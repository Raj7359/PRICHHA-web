import { Request, Response, NextFunction } from 'express';
import { verifyToken } from '../utils/jwt';

export interface AuthedRequest extends Request {
  userId?: string;
  role?: string;
}

// Accepts a JWT from EITHER:
//   - an `Authorization: Bearer <token>` header (used by the mobile app), or
//   - an httpOnly `token` cookie (used by the Next.js web app)
// so the same backend serves both clients without duplicating auth logic.
export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const bearerToken = header?.startsWith('Bearer ') ? header.slice('Bearer '.length) : undefined;
  const cookieToken = (req as any).cookies?.token as string | undefined;
  const token = bearerToken || cookieToken;

  if (!token) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  try {
    const payload = verifyToken(token);
    req.userId = payload.userId;
    req.role = payload.role;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}
