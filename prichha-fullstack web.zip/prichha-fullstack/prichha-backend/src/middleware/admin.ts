import { Response, NextFunction } from 'express';
import { AuthedRequest } from './auth';

export function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (req.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}
