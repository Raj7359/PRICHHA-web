import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();
router.use(requireAuth);

const bookSchema = z.object({
  expertId: z.string(), // the User id of the advisor/professional (not the profile id)
  type: z.enum(['CHAT', 'AUDIO', 'VIDEO']),
  ratePerMin: z.number().int().positive(),
  scheduledAt: z.string().datetime(),
});

// POST /api/sessions - book a session
router.post('/', async (req: AuthedRequest, res) => {
  const parsed = bookSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { expertId, type, ratePerMin, scheduledAt } = parsed.data;

  const expert = await prisma.user.findUnique({ where: { id: expertId } });
  if (!expert) return res.status(404).json({ error: 'Expert not found' });

  const session = await prisma.session.create({
    data: {
      studentId: req.userId!,
      expertId,
      type,
      ratePerMin,
      scheduledAt: new Date(scheduledAt),
    },
  });

  res.status(201).json(session);
});

// GET /api/sessions - my sessions (as student or expert)
router.get('/', async (req: AuthedRequest, res) => {
  const sessions = await prisma.session.findMany({
    where: { OR: [{ studentId: req.userId }, { expertId: req.userId }] },
    include: {
      student: { select: { id: true, name: true, avatarUrl: true } },
      expert: { select: { id: true, name: true, avatarUrl: true } },
    },
    orderBy: { scheduledAt: 'desc' },
  });
  res.json(sessions);
});

// GET /api/sessions/:id
router.get('/:id', async (req: AuthedRequest, res) => {
  const session = await prisma.session.findUnique({
    where: { id: req.params.id },
    include: {
      student: { select: { id: true, name: true, avatarUrl: true } },
      expert: { select: { id: true, name: true, avatarUrl: true } },
    },
  });
  if (!session) return res.status(404).json({ error: 'Session not found' });
  if (session.studentId !== req.userId && session.expertId !== req.userId) {
    return res.status(403).json({ error: 'Not authorized to view this session' });
  }
  res.json(session);
});

export default router;
