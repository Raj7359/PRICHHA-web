import { Router } from 'express';
import { prisma } from '../lib/prisma';

const router = Router();

// GET /api/mentors?search=&college=&sortBy=rating|price|sessions
router.get('/', async (req, res) => {
  const { search, college, sortBy } = req.query as Record<string, string | undefined>;

  const profiles = await prisma.advisorProfile.findMany({
    where: {
      approved: true,
      ...(college ? { college: { equals: college, mode: 'insensitive' } } : {}),
      ...(search
        ? {
            OR: [
              { college: { contains: search, mode: 'insensitive' } },
              { stream: { contains: search, mode: 'insensitive' } },
              { user: { name: { contains: search, mode: 'insensitive' } } },
            ],
          }
        : {}),
    },
    include: { user: true },
    orderBy:
      sortBy === 'price'
        ? { ratePerMin: 'asc' }
        : sortBy === 'sessions'
        ? { sessionsCount: 'desc' }
        : { rating: 'desc' },
  });

  res.json(profiles.map(serializeAdvisor));
});

router.get('/:id', async (req, res) => {
  const profile = await prisma.advisorProfile.findUnique({
    where: { id: req.params.id },
    include: { user: true },
  });
  if (!profile) return res.status(404).json({ error: 'Mentor not found' });
  res.json(serializeAdvisor(profile));
});

function serializeAdvisor(p: any) {
  return {
    id: p.id,
    name: p.user.name,
    avatarUrl: p.user.avatarUrl,
    college: p.college,
    stream: p.stream,
    rate: p.ratePerMin,
    rating: p.rating,
    sessions: p.sessionsCount,
    tags: p.tags,
    online: p.online,
    bio: p.bio,
    approved: p.approved,
  };
}

export default router;
