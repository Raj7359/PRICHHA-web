import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();
router.use(requireAuth);

async function assertParticipant(sessionId: string, userId: string) {
  const session = await prisma.session.findUnique({ where: { id: sessionId } });
  if (!session) return null;
  if (session.studentId !== userId && session.expertId !== userId) return null;
  return session;
}

// GET /api/sessions/:sessionId/messages
router.get('/:sessionId/messages', async (req: AuthedRequest, res) => {
  const session = await assertParticipant(req.params.sessionId, req.userId!);
  if (!session) return res.status(403).json({ error: 'Not authorized for this session' });

  const messages = await prisma.message.findMany({
    where: { sessionId: session.id },
    orderBy: { createdAt: 'asc' },
  });
  res.json(messages);
});

const sendSchema = z.object({ text: z.string().min(1).max(2000) });

// POST /api/sessions/:sessionId/messages
router.post('/:sessionId/messages', async (req: AuthedRequest, res) => {
  const session = await assertParticipant(req.params.sessionId, req.userId!);
  if (!session) return res.status(403).json({ error: 'Not authorized for this session' });

  const parsed = sendSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const message = await prisma.message.create({
    data: { sessionId: session.id, senderId: req.userId!, text: parsed.data.text },
  });
  res.status(201).json(message);
});

export default router;
