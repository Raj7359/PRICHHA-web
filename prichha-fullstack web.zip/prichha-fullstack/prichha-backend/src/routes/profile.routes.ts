import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();
router.use(requireAuth);

// GET /api/profile/me
// Returns the caller's own advisor/professional listing (including fields not
// exposed on the public /api/mentors and /api/professionals endpoints, like
// `approved`), so the dashboard can show "pending approval" banners etc.
router.get('/me', async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (user.role === 'ADVISOR') {
    const profile = await prisma.advisorProfile.findUnique({ where: { userId: user.id } });
    return res.json({ role: 'ADVISOR', user: publicUser(user), profile });
  }
  if (user.role === 'PROFESSIONAL') {
    const profile = await prisma.professionalProfile.findUnique({ where: { userId: user.id } });
    return res.json({ role: 'PROFESSIONAL', user: publicUser(user), profile });
  }
  return res.json({ role: user.role, user: publicUser(user), profile: null });
});

const updateSchema = z.object({
  online: z.boolean().optional(),
  bio: z.string().max(1000).optional(),
  ratePerMin: z.number().int().positive().optional(),
  tags: z.array(z.string()).optional(),
});

// PATCH /api/profile/me
// Self-service update — deliberately does NOT accept `approved`, since only
// an admin can approve a listing (see admin.routes.ts).
router.patch('/me', async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  if (!user) return res.status(404).json({ error: 'User not found' });

  const parsed = updateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  if (Object.keys(parsed.data).length === 0) return res.status(400).json({ error: 'No fields to update' });

  if (user.role === 'ADVISOR') {
    const profile = await prisma.advisorProfile.update({ where: { userId: user.id }, data: parsed.data });
    return res.json(profile);
  }
  if (user.role === 'PROFESSIONAL') {
    const profile = await prisma.professionalProfile.update({ where: { userId: user.id }, data: parsed.data });
    return res.json(profile);
  }
  return res.status(400).json({ error: 'Only advisors and professionals have a listing to update' });
});

// GET /api/profile/bookings
// Sessions where the caller is the expert — used by the advisor/professional
// dashboard's "active booking management" section.
router.get('/bookings', async (req: AuthedRequest, res) => {
  const sessions = await prisma.session.findMany({
    where: { expertId: req.userId },
    include: { student: { select: { id: true, name: true, avatarUrl: true } } },
    orderBy: { scheduledAt: 'desc' },
  });
  res.json(sessions);
});

// GET /api/profile/earnings
// Aggregate earnings analytics for the advisor/professional dashboard:
// total earned, this month, session count, and the raw list for a breakdown table.
router.get('/earnings', async (req: AuthedRequest, res) => {
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const [allTime, thisMonth, transactions] = await Promise.all([
    prisma.walletTransaction.aggregate({
      where: { userId: req.userId, kind: 'SESSION_CHARGE', type: 'CREDIT', status: 'SUCCESS' },
      _sum: { amount: true },
      _count: true,
    }),
    prisma.walletTransaction.aggregate({
      where: {
        userId: req.userId,
        kind: 'SESSION_CHARGE',
        type: 'CREDIT',
        status: 'SUCCESS',
        createdAt: { gte: startOfMonth },
      },
      _sum: { amount: true },
      _count: true,
    }),
    prisma.walletTransaction.findMany({
      where: { userId: req.userId, kind: 'SESSION_CHARGE', type: 'CREDIT', status: 'SUCCESS' },
      orderBy: { createdAt: 'desc' },
      take: 50,
    }),
  ]);

  res.json({
    totalEarnings: allTime._sum.amount ?? 0,
    totalSessions: allTime._count,
    thisMonthEarnings: thisMonth._sum.amount ?? 0,
    thisMonthSessions: thisMonth._count,
    recent: transactions,
  });
});

function publicUser(user: { id: string; name: string; email: string; role: string; balance: number; avatarUrl: string | null }) {
  return { id: user.id, name: user.name, email: user.email, role: user.role, balance: user.balance, avatarUrl: user.avatarUrl };
}

export default router;
