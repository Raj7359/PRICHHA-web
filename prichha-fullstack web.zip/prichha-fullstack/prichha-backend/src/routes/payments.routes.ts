import { Router } from 'express';
import crypto from 'crypto';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { razorpay, assertRazorpayConfigured } from '../lib/razorpay';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();

const createOrderSchema = z.object({
  amount: z.number().int().min(1).max(200000), // rupees; sanity cap to avoid fat-finger orders
});

// POST /api/payments/create-order  (auth)
// Creates a Razorpay order and a PENDING wallet transaction row keyed to it.
// The wallet balance is NOT touched here — only the webhook (source of truth)
// or /verify (fast-path UI feedback) credits it, and only after signature checks.
router.post('/create-order', requireAuth, async (req: AuthedRequest, res) => {
  assertRazorpayConfigured();
  const parsed = createOrderSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { amount } = parsed.data;

  const order = await razorpay.orders.create({
    amount: amount * 100, // paise
    currency: 'INR',
    receipt: `topup_${req.userId}_${Date.now()}`,
    notes: { userId: req.userId! },
  });

  await prisma.walletTransaction.create({
    data: {
      userId: req.userId!,
      type: 'CREDIT',
      kind: 'TOPUP',
      status: 'PENDING',
      amount,
      label: 'Money Added',
      sub: 'Razorpay',
      razorpayOrderId: order.id,
    },
  });

  res.json({
    orderId: order.id,
    amount: order.amount,
    currency: order.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
});

const verifySchema = z.object({
  razorpay_order_id: z.string(),
  razorpay_payment_id: z.string(),
  razorpay_signature: z.string(),
});

function isValidSignature(orderId: string, paymentId: string, signature: string) {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET as string)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}

// POST /api/payments/verify  (auth)
// Called by the app right after Razorpay Checkout succeeds, purely so the UI can
// reflect the new balance immediately. The webhook below is the actual source of
// truth and will safely no-op if this already credited the transaction.
router.post('/verify', requireAuth, async (req: AuthedRequest, res) => {
  assertRazorpayConfigured();
  const parsed = verifySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = parsed.data;

  if (!isValidSignature(razorpay_order_id, razorpay_payment_id, razorpay_signature)) {
    return res.status(400).json({ error: 'Invalid payment signature' });
  }

  const txn = await creditIfPending(razorpay_order_id, razorpay_payment_id, req.userId!);
  if (!txn) return res.status(404).json({ error: 'Order not found for this user' });

  res.json({ ok: true, balance: txn.newBalance });
});

// POST /api/payments/webhook  (no auth — verified via Razorpay's webhook signature)
// Mounted with express.raw() body parsing in src/index.ts so the signature can be
// computed over the exact raw bytes Razorpay sent.
router.post('/webhook', async (req, res) => {
  const signature = req.headers['x-razorpay-signature'] as string | undefined;
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!signature || !secret) return res.status(400).json({ error: 'Missing webhook signature/secret' });

  const rawBody = req.body as Buffer;
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  const valid = signature.length === expected.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  if (!valid) return res.status(400).json({ error: 'Invalid webhook signature' });

  const event = JSON.parse(rawBody.toString('utf8'));

  if (event.event === 'payment.captured' || event.event === 'order.paid') {
    const payment = event.payload?.payment?.entity;
    const orderId = payment?.order_id;
    const paymentId = payment?.id;
    const userId = payment?.notes?.userId;
    if (orderId && paymentId && userId) {
      await creditIfPending(orderId, paymentId, userId);
    }
  }

  if (event.event === 'payment.failed') {
    const payment = event.payload?.payment?.entity;
    if (payment?.order_id) {
      await prisma.walletTransaction.updateMany({
        where: { razorpayOrderId: payment.order_id, status: 'PENDING' },
        data: { status: 'FAILED' },
      });
    }
  }

  // Razorpay expects a fast 200 response regardless of what we did with the event.
  res.json({ received: true });
});

// Credits a PENDING TOPUP transaction exactly once (idempotent — safe to call from
// both /verify and the webhook without double-crediting the wallet).
async function creditIfPending(orderId: string, paymentId: string, userId: string) {
  return prisma.$transaction(async (tx) => {
    const txn = await tx.walletTransaction.findUnique({ where: { razorpayOrderId: orderId } });
    if (!txn || txn.userId !== userId) return null;
    if (txn.status === 'SUCCESS') {
      const user = await tx.user.findUnique({ where: { id: userId } });
      return { ...txn, newBalance: user?.balance ?? 0 };
    }

    await tx.walletTransaction.update({
      where: { id: txn.id },
      data: { status: 'SUCCESS', razorpayPaymentId: paymentId },
    });
    const user = await tx.user.update({
      where: { id: userId },
      data: { balance: { increment: txn.amount } },
    });
    return { ...txn, newBalance: user.balance };
  });
}

export default router;
