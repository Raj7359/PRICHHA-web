import { Router } from 'express';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { razorpay, assertRazorpayConfigured } from '../lib/razorpay';
import { signToken } from '../utils/jwt';

const router = Router();
const REGISTRATION_FEE_RUPEES = 11;

const COOKIE_OPTIONS = {
  httpOnly: true,
  sameSite: 'lax' as const,
  secure: process.env.NODE_ENV === 'production',
  maxAge: 7 * 24 * 60 * 60 * 1000,
  path: '/',
};

const startSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(['STUDENT', 'ADVISOR', 'PROFESSIONAL']).default('STUDENT'),
});

// POST /api/auth/register/start
// Creates the user row (inactive — isRegistered/paidFee false) and a ₹11
// Razorpay order. The account only becomes usable once /verify or the
// webhook confirms payment. If the email already exists but is still
// unregistered (e.g. they abandoned checkout last time), this issues a
// fresh order for that same account instead of erroring.
router.post('/start', async (req, res) => {
  assertRazorpayConfigured();
  const parsed = startSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { name, email, password, role } = parsed.data;

  let user = await prisma.user.findUnique({ where: { email } });

  if (user && (user.isRegistered || user.paidFee)) {
    return res.status(409).json({ error: 'An account with this email already exists. Try logging in instead.' });
  }

  if (!user) {
    const passwordHash = await bcrypt.hash(password, 10);
    user = await prisma.user.create({
      data: { name, email, passwordHash, role, isRegistered: false, paidFee: false },
    });
  }

  const order = await razorpay.orders.create({
    amount: REGISTRATION_FEE_RUPEES * 100, // paise
    currency: 'INR',
    receipt: `reg_${user.id}_${Date.now()}`,
    notes: { userId: user.id, purpose: 'registration_fee' },
  });

  await prisma.registrationPayment.create({
    data: {
      userId: user.id,
      amount: REGISTRATION_FEE_RUPEES,
      status: 'PENDING',
      razorpayOrderId: order.id,
    },
  });

  res.status(201).json({
    userId: user.id,
    orderId: order.id,
    amount: order.amount,
    currency: order.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
});

const verifySchema = z.object({
  userId: z.string(),
  razorpay_order_id: z.string(),
  razorpay_payment_id: z.string(),
  razorpay_signature: z.string(),
});

function isValidSignature(orderId: string, paymentId: string, signature: string) {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET as string)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
  return expected.length === signature.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}

// POST /api/auth/register/verify
// Called by the web app right after the Razorpay Checkout modal succeeds.
// The webhook below is the actual source of truth; this just lets the UI
// activate the session immediately rather than waiting on the webhook.
router.post('/verify', async (req, res) => {
  assertRazorpayConfigured();
  const parsed = verifySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { userId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = parsed.data;

  if (!isValidSignature(razorpay_order_id, razorpay_payment_id, razorpay_signature)) {
    return res.status(400).json({ error: 'Invalid payment signature' });
  }

  const user = await activateIfPending(razorpay_order_id, razorpay_payment_id, userId);
  if (!user) return res.status(404).json({ error: 'Registration order not found for this user' });

  const token = signToken({ userId: user.id, role: user.role });
  res.cookie('token', token, COOKIE_OPTIONS);
  res.json({
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role, balance: user.balance },
  });
});

// POST /api/auth/register/webhook — Razorpay calls this directly.
// Mounted with express.raw() in src/index.ts, same pattern as /api/payments/webhook.
router.post('/webhook', async (req, res) => {
  const signature = req.headers['x-razorpay-signature'] as string | undefined;
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!signature || !secret) return res.status(400).json({ error: 'Missing webhook signature/secret' });

  const rawBody = req.body as Buffer;
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  const valid = signature.length === expected.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  if (!valid) return res.status(400).json({ error: 'Invalid webhook signature' });

  const event = JSON.parse(rawBody.toString('utf8'));

  if (event.event === 'payment.captured' || event.event === 'order.paid') {
    const payment = event.payload?.payment?.entity;
    if (payment?.notes?.purpose === 'registration_fee' && payment.order_id && payment.id && payment.notes.userId) {
      await activateIfPending(payment.order_id, payment.id, payment.notes.userId);
    }
  }

  if (event.event === 'payment.failed') {
    const payment = event.payload?.payment?.entity;
    if (payment?.order_id) {
      await prisma.registrationPayment.updateMany({
        where: { razorpayOrderId: payment.order_id, status: 'PENDING' },
        data: { status: 'FAILED' },
      });
    }
  }

  res.json({ received: true });
});

// Activates a user's account exactly once for a given registration order —
// safe to call from both /verify and the webhook without double-processing.
async function activateIfPending(orderId: string, paymentId: string, userId: string) {
  return prisma.$transaction(async (tx) => {
    const payment = await tx.registrationPayment.findUnique({ where: { razorpayOrderId: orderId } });
    if (!payment || payment.userId !== userId) return null;

    if (payment.status === 'SUCCESS') {
      return tx.user.findUnique({ where: { id: userId } });
    }

    await tx.registrationPayment.update({
      where: { id: payment.id },
      data: { status: 'SUCCESS', razorpayPaymentId: paymentId },
    });

    return tx.user.update({
      where: { id: userId },
      data: { isRegistered: true, paidFee: true },
    });
  });
}

export default router;
