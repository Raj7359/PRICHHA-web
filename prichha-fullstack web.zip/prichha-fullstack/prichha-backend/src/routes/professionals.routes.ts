import { Router } from 'express';
import { prisma } from '../lib/prisma';

const router = Router();

// GET /api/professionals?search=&company=&sortBy=rating|price|sessions
router.get('/', async (req, res) => {
  const { search, company, sortBy } = req.query as Record<string, string | undefined>;

  const profiles = await prisma.professionalProfile.findMany({
    where: {
      approved: true,
      ...(company ? { company: { equals: company, mode: 'insensitive' } } : {}),
      ...(search
        ? {
            OR: [
              { company: { contains: search, mode: 'insensitive' } },
              { role: { contains: search, mode: 'insensitive' } },
              { user: { name: { contains: search, mode: 'insensitive' } } },
            ],
          }
        : {}),
    },
    include: { user: true },
    orderBy:
      sortBy === 'price'
        ? { ratePerMin: 'asc' }
        : sortBy === 'sessions'
        ? { sessionsCount: 'desc' }
        : { rating: 'desc' },
  });

  res.json(profiles.map(serializeProfessional));
});

router.get('/:id', async (req, res) => {
  const profile = await prisma.professionalProfile.findUnique({
    where: { id: req.params.id },
    include: { user: true },
  });
  if (!profile) return res.status(404).json({ error: 'Professional not found' });
  res.json(serializeProfessional(profile));
});

function serializeProfessional(p: any) {
  return {
    id: p.id,
    name: p.user.name,
    avatarUrl: p.user.avatarUrl,
    company: p.company,
    dept: p.dept,
    role: p.role,
    exp: p.experience,
    rate: p.ratePerMin,
    rating: p.rating,
    sessions: p.sessionsCount,
    tags: p.tags,
    online: p.online,
    bio: p.bio,
    approved: p.approved,
  };
}

export default router;
