import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { buildRtcToken, numericUidFor, getAppId } from '../lib/agora';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();
router.use(requireAuth);

async function assertParticipant(sessionId: string, userId: string) {
  const session = await prisma.session.findUnique({ where: { id: sessionId } });
  if (!session) return null;
  if (session.studentId !== userId && session.expertId !== userId) return null;
  return session;
}

// POST /api/calls/:sessionId/token
// Issues a short-lived Agora RTC token scoped to this session's channel.
// Only the two participants of the session (student/expert) can obtain one.
router.post('/:sessionId/token', async (req: AuthedRequest, res) => {
  const session = await assertParticipant(req.params.sessionId, req.userId!);
  if (!session) return res.status(403).json({ error: 'Not authorized for this session' });
  if (session.type === 'CHAT') return res.status(400).json({ error: 'This session type does not support calling' });
  if (session.status === 'COMPLETED' || session.status === 'CANCELLED') {
    return res.status(409).json({ error: `Session is already ${session.status.toLowerCase()}` });
  }

  // Channel name is derived from the session id so both participants always land
  // in the same Agora channel; created lazily on first token request.
  const channelName = session.agoraChannel || `prichha_${session.id}`;
  const uid = numericUidFor(req.userId!);
  const token = buildRtcToken(channelName, uid);

  const updated = await prisma.session.update({
    where: { id: session.id },
    data: {
      agoraChannel: channelName,
      status: 'ACTIVE',
      startedAt: session.startedAt ?? new Date(),
    },
  });

  res.json({
    appId: getAppId(),
    channel: channelName,
    token,
    uid,
    video: session.type === 'VIDEO',
    sessionStatus: updated.status,
  });
});

// POST /api/calls/:sessionId/end
// Ends the call, computes duration and the amount to charge the student, and
// records a SESSION_CHARGE wallet transaction. Idempotent — calling this twice
// does not double-charge.
router.post('/:sessionId/end', async (req: AuthedRequest, res) => {
  const session = await assertParticipant(req.params.sessionId, req.userId!);
  if (!session) return res.status(403).json({ error: 'Not authorized for this session' });

  if (session.status === 'COMPLETED') {
    return res.json(session);
  }

  const result = await prisma.$transaction(async (tx) => {
    const now = new Date();
    const startedAt = session.startedAt ?? now;
    const durationSec = Math.max(0, Math.round((now.getTime() - startedAt.getTime()) / 1000));
    const minutesBilled = Math.max(1, Math.ceil(durationSec / 60)); // minimum 1 minute billed
    const amountCharged = minutesBilled * session.ratePerMin;

    const updatedSession = await tx.session.update({
      where: { id: session.id },
      data: { status: 'COMPLETED', endedAt: now, durationSec, amountCharged },
    });

    // Idempotency guard: if this session was already billed (e.g. both
    // participants' clients called /end within the same race window), skip
    // charging a second time.
    const alreadyBilled = await tx.walletTransaction.findFirst({
      where: { sessionId: session.id, kind: 'SESSION_CHARGE' },
    });

    // Only charge for actual calls between two different people (not a
    // free/never-started or self-test session), and only once.
    if (!alreadyBilled && session.studentId !== session.expertId) {
      await tx.user.update({
        where: { id: session.studentId },
        data: { balance: { decrement: amountCharged } },
      });
      await tx.walletTransaction.create({
        data: {
          userId: session.studentId,
          type: 'DEBIT',
          kind: 'SESSION_CHARGE',
          status: 'SUCCESS',
          amount: amountCharged,
          label: `${session.type === 'VIDEO' ? 'Video' : 'Audio'} session`,
          sub: `${minutesBilled} min`,
          sessionId: session.id,
        },
      });

      // Credit the expert their share and record it as its own transaction so
      // it shows up in their earnings analytics. Kept as a simple full
      // pass-through credit here — a real marketplace would deduct a
      // platform commission first.
      await tx.user.update({
        where: { id: session.expertId },
        data: { balance: { increment: amountCharged } },
      });
      await tx.walletTransaction.create({
        data: {
          userId: session.expertId,
          type: 'CREDIT',
          kind: 'SESSION_CHARGE',
          status: 'SUCCESS',
          amount: amountCharged,
          label: `${session.type === 'VIDEO' ? 'Video' : 'Audio'} session earnings`,
          sub: `${minutesBilled} min`,
          sessionId: session.id,
        },
      });
    }

    return updatedSession;
  });

  res.json(result);
});

export default router;
