import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();
router.use(requireAuth);

// GET /api/wallet - current balance
router.get('/', async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ balance: user.balance });
});

// GET /api/wallet/transactions - history (topups, session charges, withdrawals)
router.get('/transactions', async (req: AuthedRequest, res) => {
  const transactions = await prisma.walletTransaction.findMany({
    where: { userId: req.userId, status: { in: ['SUCCESS', 'PENDING', 'REJECTED'] } },
    orderBy: { createdAt: 'desc' },
  });
  res.json(transactions);
});

const withdrawSchema = z.object({
  amount: z.number().int().min(100),
  method: z.enum(['UPI', 'BANK']),
  details: z.string().min(3), // UPI id, or a bank account reference/description
});

// POST /api/wallet/withdraw - request a payout.
// Funds are held (deducted) immediately so the balance never overstates what's
// actually available, and refunded automatically if an admin rejects the request.
// Actual payout to the user's bank/UPI is a manual, admin-approved step for now —
// wiring RazorpayX Payouts (or similar) is a natural next step once KYC/payout
// compliance is sorted, but is out of scope for this pass.
router.post('/withdraw', async (req: AuthedRequest, res) => {
  const parsed = withdrawSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { amount, method, details } = parsed.data;

  const result = await prisma.$transaction(async (tx) => {
    const user = await tx.user.findUnique({ where: { id: req.userId } });
    if (!user) throw Object.assign(new Error('User not found'), { status: 404 });
    if (user.balance < amount) throw Object.assign(new Error('Insufficient balance'), { status: 400 });

    await tx.user.update({ where: { id: user.id }, data: { balance: { decrement: amount } } });

    return tx.walletTransaction.create({
      data: {
        userId: user.id,
        type: 'DEBIT',
        kind: 'WITHDRAWAL',
        status: 'PENDING',
        amount,
        label: 'Withdrawal requested',
        sub: method === 'UPI' ? `UPI · ${details}` : `Bank · ${details}`,
        payoutMethod: method,
        payoutDetails: details,
      },
    });
  });

  res.status(201).json(result);
});

export default router;
