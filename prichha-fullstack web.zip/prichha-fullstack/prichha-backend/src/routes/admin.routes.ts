import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { requireAuth, AuthedRequest } from '../middleware/auth';
import { requireAdmin } from '../middleware/admin';

const router = Router();
router.use(requireAuth, requireAdmin);

// ---------- Dashboard ----------

// GET /api/admin/stats
router.get('/stats', async (_req, res) => {
  const [userCount, mentorCount, professionalCount, sessionCount, pendingWithdrawals, revenueAgg] = await Promise.all([
    prisma.user.count(),
    prisma.advisorProfile.count(),
    prisma.professionalProfile.count(),
    prisma.session.count(),
    prisma.walletTransaction.count({ where: { kind: 'WITHDRAWAL', status: 'PENDING' } }),
    prisma.walletTransaction.aggregate({ where: { kind: 'TOPUP', status: 'SUCCESS' }, _sum: { amount: true } }),
  ]);

  res.json({
    userCount,
    mentorCount,
    professionalCount,
    sessionCount,
    pendingWithdrawals,
    totalTopUpRevenue: revenueAgg._sum.amount ?? 0,
  });
});

// ---------- Users ----------

// GET /api/admin/users?search=&role=&page=&pageSize=
router.get('/users', async (req, res) => {
  const { search, role } = req.query as Record<string, string | undefined>;
  const page = Math.max(1, Number(req.query.page) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize) || 20));

  const where = {
    ...(role ? { role: role as any } : {}),
    ...(search
      ? { OR: [{ name: { contains: search, mode: 'insensitive' as const } }, { email: { contains: search, mode: 'insensitive' as const } }] }
      : {}),
  };

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where,
      select: { id: true, name: true, email: true, role: true, balance: true, isActive: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.user.count({ where }),
  ]);

  res.json({ users, total, page, pageSize });
});

const updateUserSchema = z.object({
  isActive: z.boolean().optional(),
  role: z.enum(['STUDENT', 'ADVISOR', 'PROFESSIONAL', 'ADMIN']).optional(),
});

// PATCH /api/admin/users/:id - suspend/reactivate a user, or change their role
router.patch('/users/:id', async (req, res) => {
  const parsed = updateUserSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  if (Object.keys(parsed.data).length === 0) return res.status(400).json({ error: 'No fields to update' });

  const user = await prisma.user.update({
    where: { id: req.params.id },
    data: parsed.data,
    select: { id: true, name: true, email: true, role: true, balance: true, isActive: true },
  });
  res.json(user);
});

// ---------- Transactions ----------

// GET /api/admin/transactions?kind=&status=&page=&pageSize=
router.get('/transactions', async (req, res) => {
  const { kind, status } = req.query as Record<string, string | undefined>;
  const page = Math.max(1, Number(req.query.page) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize) || 20));

  const where = {
    ...(kind ? { kind: kind as any } : {}),
    ...(status ? { status: status as any } : {}),
  };

  const [transactions, total] = await Promise.all([
    prisma.walletTransaction.findMany({
      where,
      include: { user: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.walletTransaction.count({ where }),
  ]);

  res.json({ transactions, total, page, pageSize });
});

// ---------- Withdrawals ----------

// GET /api/admin/withdrawals?status=PENDING
router.get('/withdrawals', async (req, res) => {
  const status = (req.query.status as string) || 'PENDING';
  const withdrawals = await prisma.walletTransaction.findMany({
    where: { kind: 'WITHDRAWAL', status: status as any },
    include: { user: { select: { id: true, name: true, email: true } } },
    orderBy: { createdAt: 'asc' },
  });
  res.json(withdrawals);
});

// POST /api/admin/withdrawals/:id/approve
// Marks the payout as sent. Actually moving money to the user's bank/UPI is a
// manual step outside this system for now (see wallet.routes.ts note) — this
// just records that the admin has completed it.
router.post('/withdrawals/:id/approve', async (req: AuthedRequest, res) => {
  const txn = await prisma.walletTransaction.findUnique({ where: { id: req.params.id } });
  if (!txn || txn.kind !== 'WITHDRAWAL') return res.status(404).json({ error: 'Withdrawal request not found' });
  if (txn.status !== 'PENDING') return res.status(409).json({ error: `Already ${txn.status.toLowerCase()}` });

  const updated = await prisma.walletTransaction.update({
    where: { id: txn.id },
    data: { status: 'SUCCESS', label: 'Withdrawal completed', reviewedBy: req.userId },
  });
  res.json(updated);
});

// POST /api/admin/withdrawals/:id/reject
// Refunds the held amount back to the user's wallet balance.
router.post('/withdrawals/:id/reject', async (req: AuthedRequest, res) => {
  const result = await prisma.$transaction(async (tx) => {
    const txn = await tx.walletTransaction.findUnique({ where: { id: req.params.id } });
    if (!txn || txn.kind !== 'WITHDRAWAL') throw Object.assign(new Error('Withdrawal request not found'), { status: 404 });
    if (txn.status !== 'PENDING') throw Object.assign(new Error(`Already ${txn.status.toLowerCase()}`), { status: 409 });

    await tx.user.update({ where: { id: txn.userId }, data: { balance: { increment: txn.amount } } });
    return tx.walletTransaction.update({
      where: { id: txn.id },
      data: { status: 'REJECTED', label: 'Withdrawal rejected · refunded', reviewedBy: req.userId },
    });
  });
  res.json(result);
});

// ---------- Content control (mentors / professionals) ----------

// PATCH /api/admin/mentors/:id - e.g. toggle visibility by forcing offline, correct listing data, or approve/reject
router.patch('/mentors/:id', async (req, res) => {
  const schema = z.object({
    online: z.boolean().optional(),
    ratePerMin: z.number().int().positive().optional(),
    tags: z.array(z.string()).optional(),
    approved: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const profile = await prisma.advisorProfile.update({ where: { id: req.params.id }, data: parsed.data });
  res.json(profile);
});

// GET /api/admin/mentors/pending - advisor profiles awaiting approval
router.get('/mentors/pending', async (_req, res) => {
  const profiles = await prisma.advisorProfile.findMany({
    where: { approved: false },
    include: { user: { select: { id: true, name: true, email: true, createdAt: true } } },
    orderBy: { id: 'asc' },
  });
  res.json(profiles);
});

// DELETE /api/admin/mentors/:id - remove a mentor listing (e.g. policy violation)
router.delete('/mentors/:id', async (req, res) => {
  await prisma.advisorProfile.delete({ where: { id: req.params.id } });
  res.status(204).send();
});

// PATCH /api/admin/professionals/:id
router.patch('/professionals/:id', async (req, res) => {
  const schema = z.object({
    online: z.boolean().optional(),
    ratePerMin: z.number().int().positive().optional(),
    tags: z.array(z.string()).optional(),
    approved: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const profile = await prisma.professionalProfile.update({ where: { id: req.params.id }, data: parsed.data });
  res.json(profile);
});

// GET /api/admin/professionals/pending - professional profiles awaiting approval
router.get('/professionals/pending', async (_req, res) => {
  const profiles = await prisma.professionalProfile.findMany({
    where: { approved: false },
    include: { user: { select: { id: true, name: true, email: true, createdAt: true } } },
    orderBy: { id: 'asc' },
  });
  res.json(profiles);
});

// DELETE /api/admin/professionals/:id
router.delete('/professionals/:id', async (req, res) => {
  await prisma.professionalProfile.delete({ where: { id: req.params.id } });
  res.status(204).send();
});

export default router;
