import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { signToken } from '../utils/jwt';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();

// Shared cookie options for the web app's httpOnly session cookie.
// `secure` is enabled outside development so the cookie only ever travels over HTTPS in production.
const COOKIE_OPTIONS = {
  httpOnly: true,
  sameSite: 'lax' as const,
  secure: process.env.NODE_ENV === 'production',
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days, matches JWT_EXPIRES_IN default
  path: '/',
};

function setAuthCookie(res: Response, token: string) {
  res.cookie('token', token, COOKIE_OPTIONS);
}

const signupSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(['STUDENT', 'ADVISOR', 'PROFESSIONAL']).default('STUDENT'),
});

// POST /api/auth/signup — used by the MOBILE app, which has no registration fee.
// Activates the account immediately (isRegistered/paidFee both true on creation).
// The WEB app's equivalent flow lives in registration.routes.ts and requires the
// ₹11 Razorpay payment to be verified before the account is activated.
router.post('/signup', async (req, res) => {
  const parsed = signupSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }
  const { name, email, password, role } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    return res.status(409).json({ error: 'An account with this email already exists' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: { name, email, passwordHash, role, isRegistered: true, paidFee: true },
  });

  const token = signToken({ userId: user.id, role: user.role });
  setAuthCookie(res, token);
  return res.status(201).json({
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role, balance: user.balance },
  });
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

router.post('/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }
  const { email, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  if (!user.isActive) {
    return res.status(403).json({ error: 'This account has been suspended. Contact support.' });
  }
  // Web signups that haven't completed the ₹11 payment yet cannot log in —
  // send them back through the registration-payment flow instead.
  if (!user.isRegistered || !user.paidFee) {
    return res.status(402).json({
      error: 'Registration payment not completed',
      code: 'REGISTRATION_PAYMENT_REQUIRED',
      userId: user.id,
    });
  }

  const token = signToken({ userId: user.id, role: user.role });
  setAuthCookie(res, token);
  return res.json({
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role, balance: user.balance },
  });
});

router.post('/logout', (_req, res) => {
  res.clearCookie('token', { ...COOKIE_OPTIONS, maxAge: undefined });
  res.json({ ok: true });
});

router.get('/me', requireAuth, async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId } });
  if (!user) return res.status(404).json({ error: 'User not found' });
  return res.json({
    id: user.id, name: user.name, email: user.email, role: user.role, balance: user.balance, avatarUrl: user.avatarUrl,
  });
});

export default router;
