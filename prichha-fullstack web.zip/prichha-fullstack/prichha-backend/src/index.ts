import 'dotenv/config';
import 'express-async-errors';
import http from 'http';
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';

import authRoutes from './routes/auth.routes';
import registrationRoutes from './routes/registration.routes';
import mentorsRoutes from './routes/mentors.routes';
import professionalsRoutes from './routes/professionals.routes';
import sessionsRoutes from './routes/sessions.routes';
import messagesRoutes from './routes/messages.routes';
import walletRoutes from './routes/wallet.routes';
import paymentsRoutes from './routes/payments.routes';
import adminRoutes from './routes/admin.routes';
import callsRoutes from './routes/calls.routes';
import profileRoutes from './routes/profile.routes';
import { attachSocketServer } from './lib/socket';

const app = express();

// credentials: true is required so the browser will send/receive the httpOnly
// auth cookie used by the Next.js web app and the admin dashboard. Browsers
// reject a wildcard "*" origin when credentials are used, so CORS_ORIGIN must
// list explicit origin(s) — comma-separated if you're running more than one
// (e.g. the web app on :3000 and the admin dashboard on :5173).
const allowedOrigins = (process.env.CORS_ORIGIN || 'http://localhost:3000').split(',').map((o) => o.trim());
app.use(cors({ origin: allowedOrigins, credentials: true }));

// Both webhook routes must be verified against the exact raw request bytes,
// so they need express.raw() instead of the JSON parser used everywhere else.
// This has to be registered BEFORE express.json() and BEFORE the router mounts below.
app.use('/api/payments/webhook', express.raw({ type: '*/*' }));
app.use('/api/auth/register/webhook', express.raw({ type: '*/*' }));
app.use(express.json());
app.use(cookieParser());

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/api/auth/register', registrationRoutes); // ₹11 web signup flow (must come before /api/auth catch-all below)
app.use('/api/auth', authRoutes);
app.use('/api/mentors', mentorsRoutes);
app.use('/api/professionals', professionalsRoutes);
app.use('/api/sessions', sessionsRoutes);
app.use('/api/sessions', messagesRoutes); // mounts /:sessionId/messages under /api/sessions
app.use('/api/wallet', walletRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/calls', callsRoutes);
app.use('/api/profile', profileRoutes);

// Centralized error handler (catches errors from express-async-errors too)
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

// Socket.io needs to share the same underlying HTTP server as Express
// (rather than app.listen directly) so both HTTP and WebSocket traffic
// are served on the same port.
const httpServer = http.createServer(app);
attachSocketServer(httpServer);

const PORT = Number(process.env.PORT) || 4000;
httpServer.listen(PORT, () => {
  console.log(`Prichha API (HTTP + Socket.io) listening on http://localhost:${PORT}`);
});
