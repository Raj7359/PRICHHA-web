import { RtcTokenBuilder, RtcRole } from 'agora-access-token';
import crypto from 'crypto';

const APP_ID = process.env.AGORA_APP_ID;
const APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE;

export function assertAgoraConfigured() {
  if (!APP_ID || !APP_CERTIFICATE) {
    const err: any = new Error('Calling is not configured on this server yet.');
    err.status = 503;
    throw err;
  }
}

// Agora RTC tokens need a numeric uid. We derive a stable, small positive integer
// from the user's cuid so the same user always gets the same uid within a channel,
// without having to store a separate numeric id anywhere.
export function numericUidFor(userId: string): number {
  const hash = crypto.createHash('md5').update(userId).digest();
  const n = hash.readUInt32BE(0) % 1_000_000_000;
  return n === 0 ? 1 : n;
}

export function buildRtcToken(channelName: string, uid: number, expireSeconds = 3600) {
  assertAgoraConfigured();
  const currentTimestamp = Math.floor(Date.now() / 1000);
  const privilegeExpiredTs = currentTimestamp + expireSeconds;

  return RtcTokenBuilder.buildTokenWithUid(
    APP_ID as string,
    APP_CERTIFICATE as string,
    channelName,
    uid,
    RtcRole.PUBLISHER,
    privilegeExpiredTs
  );
}

export function getAppId(): string {
  assertAgoraConfigured();
  return APP_ID as string;
}
