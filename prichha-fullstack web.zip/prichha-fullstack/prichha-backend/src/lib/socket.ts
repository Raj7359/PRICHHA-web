import { Server as HttpServer } from 'http';
import { Server, Socket } from 'socket.io';
import { verifyToken } from '../utils/jwt';
import { prisma } from './prisma';

interface AuthedSocket extends Socket {
  userId?: string;
}

// Real-time chat layer, used by the web app (the mobile app uses REST polling
// via /api/sessions/:id/messages instead — both read/write the same Message
// table, so a message sent from either client shows up on both).
export function attachSocketServer(httpServer: HttpServer) {
  const io = new Server(httpServer, {
    cors: { origin: process.env.CORS_ORIGIN || '*', credentials: true },
  });

  // Every socket connection must present a valid JWT (from the cookie or an
  // explicit auth token) before any event handlers run.
  io.use((socket: AuthedSocket, next) => {
    try {
      const cookieHeader = socket.handshake.headers.cookie || '';
      const cookieToken = cookieHeader
        .split(';')
        .map((c) => c.trim())
        .find((c) => c.startsWith('token='))
        ?.slice('token='.length);
      const authToken = socket.handshake.auth?.token as string | undefined;
      const token = authToken || cookieToken;

      if (!token) return next(new Error('Not authenticated'));
      const payload = verifyToken(token);
      socket.userId = payload.userId;
      next();
    } catch {
      next(new Error('Invalid or expired token'));
    }
  });

  io.on('connection', (socket: AuthedSocket) => {
    // Join a session's chat room. Only the two participants may join.
    socket.on('join_session', async (sessionId: string, ack?: (res: { ok: boolean; error?: string }) => void) => {
      const session = await prisma.session.findUnique({ where: { id: sessionId } });
      if (!session || (session.studentId !== socket.userId && session.expertId !== socket.userId)) {
        ack?.({ ok: false, error: 'Not authorized for this session' });
        return;
      }
      socket.join(`session:${sessionId}`);
      ack?.({ ok: true });
    });

    socket.on('leave_session', (sessionId: string) => {
      socket.leave(`session:${sessionId}`);
    });

    // Persist the message, then broadcast it to everyone in the room
    // (including the sender, so all connected clients stay in sync).
    socket.on(
      'send_message',
      async (payload: { sessionId: string; text: string }, ack?: (res: { ok: boolean; error?: string }) => void) => {
        const { sessionId, text } = payload;
        if (!text?.trim()) {
          ack?.({ ok: false, error: 'Message text is required' });
          return;
        }

        const session = await prisma.session.findUnique({ where: { id: sessionId } });
        if (!session || (session.studentId !== socket.userId && session.expertId !== socket.userId)) {
          ack?.({ ok: false, error: 'Not authorized for this session' });
          return;
        }

        const message = await prisma.message.create({
          data: { sessionId, senderId: socket.userId as string, text: text.trim() },
        });

        io.to(`session:${sessionId}`).emit('new_message', message);
        ack?.({ ok: true });
      }
    );

    // Lightweight "expert is typing…" indicator — not persisted, just relayed.
    socket.on('typing', (payload: { sessionId: string; isTyping: boolean }) => {
      socket.to(`session:${payload.sessionId}`).emit('typing', { userId: socket.userId, isTyping: payload.isTyping });
    });
  });

  return io;
}
