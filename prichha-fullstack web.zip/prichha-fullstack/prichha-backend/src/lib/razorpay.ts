import Razorpay from 'razorpay';

const keyId = process.env.RAZORPAY_KEY_ID;
const keySecret = process.env.RAZORPAY_KEY_SECRET;

if (!keyId || !keySecret) {
  // Don't crash the whole server if payments aren't configured yet (e.g. local dev
  // before Razorpay keys are issued) — but fail loudly the moment a payment route is hit.
  console.warn('[razorpay] RAZORPAY_KEY_ID/RAZORPAY_KEY_SECRET are not set — payment routes will fail until configured.');
}

export const razorpay = new Razorpay({
  key_id: keyId || 'missing_key_id',
  key_secret: keySecret || 'missing_key_secret',
});

export function assertRazorpayConfigured() {
  if (!keyId || !keySecret) {
    const err: any = new Error('Payments are not configured on this server yet.');
    err.status = 503;
    throw err;
  }
}
