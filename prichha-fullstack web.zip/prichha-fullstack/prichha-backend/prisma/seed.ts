import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const MENTORS = [
  { name: 'Priya Singh', college: 'IIT Bombay', stream: 'CSE 2nd yr', rate: 15, rating: 4.9, sessions: 47, tags: ['JEE Advanced', 'IIT Life', 'CS Prep'], online: true },
  { name: 'Rahul Sharma', college: 'BITS Pilani', stream: 'ECE 3rd yr', rate: 10, rating: 4.8, sessions: 63, tags: ['BITSAT', 'Campus Life', 'Coding'], online: true },
  { name: 'Ananya Mehta', college: 'DU - Miranda', stream: 'Economics', rate: 8, rating: 4.7, sessions: 31, tags: ['DU Entrance', 'Economics'], online: false },
  { name: 'Karan Patel', college: 'AIIMS Delhi', stream: 'MBBS 2nd yr', rate: 18, rating: 4.9, sessions: 52, tags: ['NEET', 'Medical'], online: true },
  { name: 'Sneha Gupta', college: 'IIT Delhi', stream: 'Mech 4th yr', rate: 12, rating: 4.8, sessions: 28, tags: ['JEE', 'Mechanical', 'GATE'], online: false },
  { name: 'Aryan Kapoor', college: 'NIT Trichy', stream: 'CS 3rd yr', rate: 9, rating: 4.6, sessions: 19, tags: ['Placements', 'Coding', 'NIT'], online: true },
];

const PROFESSIONALS = [
  { name: 'Vikram Nair', company: 'Google', dept: 'Engineering', role: 'SWE II', exp: '4 yrs', rate: 20, rating: 4.9, sessions: 38, tags: ['SWE Interview', 'DSA', 'System Design'], online: true },
  { name: 'Meera Iyer', company: 'Deloitte', dept: 'Consulting', role: 'Analyst', exp: '2 yrs', rate: 18, rating: 4.8, sessions: 29, tags: ['Consulting', 'Case Prep', 'Finance'], online: false },
  { name: 'Arjun Das', company: 'TCS', dept: 'Data Science', role: 'ML Eng', exp: '3 yrs', rate: 15, rating: 4.7, sessions: 44, tags: ['Python', 'ML', 'TCS NQT'], online: true },
  { name: 'Neha Joshi', company: 'Amazon', dept: 'Product', role: 'PM', exp: '5 yrs', rate: 22, rating: 4.9, sessions: 56, tags: ['Product', 'PM Interview', 'Amazon'], online: false },
];

async function main() {
  const defaultPasswordHash = await bcrypt.hash('password123', 10);

  for (const m of MENTORS) {
    const email = `${slug(m.name)}@example.com`;
    const user = await prisma.user.upsert({
      where: { email },
      update: {},
      create: { name: m.name, email, passwordHash: defaultPasswordHash, role: 'ADVISOR', isRegistered: true, paidFee: true },
    });
    await prisma.advisorProfile.upsert({
      where: { userId: user.id },
      update: {},
      create: {
        userId: user.id,
        college: m.college,
        stream: m.stream,
        ratePerMin: m.rate,
        tags: m.tags,
        online: m.online,
        rating: m.rating,
        sessionsCount: m.sessions,
        approved: true,
      },
    });
  }

  for (const p of PROFESSIONALS) {
    const email = `${slug(p.name)}@example.com`;
    const user = await prisma.user.upsert({
      where: { email },
      update: {},
      create: { name: p.name, email, passwordHash: defaultPasswordHash, role: 'PROFESSIONAL', isRegistered: true, paidFee: true },
    });
    await prisma.professionalProfile.upsert({
      where: { userId: user.id },
      update: {},
      create: {
        userId: user.id,
        company: p.company,
        dept: p.dept,
        role: p.role,
        experience: p.exp,
        ratePerMin: p.rate,
        tags: p.tags,
        online: p.online,
        rating: p.rating,
        sessionsCount: p.sessions,
        approved: true,
      },
    });
  }

  // A demo student account you can log into the app with immediately.
  await prisma.user.upsert({
    where: { email: 'student@example.com' },
    update: {},
    create: {
      name: 'Arjun Kumar',
      email: 'student@example.com',
      passwordHash: defaultPasswordHash,
      role: 'STUDENT',
      balance: 2450,
      isRegistered: true,
      paidFee: true,
    },
  });

  // A demo admin account for the admin panel.
  await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      name: 'Prichha Admin',
      email: 'admin@example.com',
      passwordHash: defaultPasswordHash,
      role: 'ADMIN',
      isRegistered: true,
      paidFee: true,
    },
  });

  // A demo advisor account with an UNAPPROVED profile, so you can immediately
  // test the admin "approve professional profile" flow without creating one by hand.
  const pendingUser = await prisma.user.upsert({
    where: { email: 'pending.mentor@example.com' },
    update: {},
    create: {
      name: 'Rohit Verma',
      email: 'pending.mentor@example.com',
      passwordHash: defaultPasswordHash,
      role: 'ADVISOR',
      isRegistered: true,
      paidFee: true,
    },
  });
  await prisma.advisorProfile.upsert({
    where: { userId: pendingUser.id },
    update: {},
    create: {
      userId: pendingUser.id,
      college: 'VIT Vellore',
      stream: 'IT 3rd yr',
      ratePerMin: 11,
      tags: ['VITEEE', 'Campus Life'],
      online: false,
      rating: 0,
      sessionsCount: 0,
      approved: false,
    },
  });

  console.log('Seed complete. Demo logins:');
  console.log('  Student: student@example.com / password123');
  console.log('  Admin:   admin@example.com / password123');
  console.log('  Pending-approval mentor: pending.mentor@example.com / password123');
}

function slug(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
