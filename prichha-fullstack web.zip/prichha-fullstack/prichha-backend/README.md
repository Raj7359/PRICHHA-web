# Prichha Backend (Phase 1)

Express + TypeScript + Prisma + PostgreSQL API for the Prichha app.

## Setup

```bash
cd prichha-backend
npm install
cp .env.example .env
# edit .env: set DATABASE_URL to your Postgres instance, set JWT_SECRET

npx prisma migrate dev --name init   # creates tables
npm run prisma:seed                  # loads demo mentors/professionals + a demo student
npm run dev                          # starts API on http://localhost:4000
```

Demo login (after seeding): `student@example.com` / `password123`

## Endpoints (Phase 1)

- `POST /api/auth/signup` `{ name, email, password, role? }` -> `{ token, user }`
- `POST /api/auth/login` `{ email, password }` -> `{ token, user }`
- `GET  /api/auth/me` (auth) -> current user
- `GET  /api/mentors?search=&college=&sortBy=` -> list of college seniors
- `GET  /api/mentors/:id` -> single mentor profile
- `GET  /api/professionals?search=&company=&sortBy=` -> list of professionals
- `GET  /api/professionals/:id` -> single professional profile
- `POST /api/sessions` (auth) `{ expertId, type, ratePerMin, scheduledAt }` -> book a session
- `GET  /api/sessions` (auth) -> my sessions
- `GET  /api/sessions/:id` (auth) -> session detail
- `GET  /api/sessions/:sessionId/messages` (auth) -> chat history for a session
- `POST /api/sessions/:sessionId/messages` (auth) `{ text }` -> send a chat message
- `GET  /api/wallet` (auth) -> `{ balance }`
- `GET  /api/wallet/transactions` (auth) -> transaction history

All `(auth)` routes require `Authorization: Bearer <token>`.

## Phase 2: Razorpay + Admin Panel

### Razorpay setup
1. Create a Razorpay account (test mode is fine to start) and grab your Key ID / Key Secret from Settings → API Keys.
2. Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in `.env`.
3. In Razorpay Dashboard → Settings → Webhooks, add a webhook pointing to `https://<your-deployed-backend>/api/payments/webhook`, subscribe to `payment.captured` and `payment.failed`, and set `RAZORPAY_WEBHOOK_SECRET` in `.env` to the secret you set there. (For local testing, use the Razorpay CLI or a tunnel like ngrok to get a public URL.)

### Payment endpoints
- `POST /api/payments/create-order` (auth) `{ amount }` -> `{ orderId, amount, currency, keyId }` — creates a Razorpay order and a `PENDING` wallet transaction. Feed `orderId`/`keyId` straight into Razorpay Checkout on the client.
- `POST /api/payments/verify` (auth) `{ razorpay_order_id, razorpay_payment_id, razorpay_signature }` — called right after Checkout succeeds, so the UI can reflect the new balance immediately. Signature-verified.
- `POST /api/payments/webhook` — Razorpay calls this directly (no user auth; verified via `x-razorpay-signature`). This is the source of truth for crediting the wallet; `/verify` and the webhook both call the same idempotent credit function, so a payment is never double-counted even if both fire.
- `POST /api/wallet/withdraw` (auth) `{ amount, method: 'UPI'|'BANK', details }` — creates a `PENDING` withdrawal request and immediately holds (deducts) the balance. Actual payout to the user's bank/UPI is a manual step performed by an admin for now — wiring an automated payout API (e.g. RazorpayX) is a good next step once KYC/compliance is sorted.

### Admin panel endpoints (all require `role: ADMIN` on the JWT)
- `GET /api/admin/stats` — dashboard summary (user/mentor/professional/session counts, pending withdrawals, total top-up revenue)
- `GET /api/admin/users?search=&role=&page=&pageSize=` — list/search users
- `PATCH /api/admin/users/:id` `{ isActive?, role? }` — suspend/reactivate a user or change their role
- `GET /api/admin/transactions?kind=&status=&page=&pageSize=` — all wallet transactions across all users
- `GET /api/admin/withdrawals?status=PENDING` — pending payout requests
- `POST /api/admin/withdrawals/:id/approve` — mark a payout as completed
- `POST /api/admin/withdrawals/:id/reject` — reject and auto-refund the held balance
- `PATCH /api/admin/mentors/:id` `{ online?, ratePerMin?, tags? }` / `DELETE /api/admin/mentors/:id` — content control over mentor listings
- `PATCH /api/admin/professionals/:id` / `DELETE /api/admin/professionals/:id` — same, for professional listings

To test the admin endpoints, log in as `admin@example.com` / `password123` (from the seed script) and use the returned token.

Calling (Agora) endpoints are added in Phase 3.

## Phase 3: Agora Calling

### Setup
1. Create an Agora project at https://console.agora.io (App Certificate must be enabled — "Secured mode: APP ID + Token").
2. Set `AGORA_APP_ID` and `AGORA_APP_CERTIFICATE` in `.env`.

### Endpoints
- `POST /api/calls/:sessionId/token` (auth) — issues a short-lived (1hr) Agora RTC token scoped to that session's channel. Only the session's student or expert can request one. Marks the session `ACTIVE` and stamps `startedAt` on first call. Returns `{ appId, channel, token, uid, video, sessionStatus }`.
- `POST /api/calls/:sessionId/end` (auth) — ends the call, computes billed duration (rounded up to the nearest minute, 1-minute minimum), charges the student's wallet, credits the expert, and records a `SESSION_CHARGE` transaction. Idempotent — safe to call more than once (e.g. both participants hanging up).

Note: the expert is credited the full session amount here (no platform commission deducted) — add a cut in `calls.routes.ts` if you want Prichha to take a percentage.

## Phase 4: Web Platform Support (prichha-web)

The backend now also serves a separate Next.js web app (`prichha-web`) alongside the mobile app. Everything below is additive — the mobile app's existing `/api/auth/signup` and `/api/auth/login` behavior is unchanged.

### Cookie-based auth (in addition to Bearer tokens)
`requireAuth` now accepts a JWT from **either** an `Authorization: Bearer <token>` header (mobile app) **or** an httpOnly `token` cookie (web app). Login/registration-verify set the cookie automatically; `POST /api/auth/logout` clears it. Because of this, **`CORS_ORIGIN` can no longer be `*`** — it must list the web app's (and admin dashboard's) exact origin(s), comma-separated. See `.env.example`.

### Mandatory ₹11 registration fee (web only)
- `POST /api/auth/register/start` `{ name, email, password, role }` — creates an **inactive** account (`isRegistered: false`) and a ₹11 Razorpay order.
- `POST /api/auth/register/verify` `{ userId, razorpay_order_id, razorpay_payment_id, razorpay_signature }` — verifies the signature and activates the account (`isRegistered: true, paidFee: true`), then logs the user in.
- `POST /api/auth/register/webhook` — Razorpay's server-to-server confirmation; the actual source of truth, same idempotent-credit pattern as `/api/payments/webhook`.
- `POST /api/auth/login` now returns `402 { code: 'REGISTRATION_PAYMENT_REQUIRED' }` if `isRegistered`/`paidFee` are false, so the web app can prompt the user to finish paying.
- The mobile app's `/api/auth/signup` is unaffected — it sets `isRegistered`/`paidFee` to `true` directly, since the mobile app has no fee.

### Real-time chat (Socket.io)
Attached to the same HTTP server as Express (see `src/lib/socket.ts`). Authenticated via the same JWT (cookie or `socket.handshake.auth.token`). Events:
- `join_session` / `leave_session` (sessionId) — joins/leaves the `session:<id>` room; only the two participants may join.
- `send_message` `{ sessionId, text }` — persists to the `Message` table and broadcasts `new_message` to the room.
- `typing` `{ sessionId, isTyping }` — relayed, not persisted.

The mobile app is unaffected — it still uses REST polling (`GET/POST /api/sessions/:id/messages`) against the same `Message` table, so messages sent from either client show up on both.

### Self-service profile (advisor/professional dashboard)
- `GET /api/profile/me` (auth) — the caller's own listing, including `approved` status.
- `PATCH /api/profile/me` (auth) `{ online?, bio?, ratePerMin?, tags? }` — self-service update (cannot set `approved` — only an admin can).
- `GET /api/profile/bookings` (auth) — sessions where the caller is the expert.
- `GET /api/profile/earnings` (auth) — total/this-month earnings + a recent transaction list, for the dashboard's analytics section.

### Professional profile approval (admin)
`AdvisorProfile`/`ProfessionalProfile` now have an `approved` boolean (default `false`). Public listing endpoints (`/api/mentors`, `/api/professionals`) only return `approved: true` profiles. New admin endpoints:
- `GET /api/admin/mentors/pending` / `GET /api/admin/professionals/pending` — profiles awaiting approval.
- Existing `PATCH /api/admin/mentors/:id` / `.../professionals/:id` now also accept `{ approved: true|false }`.
