# Prichha Admin Dashboard

Lightweight React + Vite web app for managing the Prichha backend: users, transactions, withdrawal approvals, and mentor/professional listing content control.

## Setup

```bash
npm install
cp .env.example .env   # set VITE_API_URL to your backend (e.g. http://localhost:4000)
npm run dev             # → http://localhost:5173
```

Log in with the seeded admin account: `admin@example.com` / `password123` (from `prichha-backend`'s seed script).

## What it does

- **Dashboard** — user/mentor/professional/session counts, pending withdrawals, total top-up revenue
- **Users** — search/filter by role, suspend or reactivate accounts
- **Transactions** — full history across all users, filterable by kind (top-up / withdrawal / session charge) and status
- **Withdrawals** — approve or reject pending payout requests (reject auto-refunds the user)
- **Content** — force a mentor/professional listing offline, or remove it entirely

## Notes

- Auth uses the same `/api/auth/login` endpoint as the mobile app; the dashboard simply checks the returned `role` is `ADMIN` before granting access, and every admin API call is independently re-checked server-side (`requireAdmin` middleware) — a non-admin JWT cannot use these endpoints even if someone bypasses the UI check.
- This is intentionally a single build for one static bundle (no client-side router library) to keep the dependency footprint small; add `react-router` if the page count grows significantly.
- CORS: make sure `CORS_ORIGIN` in the backend's `.env` allows this dashboard's origin (defaults to `*`, which is fine for local dev but should be locked down before shipping to production).
