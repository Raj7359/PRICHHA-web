import { useEffect, useState } from 'react';
import { getToken, setToken, me, AdminUser } from './api';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import Transactions from './pages/Transactions';
import Withdrawals from './pages/Withdrawals';
import Content from './pages/Content';

type Page = 'dashboard' | 'users' | 'transactions' | 'withdrawals' | 'content';

const NAV: { id: Page; label: string }[] = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'users', label: 'Users' },
  { id: 'transactions', label: 'Transactions' },
  { id: 'withdrawals', label: 'Withdrawals' },
  { id: 'content', label: 'Content' },
];

export default function App() {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [checking, setChecking] = useState(true);
  const [page, setPage] = useState<Page>('dashboard');

  useEffect(() => {
    const token = getToken();
    if (!token) {
      setChecking(false);
      return;
    }
    me()
      .then((u) => {
        if (u.role === 'ADMIN') setUser(u);
        else setToken(null);
      })
      .catch(() => setToken(null))
      .finally(() => setChecking(false));
  }, []);

  const handleLogout = () => {
    setToken(null);
    setUser(null);
  };

  if (checking) return <div className="loading">Loading…</div>;
  if (!user) return <Login onLogin={setUser} />;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <h2>Prichha Admin</h2>
        {NAV.map((n) => (
          <button key={n.id} className={`nav-item ${page === n.id ? 'active' : ''}`} onClick={() => setPage(n.id)}>
            {n.label}
          </button>
        ))}
        <div className="sidebar-footer">
          <div style={{ marginBottom: 8 }}>{user.name}<br />{user.email}</div>
          <button className="btn small secondary" onClick={handleLogout}>Log out</button>
        </div>
      </aside>
      <main className="main">
        {page === 'dashboard' && <Dashboard />}
        {page === 'users' && <Users />}
        {page === 'transactions' && <Transactions />}
        {page === 'withdrawals' && <Withdrawals />}
        {page === 'content' && <Content />}
      </main>
    </div>
  );
}
