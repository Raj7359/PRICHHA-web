import { useEffect, useState } from 'react';
import { getUsers, updateUser, UserRow } from '../api';

export default function Users() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [role, setRole] = useState('');
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getUsers({ search: search || undefined, role: role || undefined, page })
      .then((res) => {
        setUsers(res.users);
        setTotal(res.total);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, role, page]);

  const toggleActive = async (u: UserRow) => {
    const updated = await updateUser(u.id, { isActive: !u.isActive });
    setUsers((prev) => prev.map((x) => (x.id === u.id ? { ...x, isActive: updated.isActive } : x)));
  };

  return (
    <>
      <h1>Users</h1>
      <div className="toolbar">
        <input placeholder="Search name or email…" value={search} onChange={(e) => { setPage(1); setSearch(e.target.value); }} />
        <select value={role} onChange={(e) => { setPage(1); setRole(e.target.value); }}>
          <option value="">All roles</option>
          <option value="STUDENT">Student</option>
          <option value="ADVISOR">Advisor</option>
          <option value="PROFESSIONAL">Professional</option>
          <option value="ADMIN">Admin</option>
        </select>
      </div>

      {loading ? (
        <div className="loading">Loading…</div>
      ) : users.length === 0 ? (
        <div className="empty-state">No users found.</div>
      ) : (
        <>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Balance</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>{u.role}</td>
                  <td>₹{u.balance.toLocaleString('en-IN')}</td>
                  <td>
                    <span className={`badge ${u.isActive ? 'active' : 'suspended'}`}>{u.isActive ? 'Active' : 'Suspended'}</span>
                  </td>
                  <td>
                    <button className={`btn small ${u.isActive ? 'danger' : 'secondary'}`} onClick={() => toggleActive(u)}>
                      {u.isActive ? 'Suspend' : 'Reactivate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="pagination">
            <button className="btn small secondary" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Prev</button>
            <span>Page {page} · {total} total</span>
            <button className="btn small secondary" disabled={page * 20 >= total} onClick={() => setPage((p) => p + 1)}>Next</button>
          </div>
        </>
      )}
    </>
  );
}
