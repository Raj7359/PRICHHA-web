import { useEffect, useState } from 'react';
import { getWithdrawals, approveWithdrawal, rejectWithdrawal, TransactionRow } from '../api';

export default function Withdrawals() {
  const [rows, setRows] = useState<TransactionRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    getWithdrawals('PENDING').then(setRows).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handle = async (id: string, action: 'approve' | 'reject') => {
    setBusyId(id);
    try {
      await (action === 'approve' ? approveWithdrawal(id) : rejectWithdrawal(id));
      setRows((prev) => prev.filter((r) => r.id !== id));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <>
      <h1>Pending Withdrawals</h1>
      {loading ? (
        <div className="loading">Loading…</div>
      ) : rows.length === 0 ? (
        <div className="empty-state">No pending withdrawal requests.</div>
      ) : (
        <table>
          <thead>
            <tr>
              <th>User</th>
              <th>Amount</th>
              <th>Method</th>
              <th>Requested</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td>{t.user.name}<br /><span style={{ color: '#9CA3AF', fontSize: 11 }}>{t.user.email}</span></td>
                <td style={{ fontWeight: 600 }}>₹{t.amount}</td>
                <td>{t.sub}</td>
                <td>{new Date(t.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</td>
                <td>
                  <div className="row-actions">
                    <button className="btn small" disabled={busyId === t.id} onClick={() => handle(t.id, 'approve')}>Approve</button>
                    <button className="btn small danger" disabled={busyId === t.id} onClick={() => handle(t.id, 'reject')}>Reject</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
