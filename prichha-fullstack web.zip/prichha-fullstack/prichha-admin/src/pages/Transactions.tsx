import { useEffect, useState } from 'react';
import { getTransactions, TransactionRow } from '../api';

export default function Transactions() {
  const [rows, setRows] = useState<TransactionRow[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [kind, setKind] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getTransactions({ kind: kind || undefined, status: status || undefined, page })
      .then((res) => {
        setRows(res.transactions);
        setTotal(res.total);
      })
      .finally(() => setLoading(false));
  }, [kind, status, page]);

  return (
    <>
      <h1>Transactions</h1>
      <div className="toolbar">
        <select value={kind} onChange={(e) => { setPage(1); setKind(e.target.value); }}>
          <option value="">All types</option>
          <option value="TOPUP">Top-up</option>
          <option value="WITHDRAWAL">Withdrawal</option>
          <option value="SESSION_CHARGE">Session charge</option>
        </select>
        <select value={status} onChange={(e) => { setPage(1); setStatus(e.target.value); }}>
          <option value="">All statuses</option>
          <option value="SUCCESS">Success</option>
          <option value="PENDING">Pending</option>
          <option value="FAILED">Failed</option>
          <option value="REJECTED">Rejected</option>
        </select>
      </div>

      {loading ? (
        <div className="loading">Loading…</div>
      ) : rows.length === 0 ? (
        <div className="empty-state">No transactions found.</div>
      ) : (
        <>
          <table>
            <thead>
              <tr>
                <th>User</th>
                <th>Kind</th>
                <th>Label</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((t) => (
                <tr key={t.id}>
                  <td>{t.user.name}<br /><span style={{ color: '#9CA3AF', fontSize: 11 }}>{t.user.email}</span></td>
                  <td>{t.kind.replace('_', ' ')}</td>
                  <td>{t.label}{t.sub ? ` · ${t.sub}` : ''}</td>
                  <td style={{ color: t.type === 'CREDIT' ? '#10B981' : '#EF4444', fontWeight: 600 }}>
                    {t.type === 'CREDIT' ? '+' : '-'}₹{t.amount}
                  </td>
                  <td><span className={`badge ${t.status.toLowerCase()}`}>{t.status}</span></td>
                  <td>{new Date(t.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="pagination">
            <button className="btn small secondary" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Prev</button>
            <span>Page {page} · {total} total</span>
            <button className="btn small secondary" disabled={page * 20 >= total} onClick={() => setPage((p) => p + 1)}>Next</button>
          </div>
        </>
      )}
    </>
  );
}
