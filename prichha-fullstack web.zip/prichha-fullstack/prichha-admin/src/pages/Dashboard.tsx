import { useEffect, useState } from 'react';
import { getStats, Stats } from '../api';

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getStats().then(setStats).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading">Loading…</div>;
  if (!stats) return <div className="empty-state">Could not load stats.</div>;

  const cards = [
    { label: 'Total Users', value: stats.userCount },
    { label: 'Mentors', value: stats.mentorCount },
    { label: 'Professionals', value: stats.professionalCount },
    { label: 'Sessions', value: stats.sessionCount },
    { label: 'Pending Withdrawals', value: stats.pendingWithdrawals },
    { label: 'Total Top-up Revenue', value: `₹${stats.totalTopUpRevenue.toLocaleString('en-IN')}` },
  ];

  return (
    <>
      <h1>Dashboard</h1>
      <div className="stats-grid">
        {cards.map((c) => (
          <div className="stat-card" key={c.label}>
            <div className="label">{c.label}</div>
            <div className="value">{c.value}</div>
          </div>
        ))}
      </div>
    </>
  );
}
