import { useEffect, useState } from 'react';
import { getMentors, updateMentor, deleteMentor, getProfessionals, updateProfessional, deleteProfessional, MentorRow, ProfessionalRow } from '../api';

export default function Content() {
  const [tab, setTab] = useState<'mentors' | 'professionals'>('mentors');
  const [mentors, setMentors] = useState<MentorRow[]>([]);
  const [professionals, setProfessionals] = useState<ProfessionalRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    Promise.all([getMentors(), getProfessionals()])
      .then(([m, p]) => {
        setMentors(m);
        setProfessionals(p);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const toggleMentorOnline = async (m: MentorRow) => {
    const updated = await updateMentor(m.id, { online: !m.online });
    setMentors((prev) => prev.map((x) => (x.id === m.id ? { ...x, online: updated.online } : x)));
  };
  const removeMentor = async (id: string) => {
    if (!confirm('Remove this mentor listing? This cannot be undone.')) return;
    await deleteMentor(id);
    setMentors((prev) => prev.filter((x) => x.id !== id));
  };

  const toggleProOnline = async (p: ProfessionalRow) => {
    const updated = await updateProfessional(p.id, { online: !p.online });
    setProfessionals((prev) => prev.map((x) => (x.id === p.id ? { ...x, online: updated.online } : x)));
  };
  const removePro = async (id: string) => {
    if (!confirm('Remove this professional listing? This cannot be undone.')) return;
    await deleteProfessional(id);
    setProfessionals((prev) => prev.filter((x) => x.id !== id));
  };

  return (
    <>
      <h1>Content</h1>
      <div className="toolbar">
        <button className={`nav-item ${tab === 'mentors' ? 'active' : ''}`} style={{ width: 'auto' }} onClick={() => setTab('mentors')}>Mentors</button>
        <button className={`nav-item ${tab === 'professionals' ? 'active' : ''}`} style={{ width: 'auto' }} onClick={() => setTab('professionals')}>Professionals</button>
      </div>

      {loading ? (
        <div className="loading">Loading…</div>
      ) : tab === 'mentors' ? (
        mentors.length === 0 ? (
          <div className="empty-state">No mentor listings.</div>
        ) : (
          <table>
            <thead>
              <tr><th>Name</th><th>College</th><th>Rate</th><th>Rating</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {mentors.map((m) => (
                <tr key={m.id}>
                  <td>{m.name}</td>
                  <td>{m.college} · {m.stream}</td>
                  <td>₹{m.rate}/min</td>
                  <td>{m.rating.toFixed(1)} ({m.sessions})</td>
                  <td><span className={`badge ${m.online ? 'active' : 'suspended'}`}>{m.online ? 'Online' : 'Offline'}</span></td>
                  <td>
                    <div className="row-actions">
                      <button className="btn small secondary" onClick={() => toggleMentorOnline(m)}>{m.online ? 'Force Offline' : 'Set Online'}</button>
                      <button className="btn small danger" onClick={() => removeMentor(m.id)}>Remove</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )
      ) : professionals.length === 0 ? (
        <div className="empty-state">No professional listings.</div>
      ) : (
        <table>
          <thead>
            <tr><th>Name</th><th>Company</th><th>Rate</th><th>Rating</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {professionals.map((p) => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td>{p.company} · {p.role}</td>
                <td>₹{p.rate}/min</td>
                <td>{p.rating.toFixed(1)} ({p.sessions})</td>
                <td><span className={`badge ${p.online ? 'active' : 'suspended'}`}>{p.online ? 'Online' : 'Offline'}</span></td>
                <td>
                  <div className="row-actions">
                    <button className="btn small secondary" onClick={() => toggleProOnline(p)}>{p.online ? 'Force Offline' : 'Set Online'}</button>
                    <button className="btn small danger" onClick={() => removePro(p.id)}>Remove</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
