const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const TOKEN_KEY = 'prichha_admin_token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(token: string | null) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function apiFetch<T>(path: string, options: { method?: string; body?: unknown } = {}): Promise<T> {
  const { method = 'GET', body } = options;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const isJson = res.headers.get('content-type')?.includes('application/json');
  const data = isJson ? await res.json() : undefined;

  if (!res.ok) {
    const message = (data && (data.error?.formErrors?.[0] || data.error)) || res.statusText;
    throw new ApiError(res.status, typeof message === 'string' ? message : 'Request failed');
  }
  return data as T;
}

// ---------- Types ----------

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: 'STUDENT' | 'ADVISOR' | 'PROFESSIONAL' | 'ADMIN';
  balance: number;
}

export interface UserRow extends AdminUser {
  isActive: boolean;
  createdAt: string;
}

export interface TransactionRow {
  id: string;
  userId: string;
  user: { id: string; name: string; email: string };
  type: 'CREDIT' | 'DEBIT';
  kind: 'TOPUP' | 'WITHDRAWAL' | 'SESSION_CHARGE';
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REJECTED';
  amount: number;
  label: string;
  sub?: string | null;
  createdAt: string;
}

export interface Stats {
  userCount: number;
  mentorCount: number;
  professionalCount: number;
  sessionCount: number;
  pendingWithdrawals: number;
  totalTopUpRevenue: number;
}

export interface MentorRow {
  id: string;
  name: string;
  college: string;
  stream: string;
  rate: number;
  rating: number;
  sessions: number;
  tags: string[];
  online: boolean;
}

export interface ProfessionalRow {
  id: string;
  name: string;
  company: string;
  dept: string;
  role: string;
  exp: string;
  rate: number;
  rating: number;
  sessions: number;
  tags: string[];
  online: boolean;
}

// ---------- Auth ----------

export function login(email: string, password: string) {
  return apiFetch<{ token: string; user: AdminUser }>('/api/auth/login', { method: 'POST', body: { email, password } });
}
export function me() {
  return apiFetch<AdminUser>('/api/auth/me');
}

// ---------- Admin ----------

export function getStats() {
  return apiFetch<Stats>('/api/admin/stats');
}

export function getUsers(params: { search?: string; role?: string; page?: number } = {}) {
  const q = new URLSearchParams();
  if (params.search) q.set('search', params.search);
  if (params.role) q.set('role', params.role);
  if (params.page) q.set('page', String(params.page));
  return apiFetch<{ users: UserRow[]; total: number; page: number; pageSize: number }>(`/api/admin/users?${q}`);
}

export function updateUser(id: string, data: { isActive?: boolean; role?: string }) {
  return apiFetch<UserRow>(`/api/admin/users/${id}`, { method: 'PATCH', body: data });
}

export function getTransactions(params: { kind?: string; status?: string; page?: number } = {}) {
  const q = new URLSearchParams();
  if (params.kind) q.set('kind', params.kind);
  if (params.status) q.set('status', params.status);
  if (params.page) q.set('page', String(params.page));
  return apiFetch<{ transactions: TransactionRow[]; total: number; page: number; pageSize: number }>(`/api/admin/transactions?${q}`);
}

export function getWithdrawals(status = 'PENDING') {
  return apiFetch<TransactionRow[]>(`/api/admin/withdrawals?status=${status}`);
}
export function approveWithdrawal(id: string) {
  return apiFetch(`/api/admin/withdrawals/${id}/approve`, { method: 'POST' });
}
export function rejectWithdrawal(id: string) {
  return apiFetch(`/api/admin/withdrawals/${id}/reject`, { method: 'POST' });
}

export function getMentors() {
  return apiFetch<MentorRow[]>('/api/mentors');
}
export function updateMentor(id: string, data: { online?: boolean; ratePerMin?: number; tags?: string[] }) {
  return apiFetch<MentorRow>(`/api/admin/mentors/${id}`, { method: 'PATCH', body: data });
}
export function deleteMentor(id: string) {
  return apiFetch(`/api/admin/mentors/${id}`, { method: 'DELETE' });
}

export function getProfessionals() {
  return apiFetch<ProfessionalRow[]>('/api/professionals');
}
export function updateProfessional(id: string, data: { online?: boolean; ratePerMin?: number }) {
  return apiFetch<ProfessionalRow>(`/api/admin/professionals/${id}`, { method: 'PATCH', body: data });
}
export function deleteProfessional(id: string) {
  return apiFetch(`/api/admin/professionals/${id}`, { method: 'DELETE' });
}
