import { Modal, View, ActivityIndicator, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { WebView } from 'react-native-webview';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';

interface Props {
  visible: boolean;
  onClose: () => void;
  order: { orderId: string; amount: number; currency: string; keyId: string } | null;
  prefill: { name?: string; email?: string; contact?: string };
  onSuccess: (payload: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => void;
  onFailure?: (reason: string) => void;
}

// Renders Razorpay's own hosted Checkout (checkout.js) inside a WebView and
// bridges its callbacks back to React Native via window.ReactNativeWebView.postMessage.
// This avoids requiring the native react-native-razorpay SDK (which needs a custom
// dev client / EAS build) — this approach works the same in Expo Go and dev builds.
function buildCheckoutHtml(order: NonNullable<Props['order']>, prefill: Props['prefill']) {
  const options = {
    key: order.keyId,
    amount: order.amount,
    currency: order.currency,
    order_id: order.orderId,
    name: 'Prichha',
    description: 'Add money to wallet',
    prefill: { name: prefill.name || '', email: prefill.email || '', contact: prefill.contact || '' },
    theme: { color: '#0D7C7A' },
  };

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
      </head>
      <body style="margin:0;background:#FAFAF8;">
        <script>
          function post(msg) {
            window.ReactNativeWebView.postMessage(JSON.stringify(msg));
          }
          var options = ${JSON.stringify(options)};
          options.handler = function (response) {
            post({ event: 'success', ...response });
          };
          options.modal = {
            ondismiss: function () {
              post({ event: 'dismiss' });
            },
          };
          try {
            var rzp = new Razorpay(options);
            rzp.on('payment.failed', function (resp) {
              post({ event: 'failure', reason: resp?.error?.description || 'Payment failed' });
            });
            rzp.open();
          } catch (e) {
            post({ event: 'failure', reason: String(e) });
          }
        </script>
      </body>
    </html>
  `;
}

export default function RazorpayCheckoutModal({ visible, onClose, order, prefill, onSuccess, onFailure }: Props) {
  const colors = useColors();

  return (
    <Modal visible={visible && !!order} animationType="slide" onRequestClose={onClose}>
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
            <Feather name="x" size={20} color={colors.foreground} />
          </TouchableOpacity>
        </View>
        {order && (
          <WebView
            source={{ html: buildCheckoutHtml(order, prefill) }}
            startInLoadingState
            renderLoading={() => (
              <View style={styles.loading}>
                <ActivityIndicator color={colors.primary} size="large" />
              </View>
            )}
            onMessage={(e) => {
              try {
                const data = JSON.parse(e.nativeEvent.data);
                if (data.event === 'success') {
                  onSuccess({
                    razorpay_order_id: data.razorpay_order_id,
                    razorpay_payment_id: data.razorpay_payment_id,
                    razorpay_signature: data.razorpay_signature,
                  });
                } else if (data.event === 'dismiss') {
                  onClose();
                } else if (data.event === 'failure') {
                  onFailure?.(data.reason || 'Payment failed');
                }
              } catch {
                // ignore malformed bridge messages
              }
            }}
          />
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'flex-end', padding: 12, borderBottomWidth: 1 },
  closeBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  loading: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
});
