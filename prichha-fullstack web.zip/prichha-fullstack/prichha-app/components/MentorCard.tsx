import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';

export interface Mentor {
  id: string;
  name: string;
  college: string;
  stream: string;
  rate: string;
  rating: number;
  sessions: number;
  img: string;
  tags: string[];
  online?: boolean;
}

interface Props {
  mentor: Mentor;
  onPress: () => void;
  compact?: boolean;
}

export default function MentorCard({ mentor, onPress, compact }: Props) {
  const colors = useColors();

  if (compact) {
    return (
      <TouchableOpacity
        style={[styles.compact, { backgroundColor: colors.card, borderColor: colors.border }]}
        onPress={onPress} activeOpacity={0.85}
      >
        <View style={styles.compactTop}>
          <View>
            <Image source={{ uri: `https://i.pravatar.cc/100?img=${mentor.img}` }} style={styles.compactAvatar} />
            {mentor.online && <View style={[styles.onlineDot, { borderColor: colors.card }]} />}
          </View>
          <View style={[styles.ratingBadge, { backgroundColor: colors.amberLight }]}>
            <Feather name="star" size={10} color={colors.amber} />
            <Text style={[styles.ratingText, { color: colors.amber, fontFamily: 'Inter_700Bold' }]}>{mentor.rating}</Text>
          </View>
        </View>
        <Text style={[styles.compactName, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]} numberOfLines={1}>{mentor.name}</Text>
        <Text style={[styles.compactCollege, { color: colors.primary, fontFamily: 'Inter_600SemiBold' }]} numberOfLines={1}>{mentor.college}</Text>
        <View style={[styles.ratePill, { backgroundColor: colors.tealLight }]}>
          <Feather name="mic" size={10} color={colors.primary} />
          <Text style={[styles.rateText, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>{mentor.rate}</Text>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      style={[styles.full, { backgroundColor: colors.card, borderColor: colors.border }]}
      onPress={onPress} activeOpacity={0.85}
    >
      <View style={styles.fullLeft}>
        <View>
          <Image source={{ uri: `https://i.pravatar.cc/100?img=${mentor.img}` }} style={styles.fullAvatar} />
          {mentor.online && <View style={[styles.onlineDot, { borderColor: colors.card }]} />}
        </View>
        <View style={styles.fullInfo}>
          <Text style={[styles.fullName, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>{mentor.name}</Text>
          <Text style={[styles.fullCollege, { color: colors.primary, fontFamily: 'Inter_600SemiBold' }]}>{mentor.college} · {mentor.stream}</Text>
          <View style={styles.tags}>
            {mentor.tags.slice(0, 2).map(t => (
              <View key={t} style={[styles.tag, { backgroundColor: colors.tealLight }]}>
                <Text style={[styles.tagText, { color: colors.primary, fontFamily: 'Inter_500Medium' }]}>{t}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>
      <View style={styles.fullRight}>
        <View style={[styles.ratingBadge, { backgroundColor: colors.amberLight }]}>
          <Feather name="star" size={10} color={colors.amber} />
          <Text style={[styles.ratingText, { color: colors.amber, fontFamily: 'Inter_700Bold' }]}>{mentor.rating}</Text>
        </View>
        <Text style={[styles.fullRate, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>{mentor.rate}</Text>
        <Text style={[styles.fullSessions, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{mentor.sessions} sessions</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  compact: { width: 160, borderRadius: 20, borderWidth: 1, padding: 14, gap: 6 },
  compactTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 },
  compactAvatar: { width: 48, height: 48, borderRadius: 24 },
  compactName: { fontSize: 14 },
  compactCollege: { fontSize: 11 },
  ratePill: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10, alignSelf: 'flex-start', marginTop: 4 },
  rateText: { fontSize: 12 },
  full: { flexDirection: 'row', borderRadius: 18, borderWidth: 1, padding: 16, gap: 12, alignItems: 'center' },
  fullLeft: { flex: 1, flexDirection: 'row', gap: 12, alignItems: 'center' },
  fullAvatar: { width: 56, height: 56, borderRadius: 28 },
  fullInfo: { flex: 1, gap: 4 },
  fullName: { fontSize: 15 },
  fullCollege: { fontSize: 12 },
  tags: { flexDirection: 'row', gap: 6, marginTop: 4 },
  tag: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  tagText: { fontSize: 11 },
  fullRight: { alignItems: 'flex-end', gap: 4 },
  fullRate: { fontSize: 13 },
  fullSessions: { fontSize: 11 },
  onlineDot: { position: 'absolute', bottom: 1, right: 1, width: 12, height: 12, borderRadius: 6, backgroundColor: '#22C55E', borderWidth: 2 },
  ratingBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 8 },
  ratingText: { fontSize: 11 },
});
