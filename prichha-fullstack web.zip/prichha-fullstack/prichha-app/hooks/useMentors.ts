import { useQuery } from '@tanstack/react-query';
import { apiFetch } from '@/lib/api';
import { MentorDTO } from '@/lib/types';

export function useMentors(params: { search?: string; sortBy?: 'rating' | 'price' | 'sessions' } = {}) {
  const query = new URLSearchParams();
  if (params.search) query.set('search', params.search);
  if (params.sortBy) query.set('sortBy', params.sortBy);
  const qs = query.toString();

  return useQuery({
    queryKey: ['mentors', params],
    queryFn: () => apiFetch<MentorDTO[]>(`/api/mentors${qs ? `?${qs}` : ''}`, { auth: false }),
  });
}

export function useMentor(id: string | undefined) {
  return useQuery({
    queryKey: ['mentor', id],
    queryFn: () => apiFetch<MentorDTO>(`/api/mentors/${id}`, { auth: false }),
    enabled: !!id,
  });
}
