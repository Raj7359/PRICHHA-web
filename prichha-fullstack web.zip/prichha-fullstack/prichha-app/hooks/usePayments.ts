import { useMutation, useQueryClient } from '@tanstack/react-query';
import { createOrder, verifyPayment, requestWithdrawal } from '@/lib/payments-api';

export function useCreateOrder() {
  return useMutation({ mutationFn: createOrder });
}

export function useVerifyPayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: verifyPayment,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet'] });
    },
  });
}

export function useRequestWithdrawal() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: requestWithdrawal,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet'] });
    },
  });
}
