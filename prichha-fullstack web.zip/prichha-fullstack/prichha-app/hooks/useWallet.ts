import { useQuery } from '@tanstack/react-query';
import { apiFetch } from '@/lib/api';
import { WalletTransactionDTO } from '@/lib/types';

export function useWalletTransactions() {
  return useQuery({
    queryKey: ['wallet', 'transactions'],
    queryFn: () => apiFetch<WalletTransactionDTO[]>('/api/wallet/transactions'),
  });
}
