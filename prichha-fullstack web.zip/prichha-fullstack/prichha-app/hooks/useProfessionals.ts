import { useQuery } from '@tanstack/react-query';
import { apiFetch } from '@/lib/api';
import { ProfessionalDTO } from '@/lib/types';

export function useProfessionals(params: { search?: string; sortBy?: 'rating' | 'price' | 'sessions' } = {}) {
  const query = new URLSearchParams();
  if (params.search) query.set('search', params.search);
  if (params.sortBy) query.set('sortBy', params.sortBy);
  const qs = query.toString();

  return useQuery({
    queryKey: ['professionals', params],
    queryFn: () => apiFetch<ProfessionalDTO[]>(`/api/professionals${qs ? `?${qs}` : ''}`, { auth: false }),
  });
}

export function useProfessional(id: string | undefined) {
  return useQuery({
    queryKey: ['professional', id],
    queryFn: () => apiFetch<ProfessionalDTO>(`/api/professionals/${id}`, { auth: false }),
    enabled: !!id,
  });
}
