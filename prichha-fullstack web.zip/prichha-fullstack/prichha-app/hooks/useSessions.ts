import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { bookSession, listSessions, getSession } from '@/lib/sessions-api';

export function useBookSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: bookSession,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sessions'] });
    },
  });
}

export function useSessions() {
  return useQuery({ queryKey: ['sessions'], queryFn: listSessions });
}

export function useSession(id: string | undefined) {
  return useQuery({
    queryKey: ['session', id],
    queryFn: () => getSession(id as string),
    enabled: !!id,
  });
}
