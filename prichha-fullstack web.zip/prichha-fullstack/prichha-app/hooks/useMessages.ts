import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { listMessages, sendMessage } from '@/lib/messages-api';

export function useMessages(sessionId: string | undefined) {
  return useQuery({
    queryKey: ['messages', sessionId],
    queryFn: () => listMessages(sessionId as string),
    enabled: !!sessionId,
    // Simple polling for near-real-time chat until a WebSocket layer is added.
    refetchInterval: 4000,
  });
}

export function useSendMessage(sessionId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (text: string) => sendMessage(sessionId as string, text),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages', sessionId] });
    },
  });
}
