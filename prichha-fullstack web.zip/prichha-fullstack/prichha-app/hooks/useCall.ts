import { useMutation, useQueryClient } from '@tanstack/react-query';
import { getCallToken, endCall } from '@/lib/calls-api';

export function useCallToken() {
  return useMutation({ mutationFn: getCallToken });
}

export function useEndCall() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: endCall,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet'] });
      queryClient.invalidateQueries({ queryKey: ['sessions'] });
    },
  });
}
