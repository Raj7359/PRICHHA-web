import { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, FlatList, Modal, ScrollView, Platform, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useMentors } from '@/hooks/useMentors';
import { useProfessionals } from '@/hooks/useProfessionals';
import MentorCard, { Mentor } from '@/components/MentorCard';
import ProfessionalCard, { Professional } from '@/components/ProfessionalCard';
import { Feather } from '@expo/vector-icons';

function avatarSeed(id: string) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) % 70;
  return String(Math.abs(hash) + 1);
}

export default function ExploreScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<'college' | 'jobs'>('college');
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [filterOpen, setFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState<'rating' | 'price' | 'sessions'>('rating');

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);

  // Debounce search input so we don't hammer the API on every keystroke.
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  const { data: mentorDTOs, isLoading: mentorsLoading } = useMentors({ search: debouncedSearch, sortBy });
  const { data: professionalDTOs, isLoading: professionalsLoading } = useProfessionals({ search: debouncedSearch, sortBy });

  const mentors: Mentor[] = (mentorDTOs ?? []).map(m => ({
    id: m.id, name: m.name, college: m.college, stream: m.stream, rate: `₹${m.rate}/min`,
    rating: m.rating, sessions: m.sessions, img: avatarSeed(m.id), tags: m.tags, online: m.online,
  }));
  const professionals: Professional[] = (professionalDTOs ?? []).map(p => ({
    id: p.id, name: p.name, company: p.company, dept: p.dept, role: p.role, exp: p.exp, rate: `₹${p.rate}/min`,
    rating: p.rating, sessions: p.sessions, img: avatarSeed(p.id), tags: p.tags, online: p.online,
  }));

  const filtered = tab === 'college' ? mentors : professionals;
  const isLoading = tab === 'college' ? mentorsLoading : professionalsLoading;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.background }]}>
        <Text style={[styles.title, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Explore</Text>
        <TouchableOpacity style={[styles.filterBtn, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => setFilterOpen(true)} activeOpacity={0.8}>
          <Feather name="sliders" size={16} color={colors.foreground} />
          <Text style={[styles.filterBtnText, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>Filter</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={[styles.searchRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={16} color={colors.mutedForeground} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder={tab === 'college' ? 'Search college, name, stream…' : 'Search company, name, role…'}
          placeholderTextColor={colors.mutedForeground}
          style={[styles.searchInput, { color: colors.foreground, fontFamily: 'Inter_400Regular' }]}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Feather name="x" size={16} color={colors.mutedForeground} />
          </TouchableOpacity>
        )}
      </View>

      {/* Tab toggle */}
      <View style={[styles.tabToggle, { backgroundColor: colors.muted }]}>
        <TouchableOpacity style={[styles.tabBtn, tab === 'college' && { backgroundColor: colors.card }]} onPress={() => setTab('college')} activeOpacity={0.8}>
          <Feather name="award" size={13} color={tab === 'college' ? colors.primary : colors.mutedForeground} />
          <Text style={[styles.tabBtnText, { color: tab === 'college' ? colors.primary : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>College</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tabBtn, tab === 'jobs' && { backgroundColor: colors.card }]} onPress={() => setTab('jobs')} activeOpacity={0.8}>
          <Feather name="briefcase" size={13} color={tab === 'jobs' ? colors.amber : colors.mutedForeground} />
          <Text style={[styles.tabBtnText, { color: tab === 'jobs' ? colors.amber : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Jobs</Text>
        </TouchableOpacity>
      </View>

      <Text style={[styles.resultCount, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
        {isLoading ? 'Searching…' : `${filtered.length} ${tab === 'college' ? 'mentors' : 'professionals'} found`}
      </Text>

      {isLoading ? (
        <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
      ) : tab === 'college' ? (
        <FlatList
          data={mentors}
          keyExtractor={m => m.id}
          contentContainerStyle={{ paddingHorizontal: 20, gap: 10, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <MentorCard
              mentor={item}
              onPress={() => router.push({ pathname: '/mentor/[id]', params: { id: item.id } })}
            />
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="search" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>No mentors found</Text>
            </View>
          }
        />
      ) : (
        <FlatList
          data={professionals}
          keyExtractor={p => p.id}
          contentContainerStyle={{ paddingHorizontal: 20, gap: 10, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <ProfessionalCard
              professional={item}
              onPress={() => router.push({ pathname: '/professional/[id]', params: { id: item.id } })}
            />
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="search" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>No professionals found</Text>
            </View>
          }
        />
      )}

      {/* Filter Modal */}
      <Modal visible={filterOpen} animationType="slide" transparent>
        <TouchableOpacity style={styles.modalOverlay} onPress={() => setFilterOpen(false)} activeOpacity={1}>
          <View style={[styles.modalSheet, { backgroundColor: colors.card }]}>
            <View style={[styles.modalHandle, { backgroundColor: colors.border }]} />
            <Text style={[styles.modalTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Sort & Filter</Text>
            <Text style={[styles.modalSub, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>Sort by</Text>
            <View style={styles.sortRow}>
              {(['rating', 'price', 'sessions'] as const).map(s => (
                <TouchableOpacity key={s} style={[styles.sortChip, { backgroundColor: sortBy === s ? colors.primary : colors.muted, borderColor: sortBy === s ? colors.primary : colors.border }]} onPress={() => setSortBy(s)} activeOpacity={0.8}>
                  <Text style={[styles.sortChipText, { color: sortBy === s ? '#fff' : colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{s.charAt(0).toUpperCase() + s.slice(1)}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={[styles.applyBtn, { backgroundColor: colors.primary }]} onPress={() => setFilterOpen(false)} activeOpacity={0.85}>
              <Text style={[styles.applyBtnText, { color: '#fff', fontFamily: 'Inter_700Bold' }]}>Apply</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 14 },
  title: { fontSize: 24 },
  filterBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12, borderWidth: 1 },
  filterBtnText: { fontSize: 13 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 20, paddingHorizontal: 16, paddingVertical: 13, borderRadius: 16, borderWidth: 1, marginBottom: 12 },
  searchInput: { flex: 1, fontSize: 14 },
  tabToggle: { flexDirection: 'row', marginHorizontal: 20, borderRadius: 14, padding: 4, marginBottom: 12, gap: 4 },
  tabBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 9, borderRadius: 11 },
  tabBtnText: { fontSize: 13 },
  resultCount: { paddingHorizontal: 20, fontSize: 12, marginBottom: 10 },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 15 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.4)' },
  modalSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, paddingBottom: 48 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, marginBottom: 20 },
  modalSub: { fontSize: 13, marginBottom: 10 },
  sortRow: { flexDirection: 'row', gap: 10, marginBottom: 24 },
  sortChip: { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 20, borderWidth: 1.5 },
  sortChipText: { fontSize: 13 },
  applyBtn: { borderRadius: 16, paddingVertical: 15, alignItems: 'center' },
  applyBtnText: { fontSize: 16 },
});
