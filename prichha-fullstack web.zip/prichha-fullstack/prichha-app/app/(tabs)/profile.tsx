import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { Feather } from '@expo/vector-icons';

const MENU_ITEMS = [
  { icon: 'user' as const, label: 'Edit Profile', sub: 'Update your info & photo' },
  { icon: 'calendar' as const, label: 'My Sessions', sub: 'View session history' },
  { icon: 'star' as const, label: 'My Reviews', sub: 'Ratings you have given' },
  { icon: 'bell' as const, label: 'Notifications', sub: 'Manage alerts' },
  { icon: 'help-circle' as const, label: 'Help & Support', sub: 'FAQs & contact' },
  { icon: 'shield' as const, label: 'Privacy & Safety', sub: 'Account security settings' },
];

const ADVISOR_MENU = [
  { icon: 'bar-chart-2' as const, label: 'Earnings', sub: 'Your income & payouts' },
  { icon: 'users' as const, label: 'My Students', sub: 'Students you have mentored' },
  { icon: 'edit-2' as const, label: 'Edit Mentor Profile', sub: 'Update rates & expertise' },
];

export default function ProfileScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { userName, role, balance, logout } = useApp();

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const isAdvisor = role === 'advisor' || role === 'professional';

  const handleLogout = async () => {
    await logout();
    router.replace('/');
  };

  const roleLabel = role === 'student' ? 'Student / Aspirant' : role === 'professional' ? 'Industry Expert' : 'College Senior Mentor';
  const roleBg = role === 'student' ? colors.tealLight : colors.amberLight;
  const roleColor = role === 'student' ? colors.primary : colors.amber;

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16 }]}>
        <Text style={[styles.title, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Profile</Text>
        <TouchableOpacity style={[styles.settingsBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="settings" size={18} color={colors.foreground} />
        </TouchableOpacity>
      </View>

      {/* Profile Card */}
      <View style={[styles.profileCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.avatarWrap}>
          <Image source={{ uri: 'https://i.pravatar.cc/200?img=1' }} style={styles.avatar} />
          <TouchableOpacity style={[styles.editAvatar, { backgroundColor: colors.primary }]}>
            <Feather name="camera" size={12} color="#fff" />
          </TouchableOpacity>
        </View>
        <Text style={[styles.profileName, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>{userName}</Text>
        <View style={[styles.roleBadge, { backgroundColor: roleBg }]}>
          <Text style={[styles.roleText, { color: roleColor, fontFamily: 'Inter_600SemiBold' }]}>{roleLabel}</Text>
        </View>
        <Text style={[styles.profileHandle, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>New Delhi · India</Text>

        {/* Stats */}
        <View style={[styles.statsRow, { borderTopColor: colors.border }]}>
          {[
            { label: 'Sessions', value: '12' },
            { label: 'Balance', value: `₹${balance.toLocaleString('en-IN')}` },
            { label: 'Rating', value: '4.8 ⭐' },
          ].map((s, i) => (
            <View key={s.label} style={[styles.statItem, i < 2 && { borderRightWidth: 1, borderRightColor: colors.border }]}>
              <Text style={[styles.statValue, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>{s.value}</Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{s.label}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Advisor section */}
      {isAdvisor && (
        <View style={styles.menuSection}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>MENTOR TOOLS</Text>
          <View style={[styles.menuCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {ADVISOR_MENU.map((item, i) => (
              <TouchableOpacity key={item.label} style={[styles.menuItem, i < ADVISOR_MENU.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]} activeOpacity={0.7}>
                <View style={[styles.menuIcon, { backgroundColor: colors.amberLight }]}>
                  <Feather name={item.icon} size={18} color={colors.amber} />
                </View>
                <View style={styles.menuText}>
                  <Text style={[styles.menuLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{item.label}</Text>
                  <Text style={[styles.menuSub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{item.sub}</Text>
                </View>
                <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* General menu */}
      <View style={styles.menuSection}>
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>ACCOUNT</Text>
        <View style={[styles.menuCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {MENU_ITEMS.map((item, i) => (
            <TouchableOpacity
              key={item.label}
              style={[styles.menuItem, i < MENU_ITEMS.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
              onPress={item.label === 'Notifications' ? () => router.push('/notifications') : undefined}
              activeOpacity={0.7}
            >
              <View style={[styles.menuIcon, { backgroundColor: colors.tealLight }]}>
                <Feather name={item.icon} size={18} color={colors.primary} />
              </View>
              <View style={styles.menuText}>
                <Text style={[styles.menuLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{item.label}</Text>
                <Text style={[styles.menuSub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{item.sub}</Text>
              </View>
              <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Logout */}
      <View style={{ paddingHorizontal: 20 }}>
        <TouchableOpacity style={[styles.logoutBtn, { backgroundColor: colors.coralLight, borderColor: colors.accent }]} onPress={handleLogout} activeOpacity={0.85}>
          <Feather name="log-out" size={18} color={colors.accent} />
          <Text style={[styles.logoutText, { color: colors.accent, fontFamily: 'Inter_600SemiBold' }]}>Log Out</Text>
        </TouchableOpacity>
        <Text style={[styles.version, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>PRICHHA v1.0.0</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 16 },
  title: { fontSize: 24 },
  settingsBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  profileCard: { marginHorizontal: 20, borderRadius: 24, borderWidth: 1, padding: 24, alignItems: 'center', marginBottom: 20 },
  avatarWrap: { position: 'relative', marginBottom: 14 },
  avatar: { width: 88, height: 88, borderRadius: 44 },
  editAvatar: { position: 'absolute', bottom: 0, right: 0, width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  profileName: { fontSize: 22, marginBottom: 8 },
  roleBadge: { paddingHorizontal: 14, paddingVertical: 5, borderRadius: 20, marginBottom: 6 },
  roleText: { fontSize: 12 },
  profileHandle: { fontSize: 13, marginBottom: 20 },
  statsRow: { flexDirection: 'row', width: '100%', borderTopWidth: 1, paddingTop: 16, marginTop: 4 },
  statItem: { flex: 1, alignItems: 'center', gap: 3 },
  statValue: { fontSize: 18 },
  statLabel: { fontSize: 12 },
  menuSection: { paddingHorizontal: 20, marginBottom: 20 },
  sectionLabel: { fontSize: 11, letterSpacing: 1, marginBottom: 10 },
  menuCard: { borderRadius: 20, borderWidth: 1, overflow: 'hidden' },
  menuItem: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16 },
  menuIcon: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  menuText: { flex: 1 },
  menuLabel: { fontSize: 15, marginBottom: 2 },
  menuSub: { fontSize: 12 },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, borderRadius: 16, paddingVertical: 15, borderWidth: 1.5, marginBottom: 16 },
  logoutText: { fontSize: 15 },
  version: { textAlign: 'center', fontSize: 12, marginBottom: 8 },
});
