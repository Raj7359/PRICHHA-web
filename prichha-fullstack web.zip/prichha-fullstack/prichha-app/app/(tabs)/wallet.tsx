import { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput, Platform, Alert, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useWalletTransactions } from '@/hooks/useWallet';
import { useCreateOrder, useVerifyPayment, useRequestWithdrawal } from '@/hooks/usePayments';
import RazorpayCheckoutModal from '@/components/RazorpayCheckoutModal';
import { ApiError } from '@/lib/api';
import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';

const UPI_PROVIDERS = ['GPay', 'PhonePe', 'Paytm', 'BHIM'];
const QUICK_AMOUNTS = [100, 200, 500, 1000];

const TX_ICONS: Record<string, keyof typeof Feather.glyphMap> = {
  TOPUP: 'plus-circle',
  WITHDRAWAL: 'arrow-up-right',
  SESSION_CHARGE: 'phone',
};

export default function WalletScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { balance, user, refreshUser } = useApp();
  const { data: transactions, isLoading: txLoading } = useWalletTransactions();
  const [mode, setMode] = useState<'add' | 'withdraw'>('add');
  const [amount, setAmount] = useState('');
  const [selectedUpi, setSelectedUpi] = useState('GPay');
  const [withdrawTab, setWithdrawTab] = useState<'upi' | 'bank'>('upi');

  const createOrderMutation = useCreateOrder();
  const verifyPaymentMutation = useVerifyPayment();
  const withdrawMutation = useRequestWithdrawal();
  const [checkoutOrder, setCheckoutOrder] = useState<{ orderId: string; amount: number; currency: string; keyId: string } | null>(null);

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);

  // Creates a Razorpay order on the backend, then opens the hosted Checkout modal.
  // The wallet balance itself is only ever updated server-side, after the
  // payment signature is verified (see /api/payments/verify and the webhook).
  const handleAdd = async () => {
    const n = Number(amount);
    if (n < 1 || createOrderMutation.isPending) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      const order = await createOrderMutation.mutateAsync(n);
      setCheckoutOrder(order);
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Could not start payment. Please try again.';
      Alert.alert('Payment failed', message);
    }
  };

  const handleCheckoutSuccess = async (payload: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => {
    setCheckoutOrder(null);
    try {
      await verifyPaymentMutation.mutateAsync(payload);
      await refreshUser(); // pulls the server-confirmed balance
      setAmount('');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Money added', 'Your wallet has been topped up successfully.');
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Payment received but verification failed. Please contact support if your balance is not updated shortly.';
      Alert.alert('Verification failed', message);
    }
  };

  // Deducts the amount immediately (held) and creates a PENDING withdrawal
  // request for an admin to approve/reject — see /api/wallet/withdraw.
  const handleWithdraw = async () => {
    const n = Number(amount);
    if (n < 100 || n > balance || withdrawMutation.isPending) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      await withdrawMutation.mutateAsync({
        amount: n,
        method: withdrawTab === 'upi' ? 'UPI' : 'BANK',
        details: withdrawTab === 'upi' ? selectedUpi : 'Bank account on file',
      });
      await refreshUser();
      setAmount('');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Withdrawal requested', 'Your request has been submitted and is pending admin approval.');
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Could not submit withdrawal request. Please try again.';
      Alert.alert('Withdrawal failed', message);
    }
  };

  return (
    <>
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={{ paddingTop: topPad + 16, paddingHorizontal: 20, marginBottom: 20 }}>
        <Text style={[styles.title, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Wallet</Text>
      </View>

      {/* Balance Card */}
      <LinearGradient colors={['#0D7C7A', '#0a5e5c']} style={styles.balanceCard} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
        <View style={[styles.balanceBubble, { backgroundColor: 'rgba(255,255,255,0.1)' }]} />
        <Text style={[styles.balanceLabel, { fontFamily: 'Inter_500Medium' }]}>Available Balance</Text>
        <Text style={[styles.balanceAmount, { fontFamily: 'Inter_700Bold' }]}>₹{balance.toLocaleString('en-IN')}</Text>
        <View style={styles.balanceMeta}>
          <View style={styles.balanceMetaItem}>
            <Feather name="shield" size={13} color="rgba(255,255,255,0.7)" />
            <Text style={[styles.balanceMetaText, { fontFamily: 'Inter_400Regular' }]}>Secured & encrypted</Text>
          </View>
          <View style={styles.balanceMetaItem}>
            <Feather name="clock" size={13} color="rgba(255,255,255,0.7)" />
            <Text style={[styles.balanceMetaText, { fontFamily: 'Inter_400Regular' }]}>Instant transfer</Text>
          </View>
        </View>
      </LinearGradient>

      {/* Mode toggle */}
      <View style={[styles.modeToggle, { backgroundColor: colors.muted }]}>
        <TouchableOpacity style={[styles.modeBtn, mode === 'add' && { backgroundColor: colors.card }]} onPress={() => setMode('add')} activeOpacity={0.8}>
          <Feather name="plus" size={14} color={mode === 'add' ? colors.primary : colors.mutedForeground} />
          <Text style={[styles.modeBtnText, { color: mode === 'add' ? colors.primary : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Add Money</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.modeBtn, mode === 'withdraw' && { backgroundColor: colors.card }]} onPress={() => setMode('withdraw')} activeOpacity={0.8}>
          <Feather name="arrow-up-right" size={14} color={mode === 'withdraw' ? colors.accent : colors.mutedForeground} />
          <Text style={[styles.modeBtnText, { color: mode === 'withdraw' ? colors.accent : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Withdraw</Text>
        </TouchableOpacity>
      </View>

      <View style={{ paddingHorizontal: 20 }}>
        {mode === 'add' ? (
          <View style={[styles.panel, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.panelTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Add Money via UPI</Text>

            {/* UPI providers */}
            <View style={styles.upiRow}>
              {UPI_PROVIDERS.map(u => (
                <TouchableOpacity key={u} style={[styles.upiChip, { backgroundColor: selectedUpi === u ? colors.tealLight : colors.muted, borderColor: selectedUpi === u ? colors.primary : colors.border }]} onPress={() => setSelectedUpi(u)} activeOpacity={0.8}>
                  <Text style={[styles.upiChipText, { color: selectedUpi === u ? colors.primary : colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{u}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Quick amounts */}
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>Quick select</Text>
            <View style={styles.quickRow}>
              {QUICK_AMOUNTS.map(q => (
                <TouchableOpacity key={q} style={[styles.quickChip, { backgroundColor: amount === String(q) ? colors.primary : colors.muted }]} onPress={() => setAmount(String(q))} activeOpacity={0.8}>
                  <Text style={[styles.quickChipText, { color: amount === String(q) ? '#fff' : colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>₹{q}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={[styles.fieldLabel, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>Or enter amount</Text>
            <View style={[styles.amountInput, { borderColor: colors.border, backgroundColor: colors.background }]}>
              <Text style={[styles.rupeeSign, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>₹</Text>
              <TextInput value={amount} onChangeText={setAmount} keyboardType="number-pad" placeholder="0" placeholderTextColor={colors.mutedForeground} style={[styles.amountField, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]} />
            </View>

            <TouchableOpacity style={[styles.actionBtn, { backgroundColor: Number(amount) >= 1 ? colors.primary : colors.muted }]} onPress={handleAdd} disabled={Number(amount) < 1 || createOrderMutation.isPending} activeOpacity={0.85}>
              {createOrderMutation.isPending ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={[styles.actionBtnText, { color: Number(amount) >= 1 ? '#fff' : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Add ₹{amount || '0'}</Text>
              )}
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[styles.panel, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.panelTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Withdraw Funds</Text>
            <View style={[styles.minNote, { backgroundColor: colors.amberLight }]}>
              <Feather name="info" size={13} color={colors.amber} />
              <Text style={[styles.minNoteText, { color: colors.amber, fontFamily: 'Inter_400Regular' }]}>Minimum withdrawal: ₹100</Text>
            </View>

            {/* UPI / Bank toggle */}
            <View style={[styles.subToggle, { backgroundColor: colors.muted }]}>
              <TouchableOpacity style={[styles.subBtn, withdrawTab === 'upi' && { backgroundColor: colors.card }]} onPress={() => setWithdrawTab('upi')} activeOpacity={0.8}>
                <Text style={[styles.subBtnText, { color: withdrawTab === 'upi' ? colors.primary : colors.mutedForeground, fontFamily: 'Inter_600SemiBold' }]}>UPI</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.subBtn, withdrawTab === 'bank' && { backgroundColor: colors.card }]} onPress={() => setWithdrawTab('bank')} activeOpacity={0.8}>
                <Text style={[styles.subBtnText, { color: withdrawTab === 'bank' ? colors.primary : colors.mutedForeground, fontFamily: 'Inter_600SemiBold' }]}>Bank Account</Text>
              </TouchableOpacity>
            </View>

            {withdrawTab === 'upi' ? (
              <View style={styles.upiRow}>
                {UPI_PROVIDERS.map(u => (
                  <TouchableOpacity key={u} style={[styles.upiChip, { backgroundColor: selectedUpi === u ? colors.tealLight : colors.muted, borderColor: selectedUpi === u ? colors.primary : colors.border }]} onPress={() => setSelectedUpi(u)} activeOpacity={0.8}>
                    <Text style={[styles.upiChipText, { color: selectedUpi === u ? colors.primary : colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{u}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            ) : (
              <View style={[styles.bankRow, { backgroundColor: colors.muted, borderColor: colors.border }]}>
                <Feather name="credit-card" size={20} color={colors.mutedForeground} />
                <Text style={[styles.bankText, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>No bank account linked. Tap to add.</Text>
                <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
              </View>
            )}

            <Text style={[styles.fieldLabel, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>Enter amount</Text>
            <View style={[styles.amountInput, { borderColor: colors.border, backgroundColor: colors.background }]}>
              <Text style={[styles.rupeeSign, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>₹</Text>
              <TextInput value={amount} onChangeText={setAmount} keyboardType="number-pad" placeholder="100" placeholderTextColor={colors.mutedForeground} style={[styles.amountField, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]} />
            </View>

            <TouchableOpacity style={[styles.actionBtn, { backgroundColor: Number(amount) >= 100 && Number(amount) <= balance ? colors.accent : colors.muted }]} onPress={handleWithdraw} disabled={Number(amount) < 100 || Number(amount) > balance || withdrawMutation.isPending} activeOpacity={0.85}>
              {withdrawMutation.isPending ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={[styles.actionBtnText, { color: Number(amount) >= 100 ? '#fff' : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Withdraw ₹{amount || '0'}</Text>
              )}
            </TouchableOpacity>
          </View>
        )}

        {/* Transaction History */}
        <View style={styles.historySection}>
          <Text style={[styles.historyTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Transaction History</Text>
          {txLoading ? (
            <ActivityIndicator color={colors.primary} style={{ marginTop: 12 }} />
          ) : !transactions?.length ? (
            <Text style={[styles.txSub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>No transactions yet.</Text>
          ) : (
            <View style={styles.txList}>
              {transactions.map(tx => (
                <View key={tx.id} style={[styles.txItem, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <View style={[styles.txIcon, { backgroundColor: tx.type === 'CREDIT' ? colors.successLight : colors.coralLight }]}>
                    <Feather name={TX_ICONS[tx.kind]} size={16} color={tx.type === 'CREDIT' ? colors.success : colors.accent} />
                  </View>
                  <View style={styles.txInfo}>
                    <Text style={[styles.txLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{tx.label}</Text>
                    <Text style={[styles.txSub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
                      {tx.sub ? `${tx.sub} · ` : ''}{new Date(tx.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}
                    </Text>
                  </View>
                  <Text style={[styles.txAmount, { color: tx.type === 'CREDIT' ? colors.success : colors.accent, fontFamily: 'Inter_700Bold' }]}>
                    {tx.type === 'CREDIT' ? '+' : '-'}₹{tx.amount}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </View>
      </View>
    </ScrollView>
    <RazorpayCheckoutModal
      visible={!!checkoutOrder}
      order={checkoutOrder}
      onClose={() => setCheckoutOrder(null)}
      prefill={{ name: user?.name, email: user?.email }}
      onSuccess={handleCheckoutSuccess}
      onFailure={(reason) => {
        setCheckoutOrder(null);
        Alert.alert('Payment failed', reason);
      }}
    />
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 24 },
  balanceCard: { marginHorizontal: 20, borderRadius: 24, padding: 24, marginBottom: 20, overflow: 'hidden', position: 'relative' },
  balanceBubble: { position: 'absolute', width: 160, height: 160, borderRadius: 80, top: -40, right: -40 },
  balanceLabel: { color: 'rgba(255,255,255,0.75)', fontSize: 13, marginBottom: 6 },
  balanceAmount: { color: '#fff', fontSize: 38, marginBottom: 16 },
  balanceMeta: { flexDirection: 'row', gap: 20 },
  balanceMetaItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  balanceMetaText: { color: 'rgba(255,255,255,0.7)', fontSize: 12 },
  modeToggle: { flexDirection: 'row', marginHorizontal: 20, borderRadius: 16, padding: 4, marginBottom: 16, gap: 4 },
  modeBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 11, borderRadius: 13 },
  modeBtnText: { fontSize: 13 },
  panel: { borderRadius: 20, borderWidth: 1, padding: 20, gap: 16, marginBottom: 24 },
  panelTitle: { fontSize: 17 },
  upiRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  upiChip: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 12, borderWidth: 1.5 },
  upiChipText: { fontSize: 13 },
  fieldLabel: { fontSize: 12 },
  quickRow: { flexDirection: 'row', gap: 8 },
  quickChip: { flex: 1, paddingVertical: 10, borderRadius: 12, alignItems: 'center' },
  quickChipText: { fontSize: 13 },
  amountInput: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14 },
  rupeeSign: { fontSize: 22, marginRight: 4 },
  amountField: { flex: 1, fontSize: 22 },
  actionBtn: { borderRadius: 16, paddingVertical: 15, alignItems: 'center' },
  actionBtnText: { fontSize: 16 },
  minNote: { flexDirection: 'row', gap: 8, padding: 12, borderRadius: 12, alignItems: 'center' },
  minNoteText: { fontSize: 13 },
  subToggle: { flexDirection: 'row', borderRadius: 12, padding: 4, gap: 4 },
  subBtn: { flex: 1, paddingVertical: 8, alignItems: 'center', borderRadius: 9 },
  subBtnText: { fontSize: 13 },
  bankRow: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 14, borderWidth: 1 },
  bankText: { flex: 1, fontSize: 14 },
  historySection: { marginBottom: 20 },
  historyTitle: { fontSize: 17, marginBottom: 14 },
  txList: { gap: 10 },
  txItem: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 16, borderWidth: 1 },
  txIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  txInfo: { flex: 1 },
  txLabel: { fontSize: 14, marginBottom: 3 },
  txSub: { fontSize: 12 },
  txAmount: { fontSize: 15 },
});
