import { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput, FlatList, Image, Platform, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useMentors } from '@/hooks/useMentors';
import { useProfessionals } from '@/hooks/useProfessionals';
import MentorCard, { Mentor } from '@/components/MentorCard';
import ProfessionalCard, { Professional } from '@/components/ProfessionalCard';
import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

// Deterministic placeholder avatar index derived from id, so cards stay stable across refetches
// until real avatarUrl values are populated on profiles.
function avatarSeed(id: string) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) % 70;
  return String(Math.abs(hash) + 1);
}

const COLLEGE_CHIPS = ['IIT Bombay', 'IIT Delhi', 'BITS Pilani', 'AIIMS', 'DU', 'NIT Trichy'];
const JOB_CHIPS = ['Google', 'TCS', 'Infosys', 'Amazon', 'Deloitte', 'Wipro'];
const STREAMS = [
  { label: 'Engineering', icon: 'cpu' as const },
  { label: 'Medical', icon: 'activity' as const },
  { label: 'Commerce', icon: 'trending-up' as const },
  { label: 'Arts', icon: 'book-open' as const },
  { label: 'Law', icon: 'shield' as const },
  { label: 'Design', icon: 'pen-tool' as const },
];
const DEPTS = [
  { label: 'Engineering', icon: 'cpu' as const },
  { label: 'Data Science', icon: 'bar-chart-2' as const },
  { label: 'Finance', icon: 'trending-up' as const },
  { label: 'Product', icon: 'layers' as const },
  { label: 'Marketing', icon: 'megaphone' as const },
  { label: 'HR & Ops', icon: 'users' as const },
];

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { userName } = useApp();
  const [tab, setTab] = useState<'college' | 'jobs'>('college');
  const [search, setSearch] = useState('');

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const { data: mentorDTOs, isLoading: mentorsLoading } = useMentors({ sortBy: 'rating' });
  const { data: professionalDTOs, isLoading: professionalsLoading } = useProfessionals({ sortBy: 'rating' });

  const COLLEGE_MENTORS: Mentor[] = (mentorDTOs ?? []).slice(0, 6).map(m => ({
    id: m.id, name: m.name, college: m.college, stream: m.stream, rate: `₹${m.rate}/min`,
    rating: m.rating, sessions: m.sessions, img: avatarSeed(m.id), tags: m.tags, online: m.online,
  }));

  const PROFESSIONALS: Professional[] = (professionalDTOs ?? []).slice(0, 6).map(p => ({
    id: p.id, name: p.name, company: p.company, dept: p.dept, role: p.role, exp: p.exp, rate: `₹${p.rate}/min`,
    rating: p.rating, sessions: p.sessions, img: avatarSeed(p.id), tags: p.tags, online: p.online,
  }));

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: 100 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16 }]}>
        <View style={styles.headerLeft}>
          <View style={[styles.locationPill, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="map-pin" size={13} color={colors.accent} />
            <Text style={[styles.locationText, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>New Delhi</Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity style={[styles.iconBtn, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => router.push('/notifications')}>
            <Feather name="bell" size={18} color={colors.foreground} />
            <View style={[styles.notifDot, { backgroundColor: colors.accent }]} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => router.push('/(tabs)/profile')}>
            <Image source={{ uri: 'https://i.pravatar.cc/100?img=1' }} style={styles.avatar} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.greet}>
        <Text style={[styles.greetText, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>Good morning 👋</Text>
        <Text style={[styles.greetName, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>{userName}</Text>
      </View>

      {/* Search */}
      <View style={[styles.searchRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={16} color={colors.mutedForeground} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search college, company, role…"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.searchInput, { color: colors.foreground, fontFamily: 'Inter_400Regular' }]}
        />
      </View>

      {/* Tab toggle */}
      <View style={[styles.tabToggle, { backgroundColor: colors.muted }]}>
        <TouchableOpacity
          style={[styles.tabBtn, tab === 'college' && { backgroundColor: colors.card }]}
          onPress={() => setTab('college')} activeOpacity={0.8}
        >
          <Feather name="award" size={14} color={tab === 'college' ? colors.primary : colors.mutedForeground} />
          <Text style={[styles.tabBtnText, { color: tab === 'college' ? colors.primary : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>College</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabBtn, tab === 'jobs' && { backgroundColor: colors.card }]}
          onPress={() => setTab('jobs')} activeOpacity={0.8}
        >
          <Feather name="briefcase" size={14} color={tab === 'jobs' ? colors.amber : colors.mutedForeground} />
          <Text style={[styles.tabBtnText, { color: tab === 'jobs' ? colors.amber : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Jobs</Text>
        </TouchableOpacity>
      </View>

      {tab === 'college' ? (
        <>
          {/* College Hero */}
          <LinearGradient colors={['#0D7C7A', '#16a098']} style={styles.hero} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
            <View style={[styles.heroBubble, { backgroundColor: 'rgba(255,255,255,0.12)' }]} />
            <View style={[styles.badgePill, { backgroundColor: 'rgba(255,255,255,0.22)' }]}>
              <Text style={styles.badgePillText}>⭐ Top Rated Seniors</Text>
            </View>
            <Text style={[styles.heroTitle, { fontFamily: 'Inter_700Bold' }]}>Talk to real seniors{'\n'}from your dream college.</Text>
            <TouchableOpacity style={styles.heroBtn} onPress={() => router.push('/(tabs)/explore')} activeOpacity={0.85}>
              <Text style={[styles.heroBtnText, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>Find a Senior</Text>
            </TouchableOpacity>
          </LinearGradient>

          {/* Chips */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
            {COLLEGE_CHIPS.map(c => (
              <TouchableOpacity key={c} style={[styles.chip, { backgroundColor: colors.card, borderColor: colors.border }]} activeOpacity={0.8}>
                <Text style={[styles.chipText, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{c}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Top Mentors */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Top College Mentors</Text>
              <TouchableOpacity onPress={() => router.push('/(tabs)/explore')}>
                <Text style={[styles.seeAll, { color: colors.primary, fontFamily: 'Inter_600SemiBold' }]}>See All</Text>
              </TouchableOpacity>
            </View>
            {mentorsLoading ? (
              <ActivityIndicator color={colors.primary} style={{ marginLeft: 20 }} />
            ) : (
              <FlatList
                horizontal
                data={COLLEGE_MENTORS}
                keyExtractor={m => m.id}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ gap: 12, paddingHorizontal: 20 }}
                style={{ marginHorizontal: -20 }}
                renderItem={({ item }) => (
                  <MentorCard mentor={item} compact onPress={() => router.push({ pathname: '/mentor/[id]', params: { id: item.id } })} />
                )}
              />
            )}
          </View>

          {/* Browse by Stream */}
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold', marginBottom: 12 }]}>Browse by Stream</Text>
            <View style={styles.grid}>
              {STREAMS.map(s => (
                <TouchableOpacity key={s.label} style={[styles.gridItem, { backgroundColor: colors.card, borderColor: colors.border }]} activeOpacity={0.8}>
                  <View style={[styles.gridIcon, { backgroundColor: colors.tealLight }]}>
                    <Feather name={s.icon} size={18} color={colors.primary} />
                  </View>
                  <Text style={[styles.gridLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{s.label}</Text>
                  <Feather name="chevron-right" size={14} color={colors.mutedForeground} />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </>
      ) : (
        <>
          {/* Jobs Hero */}
          <LinearGradient colors={['#F59E0B', '#F97316']} style={styles.hero} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
            <View style={[styles.heroBubble, { backgroundColor: 'rgba(255,255,255,0.12)' }]} />
            <View style={[styles.badgePill, { backgroundColor: 'rgba(255,255,255,0.22)' }]}>
              <Text style={styles.badgePillText}>💼 Industry Experts</Text>
            </View>
            <Text style={[styles.heroTitle, { fontFamily: 'Inter_700Bold' }]}>Get career guidance from{'\n'}working professionals.</Text>
            <TouchableOpacity style={styles.heroBtn} onPress={() => router.push('/(tabs)/explore')} activeOpacity={0.85}>
              <Text style={[styles.heroBtnText, { color: colors.amber, fontFamily: 'Inter_700Bold' }]}>Find a Professional</Text>
            </TouchableOpacity>
          </LinearGradient>

          {/* Company Chips */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
            {JOB_CHIPS.map(c => (
              <TouchableOpacity key={c} style={[styles.chip, { backgroundColor: colors.card, borderColor: '#FDE68A' }]} activeOpacity={0.8}>
                <Text style={[styles.chipText, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{c}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Top Professionals */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Top Professionals</Text>
              <TouchableOpacity onPress={() => router.push('/(tabs)/explore')}>
                <Text style={[styles.seeAll, { color: colors.amber, fontFamily: 'Inter_600SemiBold' }]}>See All</Text>
              </TouchableOpacity>
            </View>
            {professionalsLoading ? (
              <ActivityIndicator color={colors.amber} style={{ marginLeft: 20 }} />
            ) : (
              <FlatList
                horizontal
                data={PROFESSIONALS}
                keyExtractor={p => p.id}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ gap: 12, paddingHorizontal: 20 }}
                style={{ marginHorizontal: -20 }}
                renderItem={({ item }) => (
                  <ProfessionalCard professional={item} compact onPress={() => router.push({ pathname: '/professional/[id]', params: { id: item.id } })} />
                )}
              />
            )}
          </View>

          {/* Browse by Department */}
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold', marginBottom: 12 }]}>Browse by Department</Text>
            <View style={styles.grid}>
              {DEPTS.map(d => (
                <TouchableOpacity key={d.label} style={[styles.gridItem, { backgroundColor: colors.card, borderColor: '#FDE68A' }]} activeOpacity={0.8}>
                  <View style={[styles.gridIcon, { backgroundColor: colors.amberLight }]}>
                    <Feather name={d.icon} size={18} color={colors.amber} />
                  </View>
                  <Text style={[styles.gridLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{d.label}</Text>
                  <Feather name="chevron-right" size={14} color={colors.mutedForeground} />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 12 },
  headerLeft: {},
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  locationPill: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: 1 },
  locationText: { fontSize: 13 },
  iconBtn: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', borderWidth: 1, position: 'relative' },
  notifDot: { position: 'absolute', top: 7, right: 7, width: 8, height: 8, borderRadius: 4 },
  avatar: { width: 38, height: 38, borderRadius: 19 },
  greet: { paddingHorizontal: 20, marginBottom: 16 },
  greetText: { fontSize: 13, marginBottom: 2 },
  greetName: { fontSize: 22 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 20, paddingHorizontal: 16, paddingVertical: 13, borderRadius: 16, borderWidth: 1, marginBottom: 16 },
  searchInput: { flex: 1, fontSize: 14 },
  tabToggle: { flexDirection: 'row', marginHorizontal: 20, borderRadius: 16, padding: 4, marginBottom: 16, gap: 4 },
  tabBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10, borderRadius: 13 },
  tabBtnText: { fontSize: 13 },
  hero: { marginHorizontal: 20, borderRadius: 24, padding: 22, marginBottom: 16, overflow: 'hidden', position: 'relative' },
  heroBubble: { position: 'absolute', width: 130, height: 130, borderRadius: 65, top: -30, right: -30 },
  badgePill: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, marginBottom: 12 },
  badgePillText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  heroTitle: { color: '#fff', fontSize: 18, lineHeight: 26, marginBottom: 18 },
  heroBtn: { backgroundColor: '#fff', alignSelf: 'flex-start', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 12 },
  heroBtnText: { fontSize: 13 },
  chips: { paddingHorizontal: 20, gap: 8, marginBottom: 20 },
  chip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  chipText: { fontSize: 13 },
  section: { paddingHorizontal: 20, marginBottom: 24 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  sectionTitle: { fontSize: 17 },
  seeAll: { fontSize: 13 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  gridItem: { width: '47%', flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, borderRadius: 16, borderWidth: 1 },
  gridIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  gridLabel: { flex: 1, fontSize: 13 },
});
