import { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

type MentorType = 'college' | 'professional' | null;

export default function AdvisorOnboardingScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { setRole } = useApp();

  const [step, setStep] = useState(1);
  const [mentorType, setMentorType] = useState<MentorType>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [institution, setInstitution] = useState('');
  const [rate, setRate] = useState('10');
  const [chatTrialEnabled, setChatTrialEnabled] = useState(true);

  const TOTAL_STEPS = 5;

  const handleNext = () => {
    if (step < TOTAL_STEPS) {
      setStep(s => s + 1);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleFinish = () => {
    if (mentorType === 'professional') setRole('professional');
    else setRole('advisor');
    router.replace('/(tabs)');
  };

  const bg = colors.background;
  const top = insets.top + (Platform.OS === 'web' ? 67 : 16);

  return (
    <View style={[styles.container, { backgroundColor: bg, paddingTop: top }]}>
      {/* Header */}
      <View style={styles.header}>
        {step < TOTAL_STEPS && (
          <TouchableOpacity onPress={() => step > 1 ? setStep(s => s - 1) : router.back()} style={[styles.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="chevron-left" size={20} color={colors.foreground} />
          </TouchableOpacity>
        )}
        <View style={[styles.progressBar, { backgroundColor: colors.muted }]}>
          <View style={[styles.progressFill, { backgroundColor: colors.primary, width: `${(step / TOTAL_STEPS) * 100}%` as any }]} />
        </View>
        <Text style={[styles.stepLabel, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>{step}/{TOTAL_STEPS}</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* STEP 1 — Mentor type */}
        {step === 1 && (
          <View style={styles.stepWrap}>
            <Text style={[styles.stepTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>What kind of mentor{'\n'}are you?</Text>
            <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>This shapes your profile and student discovery.</Text>
            <View style={styles.typeCards}>
              <TouchableOpacity
                style={[styles.typeCard, { borderColor: mentorType === 'college' ? colors.primary : colors.border, backgroundColor: mentorType === 'college' ? colors.tealLight : colors.card }]}
                onPress={() => setMentorType('college')} activeOpacity={0.8}
              >
                <Feather name="award" size={32} color={mentorType === 'college' ? colors.primary : colors.mutedForeground} />
                <Text style={[styles.typeCardTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>College Senior</Text>
                <Text style={[styles.typeCardDesc, { color: colors.mutedForeground }]}>Guide students on admissions, campus life, entrance exams</Text>
                {mentorType === 'college' && <View style={[styles.radioCheck, { backgroundColor: colors.primary }]}><Feather name="check" size={12} color="#fff" /></View>}
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.typeCard, { borderColor: mentorType === 'professional' ? colors.amber : colors.border, backgroundColor: mentorType === 'professional' ? colors.amberLight : colors.card }]}
                onPress={() => setMentorType('professional')} activeOpacity={0.8}
              >
                <Feather name="briefcase" size={32} color={mentorType === 'professional' ? colors.amber : colors.mutedForeground} />
                <Text style={[styles.typeCardTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Industry Expert</Text>
                <Text style={[styles.typeCardDesc, { color: colors.mutedForeground }]}>Guide students on careers, placements, company interviews</Text>
                {mentorType === 'professional' && <View style={[styles.radioCheck, { backgroundColor: colors.amber }]}><Feather name="check" size={12} color="#fff" /></View>}
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={[styles.nextBtn, { backgroundColor: mentorType ? colors.primary : colors.muted }]} onPress={handleNext} disabled={!mentorType} activeOpacity={0.85}>
              <Text style={[styles.nextBtnText, { color: mentorType ? colors.primaryForeground : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Continue</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* STEP 2 — Basic info */}
        {step === 2 && (
          <View style={styles.stepWrap}>
            <Text style={[styles.stepTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Tell us about{'\n'}yourself</Text>
            <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>This is what students will see on your profile.</Text>
            <View style={styles.fields}>
              {[
                { label: 'Full Name', value: name, onChange: setName, placeholder: 'e.g. Priya Singh' },
                { label: 'Phone Number', value: phone, onChange: setPhone, placeholder: '+91 98765 43210', keyboardType: 'phone-pad' as const },
                { label: mentorType === 'professional' ? 'Company & Role' : 'College & Year', value: institution, onChange: setInstitution, placeholder: mentorType === 'professional' ? 'e.g. Google · SWE II' : 'e.g. IIT Bombay · CSE 3rd Year' },
              ].map(f => (
                <View key={f.label}>
                  <Text style={[styles.fieldLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{f.label}</Text>
                  <TextInput
                    value={f.value}
                    onChangeText={f.onChange}
                    placeholder={f.placeholder}
                    placeholderTextColor={colors.mutedForeground}
                    keyboardType={f.keyboardType}
                    style={[styles.input, { borderColor: colors.border, backgroundColor: colors.card, color: colors.foreground, fontFamily: 'Inter_400Regular' }]}
                  />
                </View>
              ))}
            </View>
            <TouchableOpacity style={[styles.nextBtn, { backgroundColor: name && institution ? colors.primary : colors.muted }]} onPress={handleNext} disabled={!name || !institution} activeOpacity={0.85}>
              <Text style={[styles.nextBtnText, { color: name && institution ? colors.primaryForeground : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>Continue</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* STEP 3 — Documents */}
        {step === 3 && (
          <View style={styles.stepWrap}>
            <Text style={[styles.stepTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Verify your{'\n'}identity</Text>
            <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>We review documents to ensure authenticity for students.</Text>
            <View style={styles.docCards}>
              {[
                { label: mentorType === 'professional' ? 'Company ID / Offer Letter' : 'College ID Card', icon: 'credit-card' as const, required: true },
                { label: 'Government Photo ID', icon: 'shield' as const, required: true },
              ].map(d => (
                <TouchableOpacity key={d.label} style={[styles.docCard, { backgroundColor: colors.card, borderColor: colors.border }]} activeOpacity={0.8}>
                  <View style={[styles.docIcon, { backgroundColor: colors.tealLight }]}>
                    <Feather name={d.icon} size={22} color={colors.primary} />
                  </View>
                  <View style={styles.docInfo}>
                    <Text style={[styles.docLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{d.label}</Text>
                    <Text style={[styles.docHint, { color: colors.mutedForeground }]}>Tap to upload · JPG, PNG or PDF</Text>
                  </View>
                  <Feather name="upload" size={18} color={colors.primary} />
                </TouchableOpacity>
              ))}
            </View>
            <View style={[styles.infoBox, { backgroundColor: colors.tealLight }]}>
              <Feather name="lock" size={14} color={colors.primary} />
              <Text style={[styles.infoText, { color: colors.primary, fontFamily: 'Inter_400Regular' }]}>Your documents are encrypted and never shared with students. Used only for one-time verification.</Text>
            </View>
            <TouchableOpacity style={[styles.nextBtn, { backgroundColor: colors.primary }]} onPress={handleNext} activeOpacity={0.85}>
              <Text style={[styles.nextBtnText, { color: colors.primaryForeground, fontFamily: 'Inter_700Bold' }]}>Continue</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* STEP 4 — Rates */}
        {step === 4 && (
          <View style={styles.stepWrap}>
            <Text style={[styles.stepTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Set your{'\n'}rates</Text>
            <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>You can change this anytime from your dashboard.</Text>
            <View style={[styles.rateCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.rateLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>Per-minute rate (₹)</Text>
              <View style={styles.rateRow}>
                <TouchableOpacity onPress={() => setRate(r => String(Math.max(5, Number(r) - 5)))} style={[styles.rateBtn, { backgroundColor: colors.muted }]}>
                  <Feather name="minus" size={18} color={colors.foreground} />
                </TouchableOpacity>
                <View style={[styles.rateDisplay, { backgroundColor: colors.tealLight }]}>
                  <Text style={[styles.rateValue, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>₹{rate}/min</Text>
                </View>
                <TouchableOpacity onPress={() => setRate(r => String(Number(r) + 5))} style={[styles.rateBtn, { backgroundColor: colors.muted }]}>
                  <Feather name="plus" size={18} color={colors.foreground} />
                </TouchableOpacity>
              </View>
            </View>
            <TouchableOpacity
              style={[styles.toggleRow, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => setChatTrialEnabled(v => !v)} activeOpacity={0.8}
            >
              <View>
                <Text style={[styles.toggleLabel, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>Free 5-min chat trial</Text>
                <Text style={[styles.toggleDesc, { color: colors.mutedForeground }]}>Let students try before committing</Text>
              </View>
              <View style={[styles.toggle, { backgroundColor: chatTrialEnabled ? colors.primary : colors.muted }]}>
                <View style={[styles.toggleThumb, { transform: [{ translateX: chatTrialEnabled ? 20 : 2 }] }]} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.nextBtn, { backgroundColor: colors.primary }]} onPress={handleNext} activeOpacity={0.85}>
              <Text style={[styles.nextBtnText, { color: colors.primaryForeground, fontFamily: 'Inter_700Bold' }]}>Submit for Review</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* STEP 5 — Success */}
        {step === 5 && (
          <View style={[styles.stepWrap, styles.successWrap]}>
            <View style={[styles.successIcon, { backgroundColor: colors.tealLight }]}>
              <Feather name="check-circle" size={56} color={colors.primary} />
            </View>
            <Text style={[styles.stepTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold', textAlign: 'center' }]}>Application{'\n'}Submitted!</Text>
            <Text style={[styles.stepSub, { color: colors.mutedForeground, textAlign: 'center' }]}>
              Our team is reviewing your profile. This typically takes 24–48 hours. You'll be notified once approved.
            </Text>
            <View style={[styles.pendingBadge, { backgroundColor: colors.amberLight }]}>
              <Feather name="clock" size={14} color={colors.amber} />
              <Text style={[styles.pendingText, { color: colors.amber, fontFamily: 'Inter_600SemiBold' }]}>Verification Pending</Text>
            </View>
            <TouchableOpacity style={[styles.nextBtn, { backgroundColor: colors.primary, marginTop: 32 }]} onPress={handleFinish} activeOpacity={0.85}>
              <Text style={[styles.nextBtnText, { color: colors.primaryForeground, fontFamily: 'Inter_700Bold' }]}>Go to Dashboard</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, marginBottom: 24 },
  backBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  progressBar: { flex: 1, height: 6, borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
  stepLabel: { fontSize: 13 },
  scroll: { paddingHorizontal: 20, paddingBottom: 60 },
  stepWrap: { gap: 20 },
  stepTitle: { fontSize: 26, lineHeight: 36 },
  stepSub: { fontSize: 14, lineHeight: 22, marginTop: -12 },
  typeCards: { gap: 14 },
  typeCard: { borderWidth: 2, borderRadius: 20, padding: 20, position: 'relative' },
  typeCardTitle: { fontSize: 17, marginTop: 10, marginBottom: 6 },
  typeCardDesc: { fontSize: 13, lineHeight: 20 },
  radioCheck: { position: 'absolute', top: 16, right: 16, width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  nextBtn: { borderRadius: 18, paddingVertical: 16, alignItems: 'center', marginTop: 8 },
  nextBtnText: { fontSize: 16 },
  fields: { gap: 18 },
  fieldLabel: { fontSize: 14, marginBottom: 8 },
  input: { borderWidth: 1.5, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, fontSize: 15 },
  docCards: { gap: 12 },
  docCard: { flexDirection: 'row', alignItems: 'center', gap: 14, borderWidth: 1, borderRadius: 16, padding: 16 },
  docIcon: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  docInfo: { flex: 1 },
  docLabel: { fontSize: 14, marginBottom: 3 },
  docHint: { fontSize: 12 },
  infoBox: { flexDirection: 'row', gap: 10, padding: 14, borderRadius: 14, alignItems: 'flex-start' },
  infoText: { flex: 1, fontSize: 13, lineHeight: 20 },
  rateCard: { borderWidth: 1, borderRadius: 18, padding: 20, gap: 16 },
  rateLabel: { fontSize: 15 },
  rateRow: { flexDirection: 'row', alignItems: 'center', gap: 16, justifyContent: 'center' },
  rateBtn: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  rateDisplay: { paddingHorizontal: 32, paddingVertical: 12, borderRadius: 14, minWidth: 130, alignItems: 'center' },
  rateValue: { fontSize: 22 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderRadius: 18, padding: 18 },
  toggleLabel: { fontSize: 15, marginBottom: 4 },
  toggleDesc: { fontSize: 13 },
  toggle: { width: 46, height: 26, borderRadius: 13, justifyContent: 'center' },
  toggleThumb: { width: 22, height: 22, borderRadius: 11, backgroundColor: '#fff' },
  successWrap: { alignItems: 'center', paddingTop: 40 },
  successIcon: { width: 110, height: 110, borderRadius: 55, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  pendingBadge: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 30, alignItems: 'center' },
  pendingText: { fontSize: 14 },
});
