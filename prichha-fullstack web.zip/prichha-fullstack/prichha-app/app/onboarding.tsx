import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';

export default function OnboardingScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16) }]}>
      {/* Illustration */}
      <View style={styles.illustrationWrap}>
        <View style={[styles.glowRing, { backgroundColor: colors.primary + '18' }]} />
        <View style={[styles.glowRingInner, { backgroundColor: colors.accent + '12' }]} />
        <View style={[styles.iconCircle, { backgroundColor: colors.card }]}>
          <Feather name="award" size={68} color={colors.primary} />
        </View>
        <View style={[styles.decDot1, { backgroundColor: colors.accent + '80' }]} />
        <View style={[styles.decDot2, { backgroundColor: colors.primary + '50' }]} />
        <View style={[styles.decDot3, { backgroundColor: colors.amber + '60' }]} />
      </View>

      <View style={styles.textBlock}>
        <Text style={[styles.headline, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>
          Your dream college{'\n'}& jobs, guided by{'\n'}someone who's{'\n'}been there.
        </Text>
        <Text style={[styles.sub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
          Talk to real seniors from your target college and industry professionals who've walked the exact path you're on.
        </Text>
      </View>

      <View style={[styles.footer, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20) }]}>
        <TouchableOpacity
          style={[styles.btn, { backgroundColor: colors.primary }]}
          onPress={() => router.push('/role-select')}
          activeOpacity={0.85}
        >
          <Text style={[styles.btnText, { color: colors.primaryForeground, fontFamily: 'Inter_700Bold' }]}>Get Started</Text>
          <Feather name="arrow-right" size={18} color={colors.primaryForeground} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 24 },
  illustrationWrap: { alignItems: 'center', justifyContent: 'center', height: 260, position: 'relative', marginBottom: 16 },
  glowRing: { position: 'absolute', width: 240, height: 240, borderRadius: 120 },
  glowRingInner: { position: 'absolute', width: 180, height: 180, borderRadius: 90 },
  iconCircle: {
    width: 160, height: 160, borderRadius: 80,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1, shadowRadius: 24, elevation: 10,
  },
  decDot1: { position: 'absolute', top: 28, right: 28, width: 36, height: 36, borderRadius: 18 },
  decDot2: { position: 'absolute', bottom: 24, left: 24, width: 50, height: 50, borderRadius: 25 },
  decDot3: { position: 'absolute', top: 48, left: 40, width: 20, height: 20, borderRadius: 10 },
  textBlock: { flex: 1 },
  headline: { fontSize: 28, lineHeight: 40, marginBottom: 14 },
  sub: { fontSize: 15, lineHeight: 24 },
  footer: {},
  btn: { borderRadius: 20, paddingVertical: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  btnText: { fontSize: 17 },
});
