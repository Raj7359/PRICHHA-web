import { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Platform, Alert, ActivityIndicator } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useBookSession } from '@/hooks/useSessions';
import { ApiError } from '@/lib/api';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

type SessionTypeId = 'CHAT' | 'AUDIO' | 'VIDEO';

const DATES = ['Today', 'Tomorrow', 'Wed', 'Thu', 'Fri'];
const TIME_SLOTS = ['9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM', '4:00 PM', '6:00 PM', '7:00 PM'];

export default function BookingScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ expertId?: string; expertName?: string; rate?: string; type?: SessionTypeId }>();
  const bookMutation = useBookSession();

  const baseRate = Number(params.rate) || 10;
  const SESSION_TYPES: { id: SessionTypeId; label: string; icon: 'message-circle' | 'phone' | 'video'; rate: number; desc: string }[] = [
    { id: 'CHAT', label: 'Chat', icon: 'message-circle', rate: baseRate, desc: 'Text messaging session' },
    { id: 'AUDIO', label: 'Audio Call', icon: 'phone', rate: baseRate, desc: 'Voice call session' },
    { id: 'VIDEO', label: 'Video Call', icon: 'video', rate: Math.round(baseRate * 1.3), desc: 'Face-to-face video session' },
  ];

  const [sessionType, setSessionType] = useState<SessionTypeId>(params.type || 'AUDIO');
  const [selectedDateIdx, setSelectedDateIdx] = useState(0);
  const [selectedSlot, setSelectedSlot] = useState('');

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);
  const bottomPad = insets.bottom + (Platform.OS === 'web' ? 34 : 0);
  const selected = SESSION_TYPES.find(s => s.id === sessionType)!;

  function slotToDate(dateIdx: number, slot: string): Date {
    const [time, meridian] = slot.split(' ');
    let [hours, minutes] = time.split(':').map(Number);
    if (meridian === 'PM' && hours !== 12) hours += 12;
    if (meridian === 'AM' && hours === 12) hours = 0;
    const d = new Date();
    d.setDate(d.getDate() + dateIdx);
    d.setHours(hours, minutes, 0, 0);
    return d;
  }

  const handleBook = async () => {
    if (!params.expertId) {
      Alert.alert('Missing expert', 'Please book from a mentor or professional profile.');
      return;
    }
    try {
      const session = await bookMutation.mutateAsync({
        expertId: params.expertId,
        type: sessionType,
        ratePerMin: selected.rate,
        scheduledAt: slotToDate(selectedDateIdx, selectedSlot).toISOString(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      if (sessionType === 'AUDIO' || sessionType === 'VIDEO') {
        Alert.alert(
          'Booked!',
          `Your ${selected.label.toLowerCase()} with ${params.expertName || 'the expert'} is confirmed for ${DATES[selectedDateIdx]}, ${selectedSlot}.`,
          [
            { text: 'Later', style: 'cancel', onPress: () => router.back() },
            {
              text: 'Join Now',
              onPress: () =>
                router.replace({
                  pathname: '/call/[sessionId]',
                  params: { sessionId: session.id, expertName: params.expertName, type: sessionType },
                }),
            },
          ]
        );
      } else {
        Alert.alert('Booked!', `Your chat with ${params.expertName || 'the expert'} is confirmed for ${DATES[selectedDateIdx]}, ${selectedSlot}.`, [
          { text: 'OK', onPress: () => router.back() },
        ]);
      }
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Could not book this session. Please try again.';
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Booking failed', message);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.background }]}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="x" size={18} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Book a Session</Text>
        <View style={{ width: 40 }} />
      </View>

      {params.expertName && (
        <Text style={[styles.expertLine, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>
          with {params.expertName}
        </Text>
      )}

      <ScrollView contentContainerStyle={{ padding: 20, gap: 24, paddingBottom: 120 }} showsVerticalScrollIndicator={false}>
        {/* Session type */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Session Type</Text>
          <View style={styles.typeGrid}>
            {SESSION_TYPES.map(t => (
              <TouchableOpacity
                key={t.id}
                style={[styles.typeCard, { backgroundColor: sessionType === t.id ? colors.tealLight : colors.card, borderColor: sessionType === t.id ? colors.primary : colors.border }]}
                onPress={() => setSessionType(t.id)}
                activeOpacity={0.8}
              >
                <View style={[styles.typeIcon, { backgroundColor: sessionType === t.id ? colors.primary : colors.muted }]}>
                  <Feather name={t.icon} size={18} color={sessionType === t.id ? '#fff' : colors.mutedForeground} />
                </View>
                <Text style={[styles.typeLabel, { color: sessionType === t.id ? colors.primary : colors.foreground, fontFamily: 'Inter_700Bold' }]}>{t.label}</Text>
                <Text style={[styles.typeRate, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>₹{t.rate}/min</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Date selection */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Select Date</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
            {DATES.map((d, i) => (
              <TouchableOpacity
                key={d}
                style={[styles.dateChip, { backgroundColor: selectedDateIdx === i ? colors.primary : colors.card, borderColor: selectedDateIdx === i ? colors.primary : colors.border }]}
                onPress={() => setSelectedDateIdx(i)}
                activeOpacity={0.8}
              >
                <Text style={[styles.dateChipText, { color: selectedDateIdx === i ? '#fff' : colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{d}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Time slots */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Available Slots</Text>
          <View style={styles.slotsGrid}>
            {TIME_SLOTS.map(slot => (
              <TouchableOpacity
                key={slot}
                style={[styles.slot, { backgroundColor: selectedSlot === slot ? colors.primary : colors.card, borderColor: selectedSlot === slot ? colors.primary : colors.border }]}
                onPress={() => setSelectedSlot(slot)}
                activeOpacity={0.8}
              >
                <Text style={[styles.slotText, { color: selectedSlot === slot ? '#fff' : colors.foreground, fontFamily: 'Inter_500Medium' }]}>{slot}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Summary */}
        {selectedSlot && (
          <View style={[styles.summary, { backgroundColor: colors.tealLight, borderColor: colors.primary }]}>
            <Text style={[styles.summaryTitle, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>Booking Summary</Text>
            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Session</Text>
              <Text style={[styles.summaryValue, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{selected.label}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Date & Time</Text>
              <Text style={[styles.summaryValue, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{DATES[selectedDateIdx]}, {selectedSlot}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Rate</Text>
              <Text style={[styles.summaryValue, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>₹{selected.rate}/min</Text>
            </View>
          </View>
        )}
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: selectedSlot ? colors.primary : colors.muted }]}
          onPress={handleBook}
          disabled={!selectedSlot || bookMutation.isPending}
          activeOpacity={0.85}
        >
          {bookMutation.isPending ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={[styles.bookBtnText, { color: selectedSlot ? '#fff' : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>
              {selectedSlot ? `Confirm Booking · ${DATES[selectedDateIdx]} ${selectedSlot}` : 'Select a time slot'}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 4 },
  backBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  title: { fontSize: 18 },
  expertLine: { fontSize: 13, textAlign: 'center', marginBottom: 12 },
  sectionLabel: { fontSize: 16, marginBottom: 14 },
  typeGrid: { flexDirection: 'row', gap: 10 },
  typeCard: { flex: 1, borderWidth: 1.5, borderRadius: 18, padding: 14, alignItems: 'center', gap: 8 },
  typeIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  typeLabel: { fontSize: 13 },
  typeRate: { fontSize: 12 },
  dateChip: { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 20, borderWidth: 1.5 },
  dateChipText: { fontSize: 13 },
  slotsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  slot: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, borderWidth: 1.5 },
  slotText: { fontSize: 13 },
  summary: { borderWidth: 1.5, borderRadius: 18, padding: 18, gap: 12 },
  summaryTitle: { fontSize: 15, marginBottom: 4 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between' },
  summaryLabel: { fontSize: 14 },
  summaryValue: { fontSize: 14 },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, paddingTop: 14, borderTopWidth: 1 },
  bookBtn: { borderRadius: 16, paddingVertical: 16, alignItems: 'center' },
  bookBtnText: { fontSize: 15 },
});
