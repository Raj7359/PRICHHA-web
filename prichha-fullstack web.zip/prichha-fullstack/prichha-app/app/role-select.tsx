import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { Feather } from '@expo/vector-icons';

export default function RoleSelectScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { setRole } = useApp();

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16) }]}>
      <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="chevron-left" size={22} color={colors.foreground} />
      </TouchableOpacity>

      <Text style={[styles.heading, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>
        How do you want{'\n'}to continue today?
      </Text>
      <Text style={[styles.sub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
        Choose your role to get the right experience.
      </Text>

      <View style={styles.cards}>
        {/* Student */}
        <TouchableOpacity
          style={[styles.card, { backgroundColor: colors.tealLight, borderColor: colors.primary, borderWidth: 2 }]}
          onPress={() => { setRole('student'); router.push('/auth'); }}
          activeOpacity={0.85}
        >
          <View style={[styles.iconCircle, { backgroundColor: colors.card }]}>
            <Feather name="book-open" size={26} color={colors.primary} />
          </View>
          <Text style={[styles.cardTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Student / Aspirant</Text>
          <Text style={[styles.cardDesc, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
            Explore colleges, connect with seniors and professionals, book calls or chats.
          </Text>
          <View style={[styles.checkBadge, { backgroundColor: colors.primary }]}>
            <Feather name="check" size={13} color="#fff" />
          </View>
        </TouchableOpacity>

        {/* Advisor / Mentor */}
        <TouchableOpacity
          style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1.5 }]}
          onPress={() => router.push('/advisor-onboarding')}
          activeOpacity={0.85}
        >
          <View style={styles.advisorHeader}>
            <View style={[styles.iconCircle, { backgroundColor: colors.coralLight }]}>
              <Feather name="star" size={26} color={colors.accent} />
            </View>
            <View style={styles.badgePills}>
              <View style={[styles.pill, { backgroundColor: colors.tealLight }]}>
                <Text style={[styles.pillText, { color: colors.primary }]}>College Senior</Text>
              </View>
              <View style={[styles.pill, { backgroundColor: colors.amberLight }]}>
                <Text style={[styles.pillText, { color: colors.amber }]}>Industry Expert</Text>
              </View>
            </View>
          </View>
          <Text style={[styles.cardTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Join as Advisor / Mentor</Text>
          <Text style={[styles.cardDesc, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
            Guide students, share campus or industry insights, set your per-minute rates, and start earning.
          </Text>
          <View style={[styles.checkBadge, { backgroundColor: colors.accent }]}>
            <Feather name="chevron-right" size={13} color="#fff" />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 20 },
  backBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 28, borderWidth: 1, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  heading: { fontSize: 26, lineHeight: 36, marginBottom: 8 },
  sub: { fontSize: 15, marginBottom: 28 },
  cards: { gap: 16 },
  card: { borderRadius: 24, padding: 22, position: 'relative' },
  advisorHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 14 },
  iconCircle: { width: 54, height: 54, borderRadius: 27, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  cardTitle: { fontSize: 19, marginBottom: 8 },
  cardDesc: { fontSize: 13, lineHeight: 20, paddingRight: 20 },
  checkBadge: { position: 'absolute', top: 22, right: 22, width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  badgePills: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', gap: 6, paddingTop: 6 },
  pill: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  pillText: { fontSize: 11, fontWeight: '700', fontFamily: 'Inter_700Bold' },
});
