import { View, Text, FlatList, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';

const NOTIFS = [
  { id: '1', icon: 'message-circle' as const, color: 'primary', title: 'New message from Priya Singh', sub: 'Sure! Let me share my study plan...', time: '2 min ago', unread: true },
  { id: '2', icon: 'calendar' as const, color: 'amber', title: 'Session reminder', sub: 'Audio call with Rahul Sharma in 30 mins', time: '28 min ago', unread: true },
  { id: '3', icon: 'star' as const, color: 'amber', title: 'Leave a review', sub: 'How was your session with Priya?', time: '3 hrs ago', unread: false },
  { id: '4', icon: 'check-circle' as const, color: 'success', title: 'Booking confirmed', sub: 'Video call with Vikram Nair on Jul 29 at 4:00 PM', time: 'Yesterday', unread: false },
  { id: '5', icon: 'plus-circle' as const, color: 'success', title: '₹500 added to wallet', sub: 'UPI payment successful via GPay', time: 'Yesterday', unread: false },
  { id: '6', icon: 'user-check' as const, color: 'primary', title: 'New mentor joined', sub: 'Sneha Gupta from IIT Delhi is now available', time: 'Jul 24', unread: false },
];

export default function NotificationsScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const getColor = (c: string) => c === 'primary' ? colors.primary : c === 'amber' ? colors.amber : colors.success;
  const getBg = (c: string) => c === 'primary' ? colors.tealLight : c === 'amber' ? colors.amberLight : colors.successLight;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 16 }]}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="chevron-left" size={20} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Notifications</Text>
        <TouchableOpacity>
          <Text style={[styles.markAll, { color: colors.primary, fontFamily: 'Inter_500Medium' }]}>Mark all read</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={NOTIFS}
        keyExtractor={n => n.id}
        contentContainerStyle={{ paddingHorizontal: 20, gap: 10, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity style={[styles.notifCard, { backgroundColor: item.unread ? colors.tealLight + '50' : colors.card, borderColor: item.unread ? colors.primary + '30' : colors.border }]} activeOpacity={0.8}>
            <View style={[styles.notifIcon, { backgroundColor: getBg(item.color) }]}>
              <Feather name={item.icon} size={18} color={getColor(item.color)} />
            </View>
            <View style={styles.notifInfo}>
              <Text style={[styles.notifTitle, { color: colors.foreground, fontFamily: item.unread ? 'Inter_700Bold' : 'Inter_500Medium' }]}>{item.title}</Text>
              <Text style={[styles.notifSub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]} numberOfLines={1}>{item.sub}</Text>
              <Text style={[styles.notifTime, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{item.time}</Text>
            </View>
            {item.unread && <View style={[styles.unreadDot, { backgroundColor: colors.primary }]} />}
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="bell-off" size={44} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }]}>No notifications yet</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 20, paddingBottom: 16 },
  backBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  title: { flex: 1, fontSize: 22 },
  markAll: { fontSize: 14 },
  notifCard: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16, borderRadius: 18, borderWidth: 1 },
  notifIcon: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  notifInfo: { flex: 1, gap: 3 },
  notifTitle: { fontSize: 14 },
  notifSub: { fontSize: 13 },
  notifTime: { fontSize: 12, marginTop: 2 },
  unreadDot: { width: 9, height: 9, borderRadius: 4.5, flexShrink: 0 },
  empty: { alignItems: 'center', paddingTop: 80, gap: 12 },
  emptyText: { fontSize: 15 },
});
