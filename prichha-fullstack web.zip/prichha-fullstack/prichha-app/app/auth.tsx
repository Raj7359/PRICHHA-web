import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { ApiError } from '@/lib/api';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

export default function AuthScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { login, signup } = useApp();

  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isValid = mode === 'login'
    ? email.includes('@') && password.length >= 6
    : name.trim().length >= 2 && email.includes('@') && password.length >= 6;

  const handleSubmit = async () => {
    if (!isValid || loading) return;
    setError('');
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(email.trim(), password);
      } else {
        await signup(name.trim(), email.trim(), password);
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace('/(tabs)');
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Something went wrong. Please try again.';
      setError(message);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16) }]}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="chevron-left" size={20} color={colors.foreground} />
        </TouchableOpacity>

        <View style={styles.content}>
          <View style={[styles.iconWrap, { backgroundColor: colors.tealLight }]}>
            <Feather name={mode === 'login' ? 'log-in' : 'user-plus'} size={32} color={colors.primary} />
          </View>
          <Text style={[styles.title, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>
            {mode === 'login' ? 'Welcome back' : 'Create your\naccount'}
          </Text>
          <Text style={[styles.sub, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
            {mode === 'login' ? 'Log in to continue to Prichha.' : 'Sign up to start connecting with mentors.'}
          </Text>

          {mode === 'signup' && (
            <View style={[styles.inputRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
              <Feather name="user" size={16} color={colors.mutedForeground} style={styles.inputIcon} />
              <TextInput
                value={name}
                onChangeText={setName}
                placeholder="Full name"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.input, { color: colors.foreground, fontFamily: 'Inter_400Regular' }]}
                autoCapitalize="words"
              />
            </View>
          )}

          <View style={[styles.inputRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <Feather name="mail" size={16} color={colors.mutedForeground} style={styles.inputIcon} />
            <TextInput
              value={email}
              onChangeText={setEmail}
              placeholder="Email address"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="email-address"
              autoCapitalize="none"
              style={[styles.input, { color: colors.foreground, fontFamily: 'Inter_400Regular' }]}
            />
          </View>

          <View style={[styles.inputRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <Feather name="lock" size={16} color={colors.mutedForeground} style={styles.inputIcon} />
            <TextInput
              value={password}
              onChangeText={setPassword}
              placeholder="Password (min 6 characters)"
              placeholderTextColor={colors.mutedForeground}
              secureTextEntry
              style={[styles.input, { color: colors.foreground, fontFamily: 'Inter_400Regular' }]}
            />
          </View>

          {!!error && (
            <Text style={[styles.error, { color: colors.destructive ?? '#DC2626', fontFamily: 'Inter_500Medium' }]}>{error}</Text>
          )}

          <TouchableOpacity
            style={[styles.btn, { backgroundColor: isValid ? colors.primary : colors.muted }]}
            onPress={handleSubmit}
            disabled={!isValid || loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color={colors.primaryForeground} />
            ) : (
              <Text style={[styles.btnText, { color: isValid ? colors.primaryForeground : colors.mutedForeground, fontFamily: 'Inter_700Bold' }]}>
                {mode === 'login' ? 'Log In' : 'Sign Up'}
              </Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={styles.switchMode} onPress={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }}>
            <Text style={[styles.switchModeText, { color: colors.primary, fontFamily: 'Inter_500Medium' }]}>
              {mode === 'login' ? "Don't have an account? Sign up" : 'Already have an account? Log in'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 24 },
  backBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', borderWidth: 1, marginBottom: 32, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  content: { gap: 16 },
  iconWrap: { width: 70, height: 70, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 26, lineHeight: 36 },
  sub: { fontSize: 14, lineHeight: 22, marginTop: -8, marginBottom: 4 },
  inputRow: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 16, paddingHorizontal: 16 },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 15, paddingVertical: 16 },
  error: { fontSize: 13, marginTop: -4 },
  btn: { borderRadius: 18, paddingVertical: 17, alignItems: 'center', marginTop: 8 },
  btnText: { fontSize: 16 },
  switchMode: { alignItems: 'center', paddingVertical: 8 },
  switchModeText: { fontSize: 14 },
});
