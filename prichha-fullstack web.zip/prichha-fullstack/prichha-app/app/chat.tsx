import { useState, useRef, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, Image, ActivityIndicator } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useSessions, useBookSession } from '@/hooks/useSessions';
import { useMessages, useSendMessage } from '@/hooks/useMessages';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

export default function ChatScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useApp();
  const params = useLocalSearchParams<{ expertId?: string; expertName?: string; rate?: string; sessionId?: string }>();

  const [sessionId, setSessionId] = useState<string | undefined>(params.sessionId);
  const [settingUp, setSettingUp] = useState(!params.sessionId);
  const [input, setInput] = useState('');
  const listRef = useRef<FlatList>(null);

  const { data: existingSessions } = useSessions();
  const bookMutation = useBookSession();
  const { data: messages, isLoading: messagesLoading } = useMessages(sessionId);
  const sendMutation = useSendMessage(sessionId);

  // If we arrived from a profile (expertId, no sessionId yet), reuse an existing
  // chat session with that expert if one exists, otherwise create one.
  useEffect(() => {
    if (sessionId || !params.expertId) return;
    const reuse = existingSessions?.find(s => s.expertId === params.expertId && s.type === 'CHAT');
    if (reuse) {
      setSessionId(reuse.id);
      setSettingUp(false);
      return;
    }
    if (existingSessions === undefined) return; // still loading
    bookMutation
      .mutateAsync({
        expertId: params.expertId,
        type: 'CHAT',
        ratePerMin: Number(params.rate) || 0,
        scheduledAt: new Date().toISOString(),
      })
      .then(session => {
        setSessionId(session.id);
        setSettingUp(false);
      })
      .catch(() => setSettingUp(false));
  }, [existingSessions, params.expertId, sessionId]);

  const sendMessage = () => {
    if (!input.trim() || !sessionId) return;
    const text = input.trim();
    setInput('');
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    sendMutation.mutate(text);
  };

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);
  const bottomPad = insets.bottom + (Platform.OS === 'web' ? 34 : 0);

  if (settingUp || (sessionId && messagesLoading && !messages)) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (!sessionId) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }}>Couldn't start this chat.</Text>
        <TouchableOpacity onPress={() => router.back()} style={{ marginTop: 12 }}>
          <Text style={{ color: colors.primary, fontFamily: 'Inter_600SemiBold' }}>Go back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Newest-first for FlatList `inverted` rendering.
  const inverted = [...(messages ?? [])].reverse();

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { paddingTop: topPad + 12, backgroundColor: colors.card, borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Feather name="chevron-left" size={22} color={colors.foreground} />
          </TouchableOpacity>
          <Image source={{ uri: 'https://i.pravatar.cc/100?img=5' }} style={styles.headerAvatar} />
          <View style={styles.headerInfo}>
            <Text style={[styles.headerName, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>{params.expertName || 'Chat'}</Text>
            <Text style={[styles.headerStatus, { color: colors.success, fontFamily: 'Inter_400Regular' }]}>Online</Text>
          </View>
        </View>

        <FlatList
          ref={listRef}
          data={inverted}
          keyExtractor={m => m.id}
          inverted
          contentContainerStyle={{ padding: 16, gap: 10 }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={{ color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }}>Say hi to start the conversation.</Text>
            </View>
          }
          renderItem={({ item }) => {
            const fromMe = item.senderId === user?.id;
            return (
              <View style={[styles.bubbleRow, fromMe ? styles.bubbleRowMe : styles.bubbleRowThem]}>
                <View style={[styles.bubble, { backgroundColor: fromMe ? colors.primary : colors.card, borderColor: colors.border }, fromMe && { borderWidth: 0 }]}>
                  <Text style={[styles.bubbleText, { color: fromMe ? '#fff' : colors.foreground, fontFamily: 'Inter_400Regular' }]}>{item.text}</Text>
                </View>
                <Text style={[styles.bubbleTime, { color: colors.mutedForeground }]}>
                  {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
            );
          }}
        />

        <View style={[styles.inputBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: bottomPad + 12 }]}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Type a message…"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { color: colors.foreground, backgroundColor: colors.muted, fontFamily: 'Inter_400Regular' }]}
            multiline
          />
          <TouchableOpacity
            style={[styles.sendBtn, { backgroundColor: input.trim() ? colors.primary : colors.muted }]}
            onPress={sendMessage}
            disabled={!input.trim() || sendMutation.isPending}
            activeOpacity={0.85}
          >
            <Feather name="send" size={18} color={input.trim() ? '#fff' : colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  backBtn: { padding: 4 },
  headerAvatar: { width: 38, height: 38, borderRadius: 19 },
  headerInfo: { flex: 1 },
  headerName: { fontSize: 15 },
  headerStatus: { fontSize: 12 },
  empty: { paddingTop: 80, alignItems: 'center' },
  bubbleRow: { maxWidth: '78%', gap: 3 },
  bubbleRowMe: { alignSelf: 'flex-end', alignItems: 'flex-end' },
  bubbleRowThem: { alignSelf: 'flex-start', alignItems: 'flex-start' },
  bubble: { borderRadius: 18, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10 },
  bubbleText: { fontSize: 14, lineHeight: 20 },
  bubbleTime: { fontSize: 10, marginHorizontal: 4 },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', gap: 10, padding: 12, borderTopWidth: 1 },
  input: { flex: 1, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 14, maxHeight: 100 },
  sendBtn: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
});
