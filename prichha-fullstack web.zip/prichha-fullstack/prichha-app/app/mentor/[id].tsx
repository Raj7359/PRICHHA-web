import { ScrollView, View, Text, Image, TouchableOpacity, StyleSheet, Platform, ActivityIndicator } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useMentor } from '@/hooks/useMentors';
import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

// Reviews aren't backed by a data model yet — a Review model + endpoints
// will be added in a follow-up pass once ratings/reviews are prioritized.
const REVIEWS = [
  { id: '1', name: 'Rahul V.', rating: 5, text: 'Gave me an extremely realistic picture of what campus life is like. The prep tips changed my approach completely.', type: 'Audio Call', date: 'Jul 20' },
  { id: '2', name: 'Sneha K.', rating: 5, text: 'Best session I have had. Explained everything clearly and patiently. Worth every rupee!', type: 'Chat', date: 'Jul 15' },
  { id: '3', name: 'Aditya M.', rating: 4, text: 'Very knowledgeable and would recommend to anyone targeting this college.', type: 'Video Call', date: 'Jul 10' },
];

export default function MentorProfileScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data: mentor, isLoading, isError } = useMentor(id);

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);
  const bottomPad = insets.bottom + (Platform.OS === 'web' ? 34 : 0);

  if (isLoading) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (isError || !mentor) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }}>Mentor not found.</Text>
        <TouchableOpacity onPress={() => router.back()} style={{ marginTop: 12 }}>
          <Text style={{ color: colors.primary, fontFamily: 'Inter_600SemiBold' }}>Go back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }} showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <LinearGradient colors={['#0D7C7A', '#16a098']} style={[styles.hero, { paddingTop: topPad + 16 }]}>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()} activeOpacity={0.8}>
            <Feather name="chevron-left" size={22} color="#fff" />
          </TouchableOpacity>
          <View style={styles.heroContent}>
            <View style={styles.avatarWrap}>
              <Image source={{ uri: mentor.avatarUrl || 'https://i.pravatar.cc/200?img=5' }} style={styles.avatar} />
              {mentor.online && <View style={[styles.onlineDot, { borderColor: '#0D7C7A' }]} />}
            </View>
            <Text style={[styles.heroName, { fontFamily: 'Inter_700Bold' }]}>{mentor.name}</Text>
            <Text style={[styles.heroCollege, { fontFamily: 'Inter_500Medium' }]}>{mentor.college} · {mentor.stream}</Text>
            <View style={styles.heroMeta}>
              <View style={styles.metaItem}>
                <Feather name="star" size={14} color="#FCD34D" />
                <Text style={styles.metaText}>{mentor.rating.toFixed(1)}</Text>
              </View>
              <View style={styles.metaDot} />
              <Text style={styles.metaText}>{mentor.sessions} sessions</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={{ padding: 20, gap: 20 }}>
          {/* Tags */}
          <View style={styles.tagsRow}>
            {mentor.tags.map(t => (
              <View key={t} style={[styles.tag, { backgroundColor: colors.tealLight }]}>
                <Text style={[styles.tagText, { color: colors.primary, fontFamily: 'Inter_500Medium' }]}>{t}</Text>
              </View>
            ))}
          </View>

          {/* About */}
          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>About</Text>
            <Text style={[styles.aboutText, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>
              {mentor.bio || `Hey! I'm ${mentor.name.split(' ')[0]}, studying ${mentor.stream} at ${mentor.college}. I've helped ${mentor.sessions}+ students with honest, practical advice about getting in and what campus life is really like.`}
            </Text>
          </View>

          {/* Pricing */}
          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold' }]}>Session Pricing</Text>
            {[
              { type: 'Chat', icon: 'message-circle' as const, price: `₹${mentor.rate}/min` },
              { type: 'Audio Call', icon: 'phone' as const, price: `₹${mentor.rate}/min` },
              { type: 'Video Call', icon: 'video' as const, price: `₹${Math.round(mentor.rate * 1.3)}/min` },
            ].map(s => (
              <View key={s.type} style={[styles.pricingRow, { borderTopColor: colors.border }]}>
                <View style={[styles.pricingIcon, { backgroundColor: colors.tealLight }]}>
                  <Feather name={s.icon} size={16} color={colors.primary} />
                </View>
                <View style={styles.pricingInfo}>
                  <Text style={[styles.pricingType, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{s.type}</Text>
                  <Text style={[styles.pricingPrice, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{s.price}</Text>
                </View>
              </View>
            ))}
          </View>

          {/* Reviews */}
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: 'Inter_700Bold', marginBottom: 14 }]}>Reviews</Text>
            <View style={{ gap: 12 }}>
              {REVIEWS.map(r => (
                <View key={r.id} style={[styles.reviewCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <View style={styles.reviewHeader}>
                    <Image source={{ uri: `https://i.pravatar.cc/60?img=${r.id}` }} style={styles.reviewAvatar} />
                    <View style={styles.reviewMeta}>
                      <Text style={[styles.reviewName, { color: colors.foreground, fontFamily: 'Inter_600SemiBold' }]}>{r.name}</Text>
                      <View style={styles.starsRow}>
                        {Array.from({ length: r.rating }).map((_, i) => <Feather key={i} name="star" size={11} color={colors.amber} />)}
                      </View>
                    </View>
                    <View style={styles.reviewRight}>
                      <View style={[styles.typeBadge, { backgroundColor: colors.tealLight }]}>
                        <Text style={[styles.typeBadgeText, { color: colors.primary, fontFamily: 'Inter_500Medium' }]}>{r.type}</Text>
                      </View>
                      <Text style={[styles.reviewDate, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{r.date}</Text>
                    </View>
                  </View>
                  <Text style={[styles.reviewText, { color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }]}>{r.text}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Sticky CTA */}
      <View style={[styles.ctaBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: bottomPad + 16 }]}>
        <TouchableOpacity style={[styles.ctaSecondary, { borderColor: colors.primary }]} onPress={() => router.push({ pathname: '/booking', params: { expertId: mentor.id, expertName: mentor.name, rate: String(mentor.rate), type: 'AUDIO' } })} activeOpacity={0.85}>
          <Feather name="phone" size={16} color={colors.primary} />
          <Text style={[styles.ctaSecondaryText, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>Audio</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.ctaSecondary, { borderColor: colors.primary }]} onPress={() => router.push({ pathname: '/booking', params: { expertId: mentor.id, expertName: mentor.name, rate: String(mentor.rate), type: 'VIDEO' } })} activeOpacity={0.85}>
          <Feather name="video" size={16} color={colors.primary} />
          <Text style={[styles.ctaSecondaryText, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>Video</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.ctaPrimary, { backgroundColor: colors.primary }]} onPress={() => router.push({ pathname: '/chat', params: { expertId: mentor.id, expertName: mentor.name, rate: String(mentor.rate) } })} activeOpacity={0.85}>
          <Feather name="message-circle" size={16} color="#fff" />
          <Text style={[styles.ctaPrimaryText, { fontFamily: 'Inter_700Bold' }]}>Message</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { alignItems: 'center', justifyContent: 'center' },
  hero: { paddingHorizontal: 20, paddingBottom: 28 },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  heroContent: { alignItems: 'center' },
  avatarWrap: { position: 'relative', marginBottom: 14 },
  avatar: { width: 90, height: 90, borderRadius: 45, borderWidth: 3, borderColor: 'rgba(255,255,255,0.5)' },
  onlineDot: { position: 'absolute', bottom: 4, right: 4, width: 16, height: 16, borderRadius: 8, backgroundColor: '#22C55E', borderWidth: 2.5 },
  heroName: { color: '#fff', fontSize: 24, marginBottom: 5 },
  heroCollege: { color: 'rgba(255,255,255,0.85)', fontSize: 14, marginBottom: 12 },
  heroMeta: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { color: 'rgba(255,255,255,0.85)', fontSize: 13 },
  metaDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.5)' },
  tagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tag: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  tagText: { fontSize: 12 },
  section: { borderRadius: 20, borderWidth: 1, padding: 18, gap: 14 },
  sectionTitle: { fontSize: 17 },
  aboutText: { fontSize: 14, lineHeight: 22 },
  pricingRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 14, borderTopWidth: 1 },
  pricingIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  pricingInfo: { flex: 1 },
  pricingType: { fontSize: 14, marginBottom: 2 },
  pricingPrice: { fontSize: 13 },
  freeBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  freeBadgeText: { fontSize: 10 },
  reviewCard: { borderRadius: 16, borderWidth: 1, padding: 16, gap: 10 },
  reviewHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  reviewAvatar: { width: 38, height: 38, borderRadius: 19 },
  reviewMeta: { flex: 1, gap: 3 },
  reviewName: { fontSize: 13 },
  starsRow: { flexDirection: 'row', gap: 2 },
  reviewRight: { alignItems: 'flex-end', gap: 4 },
  typeBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  typeBadgeText: { fontSize: 11 },
  reviewDate: { fontSize: 11 },
  reviewText: { fontSize: 13, lineHeight: 20 },
  ctaBar: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', gap: 10, padding: 16, paddingTop: 14, borderTopWidth: 1 },
  ctaSecondary: { flex: 0, flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1.5, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 13 },
  ctaSecondaryText: { fontSize: 14 },
  ctaPrimary: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 14, paddingVertical: 13 },
  ctaPrimaryText: { color: '#fff', fontSize: 15 },
});
