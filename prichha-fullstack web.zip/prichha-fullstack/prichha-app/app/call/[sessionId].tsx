import { useEffect, useRef, useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform, PermissionsAndroid, ActivityIndicator, Image } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useCallToken, useEndCall } from '@/hooks/useCall';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

// react-native-agora is a native module — it requires a custom dev client / EAS
// build (`npx expo prebuild` + `eas build`), it will NOT run inside Expo Go.
// The exact method surface below matches the react-native-agora v4.x API as
// documented by Agora; double check against your installed version if you
// bump it, since native SDK APIs sometimes shift between minor releases.
import {
  createAgoraRtcEngine,
  ChannelProfileType,
  ClientRoleType,
  RtcSurfaceView,
  IRtcEngine,
  IRtcEngineEventHandler,
} from 'react-native-agora';

async function requestAndroidPermissions() {
  if (Platform.OS !== 'android') return true;
  const granted = await PermissionsAndroid.requestMultiple([
    PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    PermissionsAndroid.PERMISSIONS.CAMERA,
  ]);
  return (
    granted[PermissionsAndroid.PERMISSIONS.RECORD_AUDIO] === PermissionsAndroid.RESULTS.GRANTED &&
    granted[PermissionsAndroid.PERMISSIONS.CAMERA] === PermissionsAndroid.RESULTS.GRANTED
  );
}

function formatDuration(sec: number) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export default function CallScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ sessionId: string; expertName?: string; type?: 'AUDIO' | 'VIDEO' }>();

  const tokenMutation = useCallToken();
  const endCallMutation = useEndCall();
  const engineRef = useRef<IRtcEngine | null>(null);

  const [status, setStatus] = useState<'permission' | 'connecting' | 'connected' | 'error'>('permission');
  const [errorMessage, setErrorMessage] = useState('');
  const [isVideo, setIsVideo] = useState(params.type === 'VIDEO');
  const [remoteUid, setRemoteUid] = useState<number | null>(null);
  const [localUid, setLocalUid] = useState<number | null>(null);
  const [muted, setMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const endingRef = useRef(false);

  useEffect(() => {
    let cancelled = false;

    async function setup() {
      const ok = await requestAndroidPermissions();
      if (!ok) {
        setStatus('error');
        setErrorMessage('Camera and microphone permissions are required to join this call.');
        return;
      }
      setStatus('connecting');

      try {
        const data = await tokenMutation.mutateAsync(params.sessionId);
        if (cancelled) return;
        setIsVideo(data.video);

        const engine = createAgoraRtcEngine();
        engineRef.current = engine;
        engine.initialize({ appId: data.appId, channelProfile: ChannelProfileType.ChannelProfileCommunication });

        if (data.video) {
          engine.enableVideo();
          engine.startPreview();
        } else {
          engine.enableAudio();
          engine.disableVideo();
        }

        const handler: IRtcEngineEventHandler = {
          onJoinChannelSuccess: (_conn, uid) => {
            setLocalUid(uid);
            setStatus('connected');
          },
          onUserJoined: (_conn, uid) => setRemoteUid(uid),
          onUserOffline: (_conn, uid) => {
            setRemoteUid((current) => (current === uid ? null : current));
          },
          onError: (err) => {
            setStatus('error');
            setErrorMessage(`Call error (code ${err}). Please try again.`);
          },
        };
        engine.registerEventHandler(handler);

        engine.joinChannel(data.token, data.channel, data.uid, {
          clientRoleType: ClientRoleType.ClientRoleBroadcaster,
        });
      } catch (e: any) {
        if (!cancelled) {
          setStatus('error');
          setErrorMessage(e?.message || 'Could not start the call. Please try again.');
        }
      }
    }

    setup();

    return () => {
      cancelled = true;
      const engine = engineRef.current;
      if (engine) {
        engine.leaveChannel();
        engine.unregisterEventHandler({} as IRtcEngineEventHandler);
        engine.release();
        engineRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.sessionId]);

  // Call duration ticker (client-side display only — billing is computed
  // server-side from startedAt/endedAt in /api/calls/:sessionId/end).
  useEffect(() => {
    if (status !== 'connected') return;
    const interval = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(interval);
  }, [status]);

  const handleEndCall = useCallback(async () => {
    if (endingRef.current) return;
    endingRef.current = true;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const engine = engineRef.current;
    if (engine) {
      engine.leaveChannel();
    }
    try {
      await endCallMutation.mutateAsync(params.sessionId);
    } catch {
      // Best-effort — even if this fails the server will still have accurate
      // startedAt data and the session can be reconciled later.
    }
    router.back();
  }, [params.sessionId]);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    engineRef.current?.muteLocalAudioStream(next);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const toggleCamera = () => {
    const next = !cameraOff;
    setCameraOff(next);
    engineRef.current?.muteLocalVideoStream(next);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const flipCamera = () => {
    engineRef.current?.switchCamera();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const topPad = insets.top + (Platform.OS === 'web' ? 24 : 16);
  const bottomPad = insets.bottom + 24;

  if (status === 'permission' || status === 'connecting') {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: '#0B1220' }]}>
        <ActivityIndicator color="#fff" size="large" />
        <Text style={styles.statusText}>{status === 'permission' ? 'Checking permissions…' : 'Connecting…'}</Text>
      </View>
    );
  }

  if (status === 'error') {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: '#0B1220', padding: 24 }]}>
        <Feather name="alert-triangle" size={32} color="#F87171" />
        <Text style={[styles.statusText, { marginTop: 12, textAlign: 'center' }]}>{errorMessage}</Text>
        <TouchableOpacity onPress={() => router.back()} style={[styles.endBtn, { marginTop: 24 }]}>
          <Feather name="x" size={22} color="#fff" />
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: '#0B1220' }]}>
      {/* Remote video / avatar background */}
      {isVideo && remoteUid != null ? (
        <RtcSurfaceView style={StyleSheet.absoluteFill} canvas={{ uid: remoteUid }} />
      ) : (
        <View style={[styles.avatarBackdrop, { backgroundColor: colors.primary }]}>
          <Image source={{ uri: 'https://i.pravatar.cc/200?img=5' }} style={styles.avatarLarge} />
        </View>
      )}

      {/* Local preview (video calls only) */}
      {isVideo && localUid != null && !cameraOff && (
        <View style={[styles.localPreview, { top: topPad + 60 }]}>
          <RtcSurfaceView style={StyleSheet.absoluteFill} canvas={{ uid: 0 }} />
        </View>
      )}

      {/* Top bar */}
      <View style={[styles.topBar, { paddingTop: topPad }]}>
        <Text style={styles.expertName}>{params.expertName || 'On call'}</Text>
        <View style={styles.statusPill}>
          <View style={[styles.liveDot, { backgroundColor: remoteUid != null ? '#22C55E' : '#F59E0B' }]} />
          <Text style={styles.statusPillText}>{remoteUid != null ? formatDuration(elapsed) : 'Waiting for other side…'}</Text>
        </View>
      </View>

      {/* Bottom controls */}
      <View style={[styles.controls, { paddingBottom: bottomPad }]}>
        <TouchableOpacity onPress={toggleMute} style={[styles.controlBtn, muted && styles.controlBtnActive]} activeOpacity={0.85}>
          <Feather name={muted ? 'mic-off' : 'mic'} size={22} color="#fff" />
        </TouchableOpacity>

        {isVideo && (
          <TouchableOpacity onPress={toggleCamera} style={[styles.controlBtn, cameraOff && styles.controlBtnActive]} activeOpacity={0.85}>
            <Feather name={cameraOff ? 'video-off' : 'video'} size={22} color="#fff" />
          </TouchableOpacity>
        )}

        {isVideo && (
          <TouchableOpacity onPress={flipCamera} style={styles.controlBtn} activeOpacity={0.85}>
            <Feather name="refresh-cw" size={22} color="#fff" />
          </TouchableOpacity>
        )}

        <TouchableOpacity onPress={handleEndCall} style={styles.endBtn} activeOpacity={0.85}>
          <Feather name="phone-off" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { alignItems: 'center', justifyContent: 'center' },
  statusText: { color: 'rgba(255,255,255,0.85)', fontSize: 15, marginTop: 16, fontFamily: 'Inter_500Medium' },
  avatarBackdrop: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', opacity: 0.9 },
  avatarLarge: { width: 120, height: 120, borderRadius: 60, borderWidth: 4, borderColor: 'rgba(255,255,255,0.4)' },
  localPreview: { position: 'absolute', right: 16, width: 100, height: 140, borderRadius: 14, overflow: 'hidden', borderWidth: 2, borderColor: 'rgba(255,255,255,0.5)', backgroundColor: '#000' },
  topBar: { alignItems: 'center', paddingHorizontal: 20, gap: 8 },
  expertName: { color: '#fff', fontSize: 18, fontFamily: 'Inter_700Bold' },
  statusPill: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(0,0,0,0.35)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  liveDot: { width: 7, height: 7, borderRadius: 4 },
  statusPillText: { color: '#fff', fontSize: 13, fontFamily: 'Inter_500Medium' },
  controls: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 18 },
  controlBtn: { width: 56, height: 56, borderRadius: 28, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  controlBtnActive: { backgroundColor: 'rgba(255,255,255,0.35)' },
  endBtn: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#EF4444', alignItems: 'center', justifyContent: 'center' },
});
