import { useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '@/context/AppContext';

export default function SplashScreen() {
  const router = useRouter();
  const { isAuthenticated } = useApp();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    if (isAuthenticated) {
      const t = setTimeout(() => router.replace('/(tabs)'), 1200);
      return () => clearTimeout(t);
    }
  }, [isAuthenticated]);

  return (
    <TouchableOpacity style={styles.container} onPress={() => router.push('/onboarding')} activeOpacity={1}>
      <Image
        source={require('@/assets/images/prichha-logo.jpeg')}
        style={styles.logo}
      />
      <Text style={styles.title}>PRICHHA</Text>
      <Text style={styles.tagline}>discover. connect. ask</Text>
      <View style={[styles.hint, { bottom: insets.bottom + 48 }]}>
        <Text style={styles.hintText}>Tap to continue</Text>
        <View style={styles.dots}>
          <View style={[styles.dot, { opacity: 0.4 }]} />
          <View style={[styles.dot, { opacity: 0.9 }]} />
          <View style={[styles.dot, { opacity: 0.4 }]} />
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D7C7A', alignItems: 'center', justifyContent: 'center' },
  logo: { width: 120, height: 120, borderRadius: 28, marginBottom: 24, borderWidth: 3, borderColor: 'rgba(255,255,255,0.25)' },
  title: { fontSize: 32, fontWeight: '800', color: '#FFFFFF', letterSpacing: 3, marginBottom: 10, fontFamily: 'Inter_700Bold' },
  tagline: { fontSize: 12, color: 'rgba(255,255,255,0.7)', letterSpacing: 4, fontWeight: '500', textTransform: 'uppercase', fontFamily: 'Inter_500Medium' },
  hint: { position: 'absolute', alignItems: 'center', gap: 10 },
  hintText: { color: 'rgba(255,255,255,0.55)', fontSize: 13, fontFamily: 'Inter_500Medium' },
  dots: { flexDirection: 'row', gap: 6 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#FFFFFF' },
});
