import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setToken, getToken } from '@/lib/api';
import { login as apiLogin, signup as apiSignup, me as apiMe } from '@/lib/auth-api';
import { Role, User } from '@/lib/types';

// UI-facing role kept lowercase for backwards compatibility with existing screens.
export type UiRole = 'student' | 'advisor' | 'professional';

function toUiRole(role: Role): UiRole {
  return role.toLowerCase() as UiRole;
}
function toApiRole(role: UiRole): Role {
  return role.toUpperCase() as Role;
}

interface AppContextType {
  role: UiRole;
  setRole: (role: UiRole) => void;
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  userName: string;
  balance: number;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string, role?: UiRole) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AppContext = createContext<AppContextType>({
  role: 'student',
  setRole: () => {},
  isAuthenticated: false,
  isLoading: true,
  user: null,
  userName: '',
  balance: 0,
  login: async () => {},
  signup: async () => {},
  logout: async () => {},
  refreshUser: async () => {},
});

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [role, setRoleState] = useState<UiRole>('student');
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const setRole = (r: UiRole) => {
    setRoleState(r);
    AsyncStorage.setItem('role', r).catch(() => {});
  };

  const refreshUser = useCallback(async () => {
    try {
      const freshUser = await apiMe();
      setUser(freshUser);
      setRoleState(toUiRole(freshUser.role));
    } catch {
      // Token invalid/expired — sign the user out locally.
      await setToken(null);
      setUser(null);
    }
  }, []);

  useEffect(() => {
    (async () => {
      AsyncStorage.getItem('role').then((r) => r && setRoleState(r as UiRole)).catch(() => {});
      const token = await getToken();
      if (token) {
        await refreshUser();
      }
      setIsLoading(false);
    })();
  }, [refreshUser]);

  const login = async (email: string, password: string) => {
    const res = await apiLogin({ email, password });
    await setToken(res.token);
    setUser(res.user);
    setRoleState(toUiRole(res.user.role));
  };

  const signup = async (name: string, email: string, password: string, uiRole: UiRole = 'student') => {
    const res = await apiSignup({ name, email, password, role: toApiRole(uiRole) });
    await setToken(res.token);
    setUser(res.user);
    setRoleState(toUiRole(res.user.role));
  };

  const logout = async () => {
    await setToken(null);
    setUser(null);
  };

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        isAuthenticated: !!user,
        isLoading,
        user,
        userName: user?.name ?? '',
        balance: user?.balance ?? 0,
        login,
        signup,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
