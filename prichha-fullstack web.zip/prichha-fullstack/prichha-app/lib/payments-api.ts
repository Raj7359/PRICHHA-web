import { apiFetch } from './api';

export interface RazorpayOrder {
  orderId: string;
  amount: number; // paise
  currency: string;
  keyId: string;
}

export function createOrder(amount: number) {
  return apiFetch<RazorpayOrder>('/api/payments/create-order', { method: 'POST', body: { amount } });
}

export interface VerifyPaymentParams {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}

export function verifyPayment(params: VerifyPaymentParams) {
  return apiFetch<{ ok: true; balance: number }>('/api/payments/verify', { method: 'POST', body: params });
}

export interface WithdrawParams {
  amount: number;
  method: 'UPI' | 'BANK';
  details: string;
}

export function requestWithdrawal(params: WithdrawParams) {
  return apiFetch('/api/wallet/withdraw', { method: 'POST', body: params });
}
