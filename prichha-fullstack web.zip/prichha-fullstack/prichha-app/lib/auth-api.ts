import { apiFetch } from './api';
import { AuthResponse } from './types';

export function signup(params: { name: string; email: string; password: string; role?: 'STUDENT' | 'ADVISOR' | 'PROFESSIONAL' }) {
  return apiFetch<AuthResponse>('/api/auth/signup', { method: 'POST', body: params, auth: false });
}

export function login(params: { email: string; password: string }) {
  return apiFetch<AuthResponse>('/api/auth/login', { method: 'POST', body: params, auth: false });
}

export function me() {
  return apiFetch<AuthResponse['user']>('/api/auth/me');
}
