export type Role = 'STUDENT' | 'ADVISOR' | 'PROFESSIONAL';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  balance: number;
  avatarUrl?: string | null;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface MentorDTO {
  id: string;
  name: string;
  avatarUrl?: string | null;
  college: string;
  stream: string;
  rate: number;
  rating: number;
  sessions: number;
  tags: string[];
  online: boolean;
  bio?: string | null;
}

export interface ProfessionalDTO {
  id: string;
  name: string;
  avatarUrl?: string | null;
  company: string;
  dept: string;
  role: string;
  exp: string;
  rate: number;
  rating: number;
  sessions: number;
  tags: string[];
  online: boolean;
  bio?: string | null;
}

export interface WalletTransactionDTO {
  id: string;
  type: 'CREDIT' | 'DEBIT';
  kind: 'TOPUP' | 'WITHDRAWAL' | 'SESSION_CHARGE';
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REJECTED';
  amount: number;
  label: string;
  sub?: string | null;
  createdAt: string;
}
