import { apiFetch } from './api';

export interface SessionDTO {
  id: string;
  studentId: string;
  expertId: string;
  type: 'CHAT' | 'AUDIO' | 'VIDEO';
  status: 'PENDING' | 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  ratePerMin: number;
  scheduledAt: string;
  student?: { id: string; name: string; avatarUrl?: string | null };
  expert?: { id: string; name: string; avatarUrl?: string | null };
}

export function bookSession(params: { expertId: string; type: 'CHAT' | 'AUDIO' | 'VIDEO'; ratePerMin: number; scheduledAt: string }) {
  return apiFetch<SessionDTO>('/api/sessions', { method: 'POST', body: params });
}

export function listSessions() {
  return apiFetch<SessionDTO[]>('/api/sessions');
}

export function getSession(id: string) {
  return apiFetch<SessionDTO>(`/api/sessions/${id}`);
}
