import { apiFetch } from './api';

export interface CallTokenDTO {
  appId: string;
  channel: string;
  token: string;
  uid: number;
  video: boolean;
  sessionStatus: string;
}

export function getCallToken(sessionId: string) {
  return apiFetch<CallTokenDTO>(`/api/calls/${sessionId}/token`, { method: 'POST' });
}

export function endCall(sessionId: string) {
  return apiFetch(`/api/calls/${sessionId}/end`, { method: 'POST' });
}
