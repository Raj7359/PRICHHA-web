import { apiFetch } from './api';

export interface MessageDTO {
  id: string;
  sessionId: string;
  senderId: string;
  text: string;
  createdAt: string;
}

export function listMessages(sessionId: string) {
  return apiFetch<MessageDTO[]>(`/api/sessions/${sessionId}/messages`);
}

export function sendMessage(sessionId: string, text: string) {
  return apiFetch<MessageDTO>(`/api/sessions/${sessionId}/messages`, { method: 'POST', body: { text } });
}
