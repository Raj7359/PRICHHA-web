# Prichha Web (Next.js)

The web platform version of Prichha: registration with a mandatory ₹11 fee, student/advisor/professional dashboards, real-time chat (Socket.io), and Agora-powered audio/video calling — all against the same `prichha-backend` API used by the mobile app.

## Setup

```bash
npm install
cp .env.local.example .env.local
# edit .env.local: set NEXT_PUBLIC_API_URL to your backend, e.g. http://localhost:4000

npm run dev   # → http://localhost:3000
```

**Before running this**, make sure `prichha-backend` is running with:
- `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` set (registration and wallet top-ups won't work without them)
- `AGORA_APP_ID` / `AGORA_APP_CERTIFICATE` set (calling won't work without them)
- `CORS_ORIGIN` including `http://localhost:3000` (required — the web app uses cookie-based auth, which needs an explicit allowed origin, not `*`)
- The database migrated and seeded (`npx prisma migrate dev`, `npm run prisma:seed`)

See the root `LOCAL_SETUP_GUIDE.md` for the full walkthrough.

## Architecture

- **Auth**: httpOnly cookie (`token`), set by the backend on login/registration-verify. `middleware.ts` does a cheap "cookie exists" check on protected routes; `lib/useRequireRole.ts` does the real check (valid session + correct role) via `/api/auth/me`.
- **Registration**: `/register` → `POST /api/auth/register/start` creates an inactive account + Razorpay order → Razorpay Checkout modal opens for exactly ₹11 → on success, `POST /api/auth/register/verify` activates the account and logs the user in. The backend's webhook (`/api/auth/register/webhook`) is the actual source of truth; `/verify` just lets the UI react immediately.
- **Real-time chat**: `lib/socket.ts` holds a single Socket.io connection, authenticated via the same cookie. `components/ChatPanel.tsx` loads history over REST, then listens for `new_message` events.
- **Calling**: `components/CallRoom.tsx` uses `agora-rtc-sdk-ng` (dynamically imported, browser-only). Token comes from `POST /api/calls/:sessionId/token`; ending the call calls `POST /api/calls/:sessionId/end`, which bills the student and credits the expert server-side.

## Folder structure

```
app/
├── layout.tsx              # root layout, AuthProvider, Razorpay <script>
├── page.tsx                  # landing page
├── register/page.tsx          # ₹11 registration flow
├── login/page.tsx
├── student/dashboard/page.tsx   # browse + book, wallet top-up
├── advisor/dashboard/page.tsx    # availability, bookings, earnings (ADVISOR + PROFESSIONAL)
├── call/[sessionId]/page.tsx      # call room or chat-only view
└── admin/page.tsx                  # admin panel (tabbed: overview/users/approvals/logs/withdrawals)
components/
├── Navbar.tsx, ExpertCard.tsx, BookingModal.tsx
├── ChatPanel.tsx            # Socket.io chat
└── CallRoom.tsx              # Agora Web SDK
lib/
├── api.ts, auth-context.tsx, useRequireRole.ts, socket.ts, types.ts
└── directory-api.ts, sessions-api.ts, payments-api.ts, calls-api.ts, admin-api.ts, profile-api.ts
middleware.ts
```

## Notes

- Tailwind colors in `tailwind.config.ts` are copied 1:1 from the mobile app's `constants/colors.ts` so both clients look consistent.
- This is a genuinely separate frontend from the Expo mobile app — they share nothing but the backend API. Both can run simultaneously against the same database.
