'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from './auth-context';
import { Role } from './types';

// Used at the top of every protected dashboard page. Middleware.ts does a
// cheap "is there a cookie at all" check before the page even loads; this
// hook does the real check (valid session + correct role) once the client
// has fetched /api/auth/me, and redirects if either fails.
export function useRequireRole(allowedRoles: Role[]) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace('/login');
      return;
    }
    if (!allowedRoles.includes(user.role)) {
      const fallback = user.role === 'STUDENT' ? '/student/dashboard' : user.role === 'ADMIN' ? '/admin' : '/advisor/dashboard';
      router.replace(fallback);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, loading]);

  return { user, loading, ready: !loading && !!user && allowedRoles.includes(user.role) };
}
