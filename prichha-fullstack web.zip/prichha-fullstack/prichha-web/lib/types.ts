export type Role = 'STUDENT' | 'ADVISOR' | 'PROFESSIONAL' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  balance: number;
  avatarUrl?: string | null;
}

export interface MentorDTO {
  id: string;
  name: string;
  avatarUrl?: string | null;
  college: string;
  stream: string;
  rate: number;
  rating: number;
  sessions: number;
  tags: string[];
  online: boolean;
  bio?: string | null;
  approved: boolean;
}

export interface ProfessionalDTO {
  id: string;
  name: string;
  avatarUrl?: string | null;
  company: string;
  dept: string;
  role: string;
  exp: string;
  rate: number;
  rating: number;
  sessions: number;
  tags: string[];
  online: boolean;
  bio?: string | null;
  approved: boolean;
}

export interface SessionDTO {
  id: string;
  studentId: string;
  expertId: string;
  type: 'CHAT' | 'AUDIO' | 'VIDEO';
  status: 'PENDING' | 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  ratePerMin: number;
  scheduledAt: string;
  student?: { id: string; name: string; avatarUrl?: string | null };
  expert?: { id: string; name: string; avatarUrl?: string | null };
}

export interface MessageDTO {
  id: string;
  sessionId: string;
  senderId: string;
  text: string;
  createdAt: string;
}

export interface WalletTransactionDTO {
  id: string;
  type: 'CREDIT' | 'DEBIT';
  kind: 'TOPUP' | 'WITHDRAWAL' | 'SESSION_CHARGE';
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REJECTED';
  amount: number;
  label: string;
  sub?: string | null;
  createdAt: string;
}
