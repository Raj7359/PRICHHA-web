import { apiFetch } from './api';
import { MentorDTO, ProfessionalDTO } from './types';

export function getMentors(params: { search?: string; sortBy?: 'rating' | 'price' | 'sessions' } = {}) {
  const q = new URLSearchParams();
  if (params.search) q.set('search', params.search);
  if (params.sortBy) q.set('sortBy', params.sortBy);
  const qs = q.toString();
  return apiFetch<MentorDTO[]>(`/api/mentors${qs ? `?${qs}` : ''}`);
}

export function getMentor(id: string) {
  return apiFetch<MentorDTO>(`/api/mentors/${id}`);
}

export function getProfessionals(params: { search?: string; sortBy?: 'rating' | 'price' | 'sessions' } = {}) {
  const q = new URLSearchParams();
  if (params.search) q.set('search', params.search);
  if (params.sortBy) q.set('sortBy', params.sortBy);
  const qs = q.toString();
  return apiFetch<ProfessionalDTO[]>(`/api/professionals${qs ? `?${qs}` : ''}`);
}

export function getProfessional(id: string) {
  return apiFetch<ProfessionalDTO>(`/api/professionals/${id}`);
}
