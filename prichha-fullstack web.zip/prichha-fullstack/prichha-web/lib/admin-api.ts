import { apiFetch } from './api';

export interface UserRow {
  id: string;
  name: string;
  email: string;
  role: 'STUDENT' | 'ADVISOR' | 'PROFESSIONAL' | 'ADMIN';
  balance: number;
  isActive: boolean;
  createdAt: string;
}

export interface TransactionRow {
  id: string;
  userId: string;
  user: { id: string; name: string; email: string };
  type: 'CREDIT' | 'DEBIT';
  kind: 'TOPUP' | 'WITHDRAWAL' | 'SESSION_CHARGE';
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REJECTED';
  amount: number;
  label: string;
  sub?: string | null;
  createdAt: string;
}

export interface Stats {
  userCount: number;
  mentorCount: number;
  professionalCount: number;
  sessionCount: number;
  pendingWithdrawals: number;
  totalTopUpRevenue: number;
}

export interface PendingProfile {
  id: string;
  college?: string;
  stream?: string;
  company?: string;
  role?: string;
  ratePerMin: number;
  user: { id: string; name: string; email: string; createdAt: string };
}

export function getStats() {
  return apiFetch<Stats>('/api/admin/stats');
}

export function getUsers(params: { search?: string; role?: string; page?: number } = {}) {
  const q = new URLSearchParams();
  if (params.search) q.set('search', params.search);
  if (params.role) q.set('role', params.role);
  if (params.page) q.set('page', String(params.page));
  return apiFetch<{ users: UserRow[]; total: number; page: number; pageSize: number }>(`/api/admin/users?${q}`);
}

export function updateUser(id: string, data: { isActive?: boolean; role?: string }) {
  return apiFetch<UserRow>(`/api/admin/users/${id}`, { method: 'PATCH', body: data });
}

export function getTransactions(params: { kind?: string; status?: string; page?: number } = {}) {
  const q = new URLSearchParams();
  if (params.kind) q.set('kind', params.kind);
  if (params.status) q.set('status', params.status);
  if (params.page) q.set('page', String(params.page));
  return apiFetch<{ transactions: TransactionRow[]; total: number; page: number; pageSize: number }>(`/api/admin/transactions?${q}`);
}

export function getWithdrawals(status = 'PENDING') {
  return apiFetch<TransactionRow[]>(`/api/admin/withdrawals?status=${status}`);
}
export function approveWithdrawal(id: string) {
  return apiFetch(`/api/admin/withdrawals/${id}/approve`, { method: 'POST' });
}
export function rejectWithdrawal(id: string) {
  return apiFetch(`/api/admin/withdrawals/${id}/reject`, { method: 'POST' });
}

export function getPendingMentors() {
  return apiFetch<PendingProfile[]>('/api/admin/mentors/pending');
}
export function getPendingProfessionals() {
  return apiFetch<PendingProfile[]>('/api/admin/professionals/pending');
}
export function approveMentor(id: string) {
  return apiFetch(`/api/admin/mentors/${id}`, { method: 'PATCH', body: { approved: true } });
}
export function rejectMentorListing(id: string) {
  return apiFetch(`/api/admin/mentors/${id}`, { method: 'DELETE' });
}
export function approveProfessional(id: string) {
  return apiFetch(`/api/admin/professionals/${id}`, { method: 'PATCH', body: { approved: true } });
}
export function rejectProfessionalListing(id: string) {
  return apiFetch(`/api/admin/professionals/${id}`, { method: 'DELETE' });
}
