import { apiFetch } from './api';
import { WalletTransactionDTO, User } from './types';

// ---------- Wallet ----------

export function getWalletBalance() {
  return apiFetch<{ balance: number }>('/api/wallet');
}

export function getWalletTransactions() {
  return apiFetch<WalletTransactionDTO[]>('/api/wallet/transactions');
}

export function requestWithdrawal(params: { amount: number; method: 'UPI' | 'BANK'; details: string }) {
  return apiFetch('/api/wallet/withdraw', { method: 'POST', body: params });
}

// ---------- Wallet top-up (Razorpay) ----------

export interface RazorpayOrder {
  orderId: string;
  amount: number; // paise
  currency: string;
  keyId: string;
}

export function createTopupOrder(amount: number) {
  return apiFetch<RazorpayOrder>('/api/payments/create-order', { method: 'POST', body: { amount } });
}

export interface VerifyPaymentParams {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}

export function verifyTopupPayment(params: VerifyPaymentParams) {
  return apiFetch<{ ok: true; balance: number }>('/api/payments/verify', { method: 'POST', body: params });
}

// ---------- Registration fee (₹11, mandatory on signup) ----------

export interface RegistrationOrder {
  userId: string;
  orderId: string;
  amount: number; // paise
  currency: string;
  keyId: string;
}

export function startRegistration(params: { name: string; email: string; password: string; role: 'STUDENT' | 'ADVISOR' | 'PROFESSIONAL' }) {
  return apiFetch<RegistrationOrder>('/api/auth/register/start', { method: 'POST', body: params });
}

export interface VerifyRegistrationParams extends VerifyPaymentParams {
  userId: string;
}

export function verifyRegistration(params: VerifyRegistrationParams) {
  return apiFetch<{ token: string; user: User }>('/api/auth/register/verify', { method: 'POST', body: params });
}
