import { apiFetch } from './api';
import { SessionDTO, MessageDTO } from './types';

export function bookSession(params: { expertId: string; type: 'CHAT' | 'AUDIO' | 'VIDEO'; ratePerMin: number; scheduledAt: string }) {
  return apiFetch<SessionDTO>('/api/sessions', { method: 'POST', body: params });
}

export function listSessions() {
  return apiFetch<SessionDTO[]>('/api/sessions');
}

export function getSession(id: string) {
  return apiFetch<SessionDTO>(`/api/sessions/${id}`);
}

export function listMessages(sessionId: string) {
  return apiFetch<MessageDTO[]>(`/api/sessions/${sessionId}/messages`);
}

export function sendMessageRest(sessionId: string, text: string) {
  // REST fallback for sending a chat message — the web call room primarily
  // uses the Socket.io `send_message` event (see lib/socket.ts) for real-time
  // delivery, but this exists so chat still works if sockets are unavailable.
  return apiFetch<MessageDTO>(`/api/sessions/${sessionId}/messages`, { method: 'POST', body: { text } });
}
