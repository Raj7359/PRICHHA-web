import { apiFetch } from './api';
import { SessionDTO } from './types';

export interface MyProfile {
  role: string;
  user: { id: string; name: string; email: string; role: string; balance: number; avatarUrl?: string | null };
  profile: {
    id: string;
    online: boolean;
    ratePerMin: number;
    tags: string[];
    bio?: string | null;
    approved: boolean;
    rating: number;
    sessionsCount: number;
    college?: string;
    stream?: string;
    company?: string;
    dept?: string;
    role?: string;
    experience?: string;
  } | null;
}

export function getMyProfile() {
  return apiFetch<MyProfile>('/api/profile/me');
}

export function updateMyProfile(data: { online?: boolean; bio?: string; ratePerMin?: number; tags?: string[] }) {
  return apiFetch('/api/profile/me', { method: 'PATCH', body: data });
}

export function getMyBookings() {
  return apiFetch<SessionDTO[]>('/api/profile/bookings');
}

export interface EarningsSummary {
  totalEarnings: number;
  totalSessions: number;
  thisMonthEarnings: number;
  thisMonthSessions: number;
  recent: { id: string; amount: number; label: string; sub?: string | null; createdAt: string }[];
}

export function getMyEarnings() {
  return apiFetch<EarningsSummary>('/api/profile/earnings');
}
