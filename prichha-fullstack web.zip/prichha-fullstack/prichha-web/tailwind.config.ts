import type { Config } from 'tailwindcss';

// Colors copied 1:1 from the mobile app's constants/colors.ts so the web
// platform is visually consistent with the Expo app (same teal primary,
// coral accent, amber highlight, etc).
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        background: '#FAFAF8',
        foreground: '#111827',
        card: '#FFFFFF',
        cardForeground: '#111827',
        primary: {
          DEFAULT: '#0D7C7A',
          foreground: '#FFFFFF',
          light: '#E6F4F3',
        },
        secondary: {
          DEFAULT: '#F3F4F6',
          foreground: '#374151',
        },
        muted: {
          DEFAULT: '#F3F4F6',
          foreground: '#6B7280',
        },
        accent: {
          DEFAULT: '#FF6B6B',
          foreground: '#FFFFFF',
          light: '#FFF0F0',
        },
        destructive: {
          DEFAULT: '#EF4444',
          foreground: '#FFFFFF',
        },
        amber: {
          DEFAULT: '#F59E0B',
          foreground: '#FFFFFF',
          light: '#FEF3C7',
        },
        success: {
          DEFAULT: '#10B981',
          light: '#D1FAE5',
        },
        border: '#E5E7EB',
        input: '#E5E7EB',
      },
      borderRadius: {
        DEFAULT: '16px',
        card: '20px',
        pill: '999px',
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'sans-serif'],
      },
      boxShadow: {
        card: '0 2px 10px rgba(17, 24, 39, 0.05)',
      },
    },
  },
  plugins: [],
};

export default config;
