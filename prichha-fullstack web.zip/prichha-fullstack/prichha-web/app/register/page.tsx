'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { User, Mail, Lock, GraduationCap, Briefcase, ArrowLeft, CheckCircle2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { useAuth, ApiError } from '@/lib/auth-context';
import { startRegistration, verifyRegistration } from '@/lib/payments-api';

type Role = 'STUDENT' | 'ADVISOR' | 'PROFESSIONAL';

const ROLE_OPTIONS: { id: Role; label: string; desc: string; icon: typeof User }[] = [
  { id: 'STUDENT', label: 'Student', desc: 'Looking for guidance', icon: User },
  { id: 'ADVISOR', label: 'College Senior', desc: 'Want to mentor students', icon: GraduationCap },
  { id: 'PROFESSIONAL', label: 'Professional', desc: 'Share career expertise', icon: Briefcase },
];

export default function RegisterPage() {
  const router = useRouter();
  const { refresh } = useAuth();

  const [role, setRole] = useState<Role>('STUDENT');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [stage, setStage] = useState<'form' | 'paying' | 'success'>('form');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isValid = name.trim().length >= 2 && email.includes('@') && password.length >= 6;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid || loading) return;
    setError('');
    setLoading(true);

    try {
      // Step 1: create the (inactive) account + a ₹11 Razorpay order.
      const order = await startRegistration({ name: name.trim(), email: email.trim(), password, role });
      setStage('paying');

      // Step 2: open Razorpay's hosted Checkout for exactly ₹11.
      const rzp = new window.Razorpay({
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        order_id: order.orderId,
        name: 'Prichha',
        description: 'One-time registration fee',
        prefill: { name: name.trim(), email: email.trim() },
        theme: { color: '#0D7C7A' },
        handler: async (response) => {
          // Step 3: server verifies the signature and activates the account.
          try {
            await verifyRegistration({ userId: order.userId, ...response });
            await refresh();
            setStage('success');
            setTimeout(() => router.replace(roleToDashboard(role)), 1200);
          } catch (err) {
            setError(err instanceof ApiError ? err.message : 'Payment succeeded but activation failed. Please contact support.');
            setStage('form');
          }
        },
        modal: {
          ondismiss: () => {
            setStage('form');
            setError('Payment was cancelled. Your details are saved — just submit again to retry.');
          },
        },
      });
      rzp.on('payment.failed', () => {
        setStage('form');
        setError('Payment failed. Please try again.');
      });
      rzp.open();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.');
      setStage('form');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <main className="max-w-md mx-auto px-5 py-12">
        <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft size={14} /> Back
        </Link>

        {stage === 'success' ? (
          <div className="surface-card p-10 text-center">
            <CheckCircle2 size={40} className="text-success mx-auto mb-4" />
            <h2 className="font-bold text-lg mb-1">You&apos;re in!</h2>
            <p className="text-sm text-muted-foreground">Redirecting to your dashboard…</p>
          </div>
        ) : (
          <>
            <h1 className="text-2xl font-bold mb-1">Create your account</h1>
            <p className="text-sm text-muted-foreground mb-6">
              A one-time ₹11 registration fee activates your account — this keeps Prichha spam-free.
            </p>

            <div className="grid grid-cols-3 gap-2 mb-6">
              {ROLE_OPTIONS.map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setRole(r.id)}
                  className={`p-3 rounded-2xl border text-left transition-colors ${
                    role === r.id ? 'border-primary bg-primary-light' : 'border-border bg-card hover:bg-muted'
                  }`}
                >
                  <r.icon size={18} className={role === r.id ? 'text-primary' : 'text-muted-foreground'} />
                  <div className={`text-xs font-bold mt-2 ${role === r.id ? 'text-primary' : 'text-foreground'}`}>{r.label}</div>
                  <div className="text-[11px] text-muted-foreground leading-tight mt-0.5">{r.desc}</div>
                </button>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="relative">
                <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  className="input-field pl-11"
                  placeholder="Full name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
              </div>
              <div className="relative">
                <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  className="input-field pl-11"
                  placeholder="Email address"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
              </div>
              <div className="relative">
                <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  className="input-field pl-11"
                  placeholder="Password (min 6 characters)"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="new-password"
                />
              </div>

              {error && <p className="text-sm text-destructive">{error}</p>}

              <button type="submit" disabled={!isValid || loading} className="btn-primary w-full mt-2">
                {stage === 'paying' ? 'Opening secure checkout…' : loading ? 'Please wait…' : 'Continue to ₹11 payment'}
              </button>
            </form>

            <p className="text-center text-sm text-muted-foreground mt-6">
              Already have an account?{' '}
              <Link href="/login" className="text-primary font-semibold">
                Log in
              </Link>
            </p>
          </>
        )}
      </main>
    </>
  );
}

function roleToDashboard(role: Role) {
  if (role === 'STUDENT') return '/student/dashboard';
  return '/advisor/dashboard';
}
