'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Power, TrendingUp, Calendar, Clock, Phone, Video, MessageCircle, AlertCircle } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { useRequireRole } from '@/lib/useRequireRole';
import { getMyProfile, updateMyProfile, getMyBookings, getMyEarnings, MyProfile, EarningsSummary } from '@/lib/profile-api';
import { SessionDTO } from '@/lib/types';

const TYPE_ICON = { CHAT: MessageCircle, AUDIO: Phone, VIDEO: Video } as const;

export default function AdvisorDashboard() {
  const { ready } = useRequireRole(['ADVISOR', 'PROFESSIONAL']);
  const router = useRouter();

  const [profile, setProfile] = useState<MyProfile | null>(null);
  const [bookings, setBookings] = useState<SessionDTO[]>([]);
  const [earnings, setEarnings] = useState<EarningsSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [togglingOnline, setTogglingOnline] = useState(false);

  useEffect(() => {
    if (!ready) return;
    Promise.all([getMyProfile(), getMyBookings(), getMyEarnings()])
      .then(([p, b, e]) => {
        setProfile(p);
        setBookings(b);
        setEarnings(e);
      })
      .finally(() => setLoading(false));
  }, [ready]);

  if (!ready || loading || !profile) return <LoadingScreen />;

  const handleToggleOnline = async () => {
    if (!profile.profile) return;
    setTogglingOnline(true);
    try {
      const updated = await updateMyProfile({ online: !profile.profile.online });
      setProfile({ ...profile, profile: { ...profile.profile, online: (updated as any).online } });
    } finally {
      setTogglingOnline(false);
    }
  };

  const upcoming = bookings.filter((b) => b.status === 'PENDING' || b.status === 'ACTIVE');
  const past = bookings.filter((b) => b.status === 'COMPLETED' || b.status === 'CANCELLED');

  return (
    <>
      <Navbar />
      <main className="max-w-6xl mx-auto px-5 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">{profile.user.name.split(' ')[0]}&apos;s Dashboard</h1>
            <p className="text-sm text-muted-foreground">{profile.role === 'ADVISOR' ? 'College Senior' : 'Professional'} account</p>
          </div>
          <button
            onClick={handleToggleOnline}
            disabled={togglingOnline}
            className={`chip gap-2 font-semibold !py-2.5 !px-4 ${
              profile.profile?.online ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
            }`}
          >
            <Power size={14} />
            {profile.profile?.online ? 'Online — accepting sessions' : 'Offline'}
          </button>
        </div>

        {profile.profile && !profile.profile.approved && (
          <div className="surface-card p-4 mb-6 flex items-start gap-3 bg-amber-light border-amber/30">
            <AlertCircle size={18} className="text-amber shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-foreground">Your profile is awaiting admin approval</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                You won&apos;t appear in student search results until an admin approves your listing. This usually happens within a day.
              </p>
            </div>
          </div>
        )}

        {/* Earnings */}
        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          <StatCard icon={TrendingUp} label="Total Earnings" value={`₹${(earnings?.totalEarnings ?? 0).toLocaleString('en-IN')}`} />
          <StatCard icon={Calendar} label="This Month" value={`₹${(earnings?.thisMonthEarnings ?? 0).toLocaleString('en-IN')}`} />
          <StatCard icon={Clock} label="Total Sessions" value={String(earnings?.totalSessions ?? 0)} />
        </div>

        {/* Bookings */}
        <section className="mb-8">
          <h2 className="font-bold text-lg mb-3">Active & Upcoming Bookings</h2>
          {upcoming.length === 0 ? (
            <p className="text-sm text-muted-foreground surface-card p-6 text-center">No active bookings right now.</p>
          ) : (
            <div className="space-y-2">
              {upcoming.map((b) => {
                const Icon = TYPE_ICON[b.type];
                return (
                  <div key={b.id} className="surface-card p-4 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-primary-light flex items-center justify-center shrink-0">
                        <Icon size={16} className="text-primary" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-sm truncate">{b.student?.name || 'Student'}</p>
                        <p className="text-xs text-muted-foreground">
                          {b.type} · {new Date(b.scheduledAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                    {b.type !== 'CHAT' ? (
                      <button onClick={() => router.push(`/call/${b.id}`)} className="btn-primary !py-2 !px-4 text-xs shrink-0">
                        Join Call
                      </button>
                    ) : (
                      <button onClick={() => router.push(`/call/${b.id}?mode=chat`)} className="btn-secondary !py-2 !px-4 text-xs shrink-0">
                        Open Chat
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Earnings breakdown */}
        <section>
          <h2 className="font-bold text-lg mb-3">Recent Earnings</h2>
          {!earnings?.recent.length ? (
            <p className="text-sm text-muted-foreground surface-card p-6 text-center">No earnings yet — completed sessions will show up here.</p>
          ) : (
            <div className="surface-card divide-y divide-border overflow-hidden">
              {earnings.recent.map((t) => (
                <div key={t.id} className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{t.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {t.sub} · {new Date(t.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}
                    </p>
                  </div>
                  <span className="text-sm font-bold text-success">+₹{t.amount}</span>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: typeof TrendingUp; label: string; value: string }) {
  return (
    <div className="surface-card p-5">
      <div className="w-9 h-9 rounded-xl bg-primary-light flex items-center justify-center mb-3">
        <Icon size={16} className="text-primary" />
      </div>
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );
}
