'use client';

import { useEffect, useState } from 'react';
import { Users, Receipt, UserCheck, Wallet, LayoutGrid } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { useRequireRole } from '@/lib/useRequireRole';
import {
  getStats, getUsers, updateUser, getTransactions, getWithdrawals, approveWithdrawal, rejectWithdrawal,
  getPendingMentors, getPendingProfessionals, approveMentor, rejectMentorListing, approveProfessional, rejectProfessionalListing,
  Stats, UserRow, TransactionRow, PendingProfile,
} from '@/lib/admin-api';

type Tab = 'overview' | 'users' | 'approvals' | 'transactions' | 'withdrawals';

const TABS: { id: Tab; label: string; icon: typeof LayoutGrid }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutGrid },
  { id: 'users', label: 'Users', icon: Users },
  { id: 'approvals', label: 'Approvals', icon: UserCheck },
  { id: 'transactions', label: 'Payment Logs', icon: Receipt },
  { id: 'withdrawals', label: 'Withdrawals', icon: Wallet },
];

export default function AdminPanel() {
  const { ready } = useRequireRole(['ADMIN']);
  const [tab, setTab] = useState<Tab>('overview');

  if (!ready) return <LoadingScreen />;

  return (
    <>
      <Navbar />
      <main className="max-w-6xl mx-auto px-5 py-8">
        <h1 className="text-2xl font-bold mb-6">Admin Panel</h1>

        <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`chip gap-1.5 font-semibold whitespace-nowrap ${tab === t.id ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}
            >
              <t.icon size={14} /> {t.label}
            </button>
          ))}
        </div>

        {tab === 'overview' && <OverviewTab />}
        {tab === 'users' && <UsersTab />}
        {tab === 'approvals' && <ApprovalsTab />}
        {tab === 'transactions' && <TransactionsTab />}
        {tab === 'withdrawals' && <WithdrawalsTab />}
      </main>
    </>
  );
}

// ---------- Overview ----------

function OverviewTab() {
  const [stats, setStats] = useState<Stats | null>(null);
  useEffect(() => {
    getStats().then(setStats);
  }, []);

  if (!stats) return <SkeletonBlock />;

  const cards = [
    { label: 'Total Users', value: stats.userCount },
    { label: 'Mentors', value: stats.mentorCount },
    { label: 'Professionals', value: stats.professionalCount },
    { label: 'Sessions', value: stats.sessionCount },
    { label: 'Pending Withdrawals', value: stats.pendingWithdrawals },
    { label: 'Top-up Revenue', value: `₹${stats.totalTopUpRevenue.toLocaleString('en-IN')}` },
  ];

  return (
    <div className="grid sm:grid-cols-3 gap-4">
      {cards.map((c) => (
        <div key={c.label} className="surface-card p-5">
          <p className="text-xs text-muted-foreground mb-1.5">{c.label}</p>
          <p className="text-2xl font-bold">{c.value}</p>
        </div>
      ))}
    </div>
  );
}

// ---------- Users ----------

function UsersTab() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [search, setSearch] = useState('');
  const [role, setRole] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      getUsers({ search: search || undefined, role: role || undefined })
        .then((r) => setUsers(r.users))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [search, role]);

  const toggleActive = async (u: UserRow) => {
    const updated = await updateUser(u.id, { isActive: !u.isActive });
    setUsers((prev) => prev.map((x) => (x.id === u.id ? { ...x, isActive: (updated as any).isActive } : x)));
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-4">
        <input className="input-field max-w-xs !py-2" placeholder="Search name or email…" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="input-field max-w-[160px] !py-2" value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="">All roles</option>
          <option value="STUDENT">Student</option>
          <option value="ADVISOR">Advisor</option>
          <option value="PROFESSIONAL">Professional</option>
          <option value="ADMIN">Admin</option>
        </select>
      </div>

      {loading ? (
        <SkeletonBlock />
      ) : (
        <div className="surface-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted text-muted-foreground text-xs uppercase">
              <tr>
                <th className="text-left px-4 py-3">Name</th>
                <th className="text-left px-4 py-3">Email</th>
                <th className="text-left px-4 py-3">Role</th>
                <th className="text-left px-4 py-3">Balance</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {users.map((u) => (
                <tr key={u.id}>
                  <td className="px-4 py-3 font-medium">{u.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                  <td className="px-4 py-3">{u.role}</td>
                  <td className="px-4 py-3">₹{u.balance.toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3">
                    <span className={`chip text-xs ${u.isActive ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'}`}>
                      {u.isActive ? 'Active' : 'Suspended'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => toggleActive(u)} className="text-xs font-semibold text-primary hover:underline">
                      {u.isActive ? 'Suspend' : 'Reactivate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ---------- Approvals ----------

function ApprovalsTab() {
  const [mentors, setMentors] = useState<PendingProfile[]>([]);
  const [professionals, setProfessionals] = useState<PendingProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    Promise.all([getPendingMentors(), getPendingProfessionals()])
      .then(([m, p]) => {
        setMentors(m);
        setProfessionals(p);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleMentor = async (id: string, action: 'approve' | 'reject') => {
    await (action === 'approve' ? approveMentor(id) : rejectMentorListing(id));
    setMentors((prev) => prev.filter((m) => m.id !== id));
  };
  const handlePro = async (id: string, action: 'approve' | 'reject') => {
    await (action === 'approve' ? approveProfessional(id) : rejectProfessionalListing(id));
    setProfessionals((prev) => prev.filter((p) => p.id !== id));
  };

  if (loading) return <SkeletonBlock />;

  const combined = [
    ...mentors.map((m) => ({ ...m, kind: 'mentor' as const, subtitle: `${m.college} · ${m.stream}` })),
    ...professionals.map((p) => ({ ...p, kind: 'professional' as const, subtitle: `${p.company} · ${p.role}` })),
  ];

  if (combined.length === 0) {
    return <p className="text-sm text-muted-foreground surface-card p-8 text-center">No profiles awaiting approval. 🎉</p>;
  }

  return (
    <div className="space-y-3">
      {combined.map((p) => (
        <div key={p.id} className="surface-card p-4 flex items-center justify-between gap-3">
          <div>
            <p className="font-semibold text-sm">{p.user.name} <span className="text-xs text-muted-foreground font-normal">· {p.user.email}</span></p>
            <p className="text-xs text-muted-foreground mt-0.5">{p.subtitle} · ₹{p.ratePerMin}/min</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button
              onClick={() => (p.kind === 'mentor' ? handleMentor(p.id, 'approve') : handlePro(p.id, 'approve'))}
              className="btn-primary !py-2 !px-4 text-xs"
            >
              Approve
            </button>
            <button
              onClick={() => (p.kind === 'mentor' ? handleMentor(p.id, 'reject') : handlePro(p.id, 'reject'))}
              className="btn-secondary !py-2 !px-4 text-xs !border-destructive/30 !text-destructive"
            >
              Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- Transactions / Payment logs ----------

function TransactionsTab() {
  const [rows, setRows] = useState<TransactionRow[]>([]);
  const [kind, setKind] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getTransactions({ kind: kind || undefined, status: status || undefined })
      .then((r) => setRows(r.transactions))
      .finally(() => setLoading(false));
  }, [kind, status]);

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-4">
        <select className="input-field max-w-[160px] !py-2" value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="">All types</option>
          <option value="TOPUP">Top-up</option>
          <option value="WITHDRAWAL">Withdrawal</option>
          <option value="SESSION_CHARGE">Session charge</option>
        </select>
        <select className="input-field max-w-[160px] !py-2" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="SUCCESS">Success</option>
          <option value="PENDING">Pending</option>
          <option value="FAILED">Failed</option>
          <option value="REJECTED">Rejected</option>
        </select>
      </div>

      {loading ? (
        <SkeletonBlock />
      ) : (
        <div className="surface-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted text-muted-foreground text-xs uppercase">
              <tr>
                <th className="text-left px-4 py-3">User</th>
                <th className="text-left px-4 py-3">Kind</th>
                <th className="text-left px-4 py-3">Label</th>
                <th className="text-left px-4 py-3">Amount</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-left px-4 py-3">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.map((t) => (
                <tr key={t.id}>
                  <td className="px-4 py-3">
                    <p className="font-medium">{t.user.name}</p>
                    <p className="text-xs text-muted-foreground">{t.user.email}</p>
                  </td>
                  <td className="px-4 py-3">{t.kind.replace('_', ' ')}</td>
                  <td className="px-4 py-3">{t.label}{t.sub ? ` · ${t.sub}` : ''}</td>
                  <td className={`px-4 py-3 font-bold ${t.type === 'CREDIT' ? 'text-success' : 'text-destructive'}`}>
                    {t.type === 'CREDIT' ? '+' : '-'}₹{t.amount}
                  </td>
                  <td className="px-4 py-3">
                    <span className="chip bg-muted text-xs">{t.status}</span>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">
                    {new Date(t.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ---------- Withdrawals ----------

function WithdrawalsTab() {
  const [rows, setRows] = useState<TransactionRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getWithdrawals('PENDING').then(setRows).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const handle = async (id: string, action: 'approve' | 'reject') => {
    await (action === 'approve' ? approveWithdrawal(id) : rejectWithdrawal(id));
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  if (loading) return <SkeletonBlock />;
  if (rows.length === 0) return <p className="text-sm text-muted-foreground surface-card p-8 text-center">No pending withdrawal requests.</p>;

  return (
    <div className="space-y-3">
      {rows.map((t) => (
        <div key={t.id} className="surface-card p-4 flex items-center justify-between gap-3">
          <div>
            <p className="font-semibold text-sm">{t.user.name} <span className="text-xs text-muted-foreground font-normal">· {t.user.email}</span></p>
            <p className="text-xs text-muted-foreground mt-0.5">₹{t.amount} · {t.sub}</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <button onClick={() => handle(t.id, 'approve')} className="btn-primary !py-2 !px-4 text-xs">Approve</button>
            <button onClick={() => handle(t.id, 'reject')} className="btn-secondary !py-2 !px-4 text-xs !border-destructive/30 !text-destructive">Reject</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function SkeletonBlock() {
  return <div className="surface-card h-48 animate-pulse bg-muted" />;
}

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );
}
