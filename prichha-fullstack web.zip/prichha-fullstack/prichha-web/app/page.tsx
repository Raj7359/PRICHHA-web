'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { MessageCircle, Phone, Video, Star, ArrowRight } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import Navbar from '@/components/Navbar';

export default function HomePage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading || !user) return;
    if (user.role === 'STUDENT') router.replace('/student/dashboard');
    else if (user.role === 'ADMIN') router.replace('/admin');
    else router.replace('/advisor/dashboard');
  }, [user, loading, router]);

  return (
    <>
      <Navbar />
      <main className="max-w-6xl mx-auto px-5 py-16 md:py-24">
        <div className="max-w-2xl">
          <div className="chip bg-primary-light text-primary font-semibold mb-6">Real advice, from real people</div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight leading-tight mb-5">
            Talk to someone who&apos;s <span className="text-primary">already been there.</span>
          </h1>
          <p className="text-muted-foreground text-lg leading-relaxed mb-8">
            Book a chat, audio, or video session with a college senior or working professional — honest, 1-on-1 guidance
            on admissions, careers, and everything in between.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link href="/register" className="btn-primary inline-flex items-center gap-2">
              Get started <ArrowRight size={16} />
            </Link>
            <Link href="/login" className="btn-secondary">
              I already have an account
            </Link>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 mt-20">
          {[
            { icon: MessageCircle, label: 'Chat', desc: 'Text a mentor whenever you have a question.', color: 'text-primary', bg: 'bg-primary-light' },
            { icon: Phone, label: 'Audio Call', desc: 'A real conversation, no video needed.', color: 'text-amber', bg: 'bg-amber-light' },
            { icon: Video, label: 'Video Call', desc: 'Face-to-face guidance sessions.', color: 'text-accent', bg: 'bg-accent-light' },
          ].map((f) => (
            <div key={f.label} className="surface-card p-6">
              <div className={`w-11 h-11 rounded-2xl ${f.bg} flex items-center justify-center mb-4`}>
                <f.icon size={20} className={f.color} />
              </div>
              <h3 className="font-bold mb-1">{f.label}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="surface-card p-8 mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} size={16} className="fill-amber text-amber" />
            ))}
            <span className="text-sm text-muted-foreground ml-2">Loved by students and professionals alike</span>
          </div>
          <Link href="/register" className="btn-primary !py-2.5 !px-6 text-sm whitespace-nowrap">
            Join Prichha — ₹11 one-time
          </Link>
        </div>
      </main>
    </>
  );
}
