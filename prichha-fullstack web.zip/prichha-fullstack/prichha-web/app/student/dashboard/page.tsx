'use client';

import { useEffect, useState } from 'react';
import { Search, Wallet as WalletIcon, GraduationCap, Briefcase } from 'lucide-react';
import Navbar from '@/components/Navbar';
import ExpertCard, { ExpertCardData } from '@/components/ExpertCard';
import BookingModal from '@/components/BookingModal';
import { useRequireRole } from '@/lib/useRequireRole';
import { getMentors, getProfessionals } from '@/lib/directory-api';
import { createTopupOrder, verifyTopupPayment } from '@/lib/payments-api';
import { useAuth, ApiError } from '@/lib/auth-context';
import { MentorDTO, ProfessionalDTO } from '@/lib/types';

type Tab = 'college' | 'jobs';

export default function StudentDashboard() {
  const { ready, user } = useRequireRole(['STUDENT']);
  const { refresh } = useAuth();

  const [tab, setTab] = useState<Tab>('college');
  const [search, setSearch] = useState('');
  const [mentors, setMentors] = useState<MentorDTO[]>([]);
  const [professionals, setProfessionals] = useState<ProfessionalDTO[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [booking, setBooking] = useState<{ id: string; name: string; rate: number; type: 'CHAT' | 'AUDIO' | 'VIDEO' } | null>(null);
  const [topupOpen, setTopupOpen] = useState(false);

  useEffect(() => {
    if (!ready) return;
    setLoadingList(true);
    const t = setTimeout(() => {
      Promise.all([getMentors({ search }), getProfessionals({ search })])
        .then(([m, p]) => {
          setMentors(m);
          setProfessionals(p);
        })
        .finally(() => setLoadingList(false));
    }, 250);
    return () => clearTimeout(t);
  }, [ready, search]);

  if (!ready) return <LoadingScreen />;

  const list: ExpertCardData[] =
    tab === 'college'
      ? mentors.map((m) => ({ id: m.id, name: m.name, avatarUrl: m.avatarUrl, subtitle: `${m.college} · ${m.stream}`, rate: m.rate, rating: m.rating, sessions: m.sessions, tags: m.tags, online: m.online }))
      : professionals.map((p) => ({ id: p.id, name: p.name, avatarUrl: p.avatarUrl, subtitle: `${p.company} · ${p.role}`, rate: p.rate, rating: p.rating, sessions: p.sessions, tags: p.tags, online: p.online }));

  return (
    <>
      <Navbar />
      <main className="max-w-6xl mx-auto px-5 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Hey {user?.name?.split(' ')[0]} 👋</h1>
            <p className="text-sm text-muted-foreground">Who do you want to talk to today?</p>
          </div>
          <button onClick={() => setTopupOpen(true)} className="btn-secondary inline-flex items-center gap-2 !py-2.5 !px-4 text-sm">
            <WalletIcon size={15} /> Add Money
          </button>
        </div>

        <div className="relative mb-5">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            className="input-field pl-11"
            placeholder="Search by name, college, or company…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setTab('college')}
            className={`chip gap-1.5 font-semibold ${tab === 'college' ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}
          >
            <GraduationCap size={14} /> College Seniors
          </button>
          <button
            onClick={() => setTab('jobs')}
            className={`chip gap-1.5 font-semibold ${tab === 'jobs' ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}
          >
            <Briefcase size={14} /> Professionals
          </button>
        </div>

        {loadingList ? (
          <SkeletonGrid />
        ) : list.length === 0 ? (
          <p className="text-sm text-muted-foreground py-12 text-center">No results found.</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {list.map((e) => (
              <ExpertCard key={e.id} expert={e} onBook={(type) => setBooking({ id: e.id, name: e.name, rate: e.rate, type })} />
            ))}
          </div>
        )}
      </main>

      {booking && (
        <BookingModal
          expertId={booking.id}
          expertName={booking.name}
          rate={booking.rate}
          initialType={booking.type}
          onClose={() => setBooking(null)}
        />
      )}
      {topupOpen && <TopupModal onClose={() => setTopupOpen(false)} onSuccess={refresh} />}
    </>
  );
}

function TopupModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => Promise<void> }) {
  const [amount, setAmount] = useState('200');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleTopup = async () => {
    const n = Number(amount);
    if (n < 1) return;
    setLoading(true);
    setError('');
    try {
      const order = await createTopupOrder(n);
      const rzp = new window.Razorpay({
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        order_id: order.orderId,
        name: 'Prichha',
        description: 'Add money to wallet',
        theme: { color: '#0D7C7A' },
        handler: async (response) => {
          try {
            await verifyTopupPayment(response);
            await onSuccess();
            onClose();
          } catch (err) {
            setError(err instanceof ApiError ? err.message : 'Verification failed.');
          }
        },
      });
      rzp.open();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not start payment.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-card w-full max-w-sm rounded-3xl p-6">
        <h2 className="font-bold text-lg mb-4">Add Money</h2>
        <div className="flex gap-2 mb-4">
          {[100, 200, 500, 1000].map((a) => (
            <button
              key={a}
              onClick={() => setAmount(String(a))}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold border ${amount === String(a) ? 'border-primary bg-primary-light text-primary' : 'border-border'}`}
            >
              ₹{a}
            </button>
          ))}
        </div>
        <input
          className="input-field mb-4"
          type="number"
          min={1}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        {error && <p className="text-sm text-destructive mb-3">{error}</p>}
        <div className="flex gap-2">
          <button onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button onClick={handleTopup} disabled={loading} className="btn-primary flex-1">
            {loading ? 'Please wait…' : `Add ₹${amount || 0}`}
          </button>
        </div>
      </div>
    </div>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="surface-card p-5 h-40 animate-pulse bg-muted" />
      ))}
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );
}
