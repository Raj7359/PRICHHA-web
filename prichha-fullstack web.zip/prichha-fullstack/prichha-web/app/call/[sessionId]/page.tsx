'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { ChevronLeft } from 'lucide-react';
import CallRoom from '@/components/CallRoom';
import ChatPanel from '@/components/ChatPanel';
import { useAuth } from '@/lib/auth-context';
import { getSession } from '@/lib/sessions-api';
import { SessionDTO } from '@/lib/types';

export default function CallPage() {
  const params = useParams<{ sessionId: string }>();
  const searchParams = useSearchParams();
  const router = useRouter();
  const { user } = useAuth();

  const [session, setSession] = useState<SessionDTO | null>(null);
  const [loading, setLoading] = useState(true);
  const [callEnded, setCallEnded] = useState(false);

  const sessionId = params.sessionId;
  const forceChatOnly = searchParams.get('mode') === 'chat';

  useEffect(() => {
    getSession(sessionId)
      .then(setSession)
      .finally(() => setLoading(false));
  }, [sessionId]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0B1220]">
        <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-3">
        <p className="text-muted-foreground text-sm">This session could not be found.</p>
        <button onClick={() => router.back()} className="btn-secondary">Go back</button>
      </div>
    );
  }

  const otherParty = user?.id === session.studentId ? session.expert : session.student;
  const isChatOnly = session.type === 'CHAT' || forceChatOnly;

  if (callEnded) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-4 text-center px-6">
        <h2 className="text-xl font-bold">Session ended</h2>
        <p className="text-sm text-muted-foreground max-w-sm">
          Thanks for using Prichha. The session cost has been deducted from your wallet and credited to {otherParty?.name || 'the expert'}.
        </p>
        <button onClick={() => router.push('/student/dashboard')} className="btn-primary">
          Back to Dashboard
        </button>
      </div>
    );
  }

  if (isChatOnly) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card">
          <button onClick={() => router.back()} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
            <ChevronLeft size={16} />
          </button>
          <div>
            <p className="font-bold text-sm">{otherParty?.name || 'Chat'}</p>
            <p className="text-xs text-success">Online</p>
          </div>
        </div>
        <div className="flex-1 min-h-0">
          <ChatPanel sessionId={sessionId} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B1220] p-0 sm:p-6 flex flex-col md:flex-row gap-4">
      <div className="flex-1 min-h-[60vh] md:min-h-[80vh]">
        <CallRoom
          sessionId={sessionId}
          isVideo={session.type === 'VIDEO'}
          expertName={otherParty?.name || 'Prichha'}
          onEnded={() => setCallEnded(true)}
        />
      </div>
      <div className="w-full md:w-80 h-64 md:h-auto bg-card md:rounded-3xl overflow-hidden shrink-0">
        <ChatPanel sessionId={sessionId} />
      </div>
    </div>
  );
}
