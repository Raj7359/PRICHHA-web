import { NextRequest, NextResponse } from 'next/server';

const PROTECTED_PREFIXES = ['/student', '/advisor', '/admin', '/call'];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isProtected = PROTECTED_PREFIXES.some((p) => pathname.startsWith(p));
  if (!isProtected) return NextResponse.next();

  // This only checks that SOME token cookie exists — it can't verify the JWT
  // signature here (that requires the JWT_SECRET, which we deliberately keep
  // server-only). An invalid/expired token still gets past this check, but
  // useRequireRole() on the page itself (backed by a real /api/auth/me call)
  // catches that and redirects to /login.
  const token = req.cookies.get('token');
  if (!token) {
    const loginUrl = new URL('/login', req.url);
    return NextResponse.redirect(loginUrl);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/student/:path*', '/advisor/:path*', '/admin/:path*', '/call/:path*'],
};
