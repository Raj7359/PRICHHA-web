'use client';

import { useEffect, useRef, useState } from 'react';
import { Send } from 'lucide-react';
import { getSocket } from '@/lib/socket';
import { listMessages } from '@/lib/sessions-api';
import { MessageDTO } from '@/lib/types';
import { useAuth } from '@/lib/auth-context';

export default function ChatPanel({ sessionId }: { sessionId: string }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<MessageDTO[]>([]);
  const [input, setInput] = useState('');
  const [connected, setConnected] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Load existing history over REST first (fast, works even before the
    // socket handshake completes), then switch to real-time via Socket.io.
    listMessages(sessionId).then(setMessages).catch(() => {});

    const socket = getSocket();

    function handleConnect() {
      setConnected(true);
      socket.emit('join_session', sessionId);
    }
    function handleNewMessage(msg: MessageDTO) {
      if (msg.sessionId !== sessionId) return;
      setMessages((prev) => (prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]));
    }

    socket.on('connect', handleConnect);
    socket.on('new_message', handleNewMessage);
    if (socket.connected) handleConnect();

    return () => {
      socket.emit('leave_session', sessionId);
      socket.off('connect', handleConnect);
      socket.off('new_message', handleNewMessage);
    };
  }, [sessionId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleSend = () => {
    const text = input.trim();
    if (!text) return;
    setInput('');
    getSocket().emit('send_message', { sessionId, text });
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground pt-10">Say hi to start the conversation.</p>
        ) : (
          messages.map((m) => {
            const fromMe = m.senderId === user?.id;
            return (
              <div key={m.id} className={`flex ${fromMe ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                    fromMe ? 'bg-primary text-white rounded-br-sm' : 'bg-muted text-foreground rounded-bl-sm'
                  }`}
                >
                  {m.text}
                  <div className={`text-[10px] mt-1 ${fromMe ? 'text-white/70' : 'text-muted-foreground'}`}>
                    {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      <div className="flex items-end gap-2 p-3 border-t border-border">
        <input
          className="input-field flex-1 !py-2.5"
          placeholder={connected ? 'Type a message…' : 'Connecting…'}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        />
        <button
          onClick={handleSend}
          disabled={!input.trim()}
          className="w-11 h-11 rounded-2xl bg-primary text-white flex items-center justify-center disabled:opacity-40 shrink-0"
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  );
}
