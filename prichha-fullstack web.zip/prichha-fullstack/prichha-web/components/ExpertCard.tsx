'use client';

import { Star, MessageCircle, Phone, Video } from 'lucide-react';

export interface ExpertCardData {
  id: string;
  name: string;
  avatarUrl?: string | null;
  subtitle: string; // "IIT Bombay · CSE 2nd yr" or "Google · SWE II"
  rate: number;
  rating: number;
  sessions: number;
  tags: string[];
  online: boolean;
}

export default function ExpertCard({ expert, onBook }: { expert: ExpertCardData; onBook: (type: 'CHAT' | 'AUDIO' | 'VIDEO') => void }) {
  return (
    <div className="surface-card p-5 flex flex-col gap-4">
      <div className="flex items-start gap-3">
        <div className="relative shrink-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={expert.avatarUrl || `https://i.pravatar.cc/100?u=${expert.id}`}
            alt={expert.name}
            className="w-14 h-14 rounded-full object-cover border border-border"
          />
          {expert.online && <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-success border-2 border-card" />}
        </div>
        <div className="min-w-0">
          <h3 className="font-bold text-[15px] truncate">{expert.name}</h3>
          <p className="text-xs text-muted-foreground truncate">{expert.subtitle}</p>
          <div className="flex items-center gap-1.5 mt-1 text-xs text-muted-foreground">
            <Star size={12} className="fill-amber text-amber" />
            {expert.rating.toFixed(1)}
            <span>· {expert.sessions} sessions</span>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {expert.tags.slice(0, 3).map((t) => (
          <span key={t} className="chip bg-primary-light text-primary text-[11px]">
            {t}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between pt-1">
        <span className="text-sm font-bold text-primary">₹{expert.rate}/min</span>
        <div className="flex gap-1.5">
          <button
            onClick={() => onBook('CHAT')}
            className="w-9 h-9 rounded-xl bg-primary-light text-primary flex items-center justify-center hover:opacity-80"
            title="Chat"
          >
            <MessageCircle size={15} />
          </button>
          <button
            onClick={() => onBook('AUDIO')}
            className="w-9 h-9 rounded-xl bg-amber-light text-amber flex items-center justify-center hover:opacity-80"
            title="Audio call"
          >
            <Phone size={15} />
          </button>
          <button
            onClick={() => onBook('VIDEO')}
            className="w-9 h-9 rounded-xl bg-accent-light text-accent flex items-center justify-center hover:opacity-80"
            title="Video call"
          >
            <Video size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}
