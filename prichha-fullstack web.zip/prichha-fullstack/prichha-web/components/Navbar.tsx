'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Wallet, LogOut, LayoutDashboard, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

export default function Navbar() {
  const { user, logout } = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    await logout();
    router.push('/login');
  };

  const dashboardHref =
    user?.role === 'STUDENT' ? '/student/dashboard' : user?.role === 'ADMIN' ? '/admin' : '/advisor/dashboard';

  return (
    <header className="sticky top-0 z-40 bg-card/95 backdrop-blur border-b border-border">
      <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center text-white font-bold text-sm">P</div>
          <span className="font-bold text-lg tracking-tight">Prichha</span>
        </Link>

        {user ? (
          <nav className="flex items-center gap-2">
            {user.role === 'STUDENT' && (
              <div className="chip bg-primary-light text-primary font-semibold gap-1.5 mr-1">
                <Wallet size={14} />₹{user.balance.toLocaleString('en-IN')}
              </div>
            )}
            <Link
              href={dashboardHref}
              className="chip bg-muted text-foreground font-medium hover:bg-border transition-colors gap-1.5"
            >
              {user.role === 'ADMIN' ? <ShieldCheck size={14} /> : <LayoutDashboard size={14} />}
              Dashboard
            </Link>
            <button
              onClick={handleLogout}
              className="chip bg-transparent text-muted-foreground hover:text-destructive transition-colors gap-1.5"
            >
              <LogOut size={14} />
              Log out
            </button>
          </nav>
        ) : (
          <nav className="flex items-center gap-3">
            <Link href="/login" className="chip text-foreground font-medium hover:text-primary transition-colors">
              Log in
            </Link>
            <Link href="/register" className="btn-primary !py-2 !px-5 text-sm">
              Sign up
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
