'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import type {
  IAgoraRTCClient,
  IMicrophoneAudioTrack,
  ICameraVideoTrack,
  IAgoraRTCRemoteUser,
} from 'agora-rtc-sdk-ng';
import { Mic, MicOff, Video, VideoOff, RefreshCw, PhoneOff, Loader2 } from 'lucide-react';
import { getCallToken, endCall } from '@/lib/calls-api';

interface Props {
  sessionId: string;
  isVideo: boolean;
  expertName: string;
  onEnded: () => void;
}

export default function CallRoom({ sessionId, isVideo, expertName, onEnded }: Props) {
  const clientRef = useRef<IAgoraRTCClient | null>(null);
  const micTrackRef = useRef<IMicrophoneAudioTrack | null>(null);
  const camTrackRef = useRef<ICameraVideoTrack | null>(null);
  const localVideoRef = useRef<HTMLDivElement>(null);
  const remoteVideoRef = useRef<HTMLDivElement>(null);

  const [status, setStatus] = useState<'connecting' | 'connected' | 'error'>('connecting');
  const [errorMessage, setErrorMessage] = useState('');
  const [remoteUser, setRemoteUser] = useState<IAgoraRTCRemoteUser | null>(null);
  const [muted, setMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const endingRef = useRef(false);

  useEffect(() => {
    let cancelled = false;

    async function setup() {
      try {
        // agora-rtc-sdk-ng only runs in the browser (it touches WebRTC/media
        // APIs), so it's imported dynamically rather than at module scope —
        // this also keeps it out of the server-side render bundle.
        const AgoraRTC = (await import('agora-rtc-sdk-ng')).default;
        const client = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });
        clientRef.current = client;

        client.on('user-published', async (user, mediaType) => {
          await client.subscribe(user, mediaType);
          if (mediaType === 'video') {
            setRemoteUser(user);
            setTimeout(() => user.videoTrack?.play(remoteVideoRef.current!), 0);
          }
          if (mediaType === 'audio') {
            user.audioTrack?.play();
          }
        });
        client.on('user-unpublished', (user, mediaType) => {
          if (mediaType === 'video') setRemoteUser((cur) => (cur?.uid === user.uid ? null : cur));
        });
        client.on('user-left', (user) => {
          setRemoteUser((cur) => (cur?.uid === user.uid ? null : cur));
        });

        const data = await getCallToken(sessionId);
        if (cancelled) return;

        await client.join(data.appId, data.channel, data.token, data.uid);

        const micTrack = await AgoraRTC.createMicrophoneAudioTrack();
        micTrackRef.current = micTrack;
        const tracksToPublish: (IMicrophoneAudioTrack | ICameraVideoTrack)[] = [micTrack];

        if (data.video) {
          const camTrack = await AgoraRTC.createCameraVideoTrack();
          camTrackRef.current = camTrack;
          camTrack.play(localVideoRef.current!);
          tracksToPublish.push(camTrack);
        }

        await client.publish(tracksToPublish);
        if (!cancelled) setStatus('connected');
      } catch (err: any) {
        if (!cancelled) {
          setStatus('error');
          setErrorMessage(err?.message || 'Could not start the call. Please check your camera/microphone permissions.');
        }
      }
    }

    setup();

    return () => {
      cancelled = true;
      micTrackRef.current?.close();
      camTrackRef.current?.close();
      clientRef.current?.leave();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId]);

  useEffect(() => {
    if (status !== 'connected') return;
    const interval = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(interval);
  }, [status]);

  const handleEndCall = useCallback(async () => {
    if (endingRef.current) return;
    endingRef.current = true;
    micTrackRef.current?.close();
    camTrackRef.current?.close();
    await clientRef.current?.leave();
    try {
      await endCall(sessionId);
    } catch {
      // Best-effort — server still has accurate startedAt for reconciliation.
    }
    onEnded();
  }, [sessionId, onEnded]);

  const toggleMute = async () => {
    const next = !muted;
    setMuted(next);
    await micTrackRef.current?.setEnabled(!next);
  };

  const toggleCamera = async () => {
    const next = !cameraOff;
    setCameraOff(next);
    await camTrackRef.current?.setEnabled(!next);
  };

  const flipCamera = async () => {
    if (!camTrackRef.current) return;
    const AgoraRTC = (await import('agora-rtc-sdk-ng')).default;
    const cameras = await AgoraRTC.getCameras();
    if (cameras.length < 2) return;
    const currentLabel = camTrackRef.current.getTrackLabel();
    const next = cameras.find((c) => c.label !== currentLabel) || cameras[0];
    await camTrackRef.current.setDevice(next.deviceId);
  };

  if (status === 'error') {
    return (
      <div className="h-full flex flex-col items-center justify-center text-white gap-3 p-8 text-center">
        <p className="text-sm">{errorMessage}</p>
        <button onClick={onEnded} className="btn-secondary !bg-white/10 !border-white/20 !text-white">
          Close
        </button>
      </div>
    );
  }

  return (
    <div className="relative h-full bg-[#0B1220] overflow-hidden rounded-3xl">
      {/* Remote video fills the frame; audio-only calls show an avatar placeholder */}
      {isVideo ? (
        <div ref={remoteVideoRef} className="absolute inset-0 bg-[#0B1220]" />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary to-primary/70">
          <div className="w-28 h-28 rounded-full bg-white/20 flex items-center justify-center text-white text-3xl font-bold">
            {expertName.charAt(0)}
          </div>
        </div>
      )}

      {status === 'connecting' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#0B1220]/80 text-white">
          <Loader2 className="animate-spin" size={28} />
          <p className="text-sm">Connecting…</p>
        </div>
      )}

      {/* Local preview */}
      {isVideo && !cameraOff && (
        <div ref={localVideoRef} className="absolute top-4 right-4 w-28 h-40 rounded-2xl overflow-hidden border-2 border-white/30 bg-black" />
      )}

      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 p-5 flex flex-col items-center gap-1.5 text-white">
        <p className="font-bold">{expertName}</p>
        <div className="chip bg-black/35 text-white gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${remoteUser ? 'bg-success' : 'bg-amber'}`} />
          {remoteUser || !isVideo ? formatDuration(elapsed) : 'Waiting for other side…'}
        </div>
      </div>

      {/* Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-6 flex items-center justify-center gap-4">
        <ControlButton active={muted} onClick={toggleMute} icon={muted ? MicOff : Mic} />
        {isVideo && <ControlButton active={cameraOff} onClick={toggleCamera} icon={cameraOff ? VideoOff : Video} />}
        {isVideo && <ControlButton onClick={flipCamera} icon={RefreshCw} />}
        <button onClick={handleEndCall} className="w-16 h-16 rounded-full bg-destructive flex items-center justify-center">
          <PhoneOff size={22} className="text-white" />
        </button>
      </div>
    </div>
  );
}

function ControlButton({ icon: Icon, active, onClick }: { icon: typeof Mic; active?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${active ? 'bg-white/35' : 'bg-white/15'}`}
    >
      <Icon size={20} className="text-white" />
    </button>
  );
}

function formatDuration(sec: number) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}
