'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { X, MessageCircle, Phone, Video } from 'lucide-react';
import { bookSession } from '@/lib/sessions-api';
import { ApiError } from '@/lib/auth-context';

interface Props {
  expertId: string;
  expertName: string;
  rate: number;
  initialType: 'CHAT' | 'AUDIO' | 'VIDEO';
  onClose: () => void;
}

const TYPE_META = {
  CHAT: { icon: MessageCircle, label: 'Chat', color: 'text-primary', bg: 'bg-primary-light' },
  AUDIO: { icon: Phone, label: 'Audio Call', color: 'text-amber', bg: 'bg-amber-light' },
  VIDEO: { icon: Video, label: 'Video Call', color: 'text-accent', bg: 'bg-accent-light' },
} as const;

export default function BookingModal({ expertId, expertName, rate, initialType, onClose }: Props) {
  const router = useRouter();
  const [type, setType] = useState(initialType);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const effectiveRate = type === 'VIDEO' ? Math.round(rate * 1.3) : rate;

  const handleConfirm = async () => {
    setLoading(true);
    setError('');
    try {
      const session = await bookSession({
        expertId,
        type,
        ratePerMin: effectiveRate,
        scheduledAt: new Date().toISOString(), // on-demand booking — starts immediately
      });
      if (type === 'CHAT') {
        router.push(`/call/${session.id}?mode=chat`);
      } else {
        router.push(`/call/${session.id}`);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not book this session. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-card w-full sm:max-w-sm rounded-t-3xl sm:rounded-3xl p-6 animate-in slide-in-from-bottom">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-bold text-lg">Book with {expertName}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
            <X size={16} />
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-5">
          {(Object.keys(TYPE_META) as Array<keyof typeof TYPE_META>).map((t) => {
            const meta = TYPE_META[t];
            const active = type === t;
            return (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`p-3 rounded-2xl border text-center transition-colors ${
                  active ? 'border-primary bg-primary-light' : 'border-border hover:bg-muted'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl ${active ? 'bg-primary' : meta.bg} flex items-center justify-center mx-auto mb-2`}>
                  <meta.icon size={16} className={active ? 'text-white' : meta.color} />
                </div>
                <div className={`text-xs font-bold ${active ? 'text-primary' : 'text-foreground'}`}>{meta.label}</div>
              </button>
            );
          })}
        </div>

        <div className="surface-card !shadow-none bg-primary-light border-primary/20 p-4 mb-5">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Rate</span>
            <span className="font-bold text-primary">₹{effectiveRate}/min</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            You&apos;ll be connected right away. Billing starts once the {type === 'CHAT' ? 'chat' : 'call'} begins and is deducted from your wallet.
          </p>
        </div>

        {error && <p className="text-sm text-destructive mb-3">{error}</p>}

        <button onClick={handleConfirm} disabled={loading} className="btn-primary w-full">
          {loading ? 'Connecting…' : `Start ${TYPE_META[type].label}`}
        </button>
      </div>
    </div>
  );
}
